package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.AIMLServiceResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.AIMLSuggestionService;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;


public class AIMLSuggestionServiceTest extends BaseIntegrationTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private SearchConfig searchConfig;

    @InjectMocks
    private AIMLSuggestionService aimlSuggestionService;

    private List<DrugResponse> elasticResp = Lists.newArrayList(DrugResponse.builder().drugName("NOVOLOG Test1").build(),
            DrugResponse.builder().drugName("NOVOLOG Test2").build(),
            DrugResponse.builder().drugName("NOVOLOG Test3").build(),
            DrugResponse.builder().drugName("NOVOLOG Test4").build(),
            DrugResponse.builder().drugName("NOVOLOG Test5").build(),
            DrugResponse.builder().drugName("NOVOLOG Test6").build(),
            DrugResponse.builder().drugName("NOVOLOG AIML1").build(),
            DrugResponse.builder().drugName("NOVOLOG AIML2").build());

    @Test
    public void testAIMLCallWhenNoAIMLSuggestionsSuccess3(){
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);

        HttpEntity entity = new HttpEntity<>("{\"name\":\"novo\"}", headers);
        AIMLServiceResponse aimlResp = new AIMLServiceResponse();
        List<String> suggestedDrugs = new ArrayList<>();
        aimlResp.setSuggestedDrugs(suggestedDrugs);
        lenient().when(searchConfig.getAimlServiceUrl()).thenReturn("http://test.com");
        lenient().when(restTemplate.postForEntity(Mockito.eq("http://test.com"),Mockito.eq(entity),Mockito.eq(AIMLServiceResponse.class)))
                .thenReturn(new ResponseEntity<>(aimlResp, HttpStatus.OK));

        List<DrugResponse> combinedAIMLElasticResp = aimlSuggestionService.getAIMLSuggestions(elasticResp, "novo");
        Assert.assertNotNull(combinedAIMLElasticResp);
        //Check if AIML drugs are not inserted.
        Assert.assertTrue(combinedAIMLElasticResp.get(2).getDrugName().equalsIgnoreCase("NOVOLOG Test3"));
        Assert.assertTrue(combinedAIMLElasticResp.get(3).getDrugName().equalsIgnoreCase("NOVOLOG Test4"));
    }

    @Test
    public void testAIMLCallFailedAndReturnElasticResponse(){
        AIMLServiceResponse aimlResp = new AIMLServiceResponse();
        aimlResp.setSuggestedDrugs(new ArrayList<>());
        when(searchConfig.getAimlServiceUrl()).thenReturn("http://test.com");
        lenient().when(restTemplate.postForEntity(Mockito.eq("http://test.com"),Mockito.eq(new HttpEntity<>("{\"name\":\"novo\"}",
                        new LinkedMultiValueMap<>())),
                Mockito.eq(AIMLServiceResponse.class))).thenThrow(new RuntimeException());

        List<DrugResponse> combinedAIMLElasticResp = aimlSuggestionService.getAIMLSuggestions(elasticResp, "novo");
        Assert.assertNotNull(combinedAIMLElasticResp);
        //Check if AIML drugs are not inserted.
        Assert.assertTrue(combinedAIMLElasticResp.get(2).getDrugName().equalsIgnoreCase("NOVOLOG Test3"));
        Assert.assertTrue(combinedAIMLElasticResp.get(3).getDrugName().equalsIgnoreCase("NOVOLOG Test4"));
    }

}
