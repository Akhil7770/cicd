package com.cvshealth.digital.microservice.rxomnidrugsearch.test.data;

import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.CacheResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.ResponseData;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.ResponseMetaData;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.ResponsePayloadData;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugConditionFDBResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsEslResponse;import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.DrugSearchNdcidRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.experimental.UtilityClass;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@UtilityClass
public class TestHelper {

    public static final String LIPPI = "LIPPI";
    public static final String LIPITOR = "LIPITOR";
    public static final String ZANACKS = "ZANACKS";
    public static final String XANAX = "XANAX";
    public static final String LIPATOR = "lipator";
    public static final String CONDITION_MIGRAINE = "Migraine";
    public static final String CONDITION_HEARTFAILURE = "Heart Failure";

    public static ObjectMapper getObjectMapper(){
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return objectMapper;
    }

    public static final String SILDENAFIL_CDT_RECORD = "{\n" +
            "    \"brand_name\": \"SILDENAFIL\",\n" +
            "    \"dsg_form\": \"TAB\",\n" +
            "    \"gnrc_name\": \"SILDENAFIL CITRATE\",\n" +
            "    \"gpi_code\": \"40304070100330\",\n" +
            "    \"ndc_code\": \"76282064501\",\n" +
            "    \"rxclm_mail_rep_drug_ind\": null,\n" +
            "    \"rxclm_mail_rep_drug_mc_qty\": \"0\",\n" +
            "    \"rxRetailClaimCount\": \"5376\",\n"+
            "    \"rxclm_retail_claim_count\": \"5376\",\n" +
            "    \"rxclm_rtl_rep_drug_mc_qty\": \"6\",\n" +
            "    \"strgh_desc\": \"100MG\",\n" +
            "    \"drug_gid\": \"42489669\",\n" +
            "    \"drug_rxclm_src_flg\": \"1\",\n" +
            "    \"eff_date\": \"2022-10-26\",\n" +
            "    \"end_date\": \"2999-12-31\",\n" +
            "    \"gcn_nbr\": \"57903\",\n" +
            "    \"gnrc_flag\": \"1\",\n" +
            "    \"gpi_code_6\": \"403040\",\n" +
            "    \"gpi_name\": \"SILDENAFIL CITRATE TAB 100 MG\",\n" +
            "    \"pkg_desc\": \"BOTTLE\",\n" +
            "    \"rx_otc_ind\": \"S\",\n" +
            "    \"rxclm_mail_claim_count\": \"0\",\n" +
            "    \"rxclm_ml_rep_drug_day_sply_qty\": \"0\",\n" +
            "    \"rxclm_obslt_date\": \"2039-12-31\",\n" +
            "    \"rxclm_retail_rep_drug_ind\": \"Y\",\n" +
            "    \"rxclm_rtl_rep_drug_dy_sply_qty\": \"30\",\n" +
            "    \"strgh_nbr\": \"100\",\n" +
            "    \"usc_code\": \" \",\n" +
            "    \"usc_desc\": \" \",\n" +
            "    \"currentdate\": \"2024-07-05\"\n" +
            "  }";

    public static final String ATORVASTATIN_RECORD = "{\n" +
            "    \"brand_name\": \"ATORVASTATIN CALCIUM\",\n" +
            "    \"rxclm_retail_claim_count\":\"100\",\n"+
            "    \"rxRetailClaimCount\": \"100\",\n"+
            "    \"dsg_form\": \"TAB\",\n" +
            "    \"gnrc_name\": \"ATORVASTATIN CALCIUM\",\n" +
            "    \"gpi_code\": \"39400010100310\",\n" +
            "    \"ndc_code\": \"60505257809\",\n" +
            "    \"rxclm_mail_rep_drug_ind\": null,\n" +
            "    \"rxclm_mail_rep_drug_mc_qty\": \"0\",\n" +
            "    \"rxclm_retail_claim_count\": \"654217\",\n" +
            "    \"rxclm_rtl_rep_drug_mc_qty\": \"90\",\n" +
            "    \"strgh_desc\": \"10MG\",\n" +
            "    \"drug_gid\": \"631190\",\n" +
            "    \"drug_rxclm_src_flg\": \"1\",\n" +
            "    \"eff_date\": \"2012-05-31\",\n" +
            "    \"end_date\": \"2999-12-31\",\n" +
            "    \"gcn_nbr\": \"43720\",\n" +
            "    \"gnrc_flag\": \"1\",\n" +
            "    \"gpi_code_6\": \"394000\",\n" +
            "    \"gpi_name\": \"ATORVASTATIN CALCIUM TAB 10 MG (BASE EQUIVALENT)\",\n" +
            "    \"pkg_desc\": \"BOTTLE\",\n" +
            "    \"rx_otc_ind\": \"S\",\n" +
            "    \"rxclm_mail_claim_count\": \"0\",\n" +
            "    \"rxclm_ml_rep_drug_day_sply_qty\": \"0\",\n" +
            "    \"rxclm_obslt_date\": \"2039-12-31\",\n" +
            "    \"rxclm_retail_rep_drug_ind\": \"Y\",\n" +
            "    \"rxclm_rtl_rep_drug_dy_sply_qty\": \"90\",\n" +
            "    \"strgh_nbr\": \"10\",\n" +
            "    \"usc_code\": \"32100\",\n" +
            "    \"usc_desc\": \"ANTIHYPERLIPIDEMIC AGENTS\",\n" +
            "    \"currentdate\": \"2024-07-05\"\n" +
            "  }";


    public static final String LIPITOR_RECORD = "{\n" +
            "    \"brand_name\": \"LIPITOR\",\n" +
            "    \"dsg_form\": \"TAB\",\n" +
            "    \"gnrc_name\": \"ATORVASTATIN CALCIUM\",\n" +
            "    \"gpi_code\": \"39400010100310\",\n" +
            "    \"ndc_code\": \"00071015523\",\n" +
            "    \"rxclm_mail_rep_drug_ind\": \"Y\",\n" +
            "    \"rxclm_mail_rep_drug_mc_qty\": \"90\",\n" +
            "    \"rxclm_retail_claim_count\": \"2698\",\n" +
            "    \"rxRetailClaimCount\": \"2698\",\n" +
            "    \"rxclm_rtl_rep_drug_mc_qty\": \"\",\n" +
            //"    \"rxclm_rtl_rep_drug_mc_qty\": \"90\",\n" +
            "    \"strgh_desc\": \"10MG\",\n" +
            "    \"drug_gid\": \"12978\",\n" +
            "    \"drug_rxclm_src_flg\": \"1\",\n" +
            "    \"eff_date\": \"1997-01-28\",\n" +
            "    \"end_date\": \"2999-12-31\",\n" +
            "    \"gcn_nbr\": \"43720\",\n" +
            "    \"gnrc_flag\": \"0\",\n" +
            "    \"gpi_code_6\": \"394000\",\n" +
            "    \"gpi_name\": \"ATORVASTATIN CALCIUM TAB 10 MG (BASE EQUIVALENT)\",\n" +
            "    \"pkg_desc\": \"BOTTLE\",\n" +
            "    \"rx_otc_ind\": \"S\",\n" +
            "    \"rxclm_mail_claim_count\": \"924\",\n" +
            "    \"rxclm_ml_rep_drug_day_sply_qty\": \"90\",\n" +
            "    \"rxclm_obslt_date\": \"2039-12-31\",\n" +
            "    \"rxclm_retail_rep_drug_ind\": \"Y\",\n" +
            "    \"rxclm_rtl_rep_drug_dy_sply_qty\": \"90\",\n" +
            "    \"strgh_nbr\": \"10\",\n" +
            "    \"usc_code\": \"32100\",\n" +
            "    \"usc_desc\": \"ANTIHYPERLIPIDEMIC AGENTS\",\n" +
            "    \"currentdate\": \"2024-07-05\"\n" +
            "  }";

    public static final String LIP2_RECORD = "{\n" +
            "    \"brand_name\": \"STICKLIPSTICK\",\n" +
            "    \"dsg_form\": \"TAB\",\n" +
            "    \"gnrc_name\": \"STICKLIPSTICK\",\n" +
            "    \"gpi_code\": \"39400010100311\",\n" +
            "    \"ndc_code\": \"00071015524\",\n" +
            "    \"rxclm_mail_rep_drug_ind\": \"Y\",\n" +
            "    \"rxclm_mail_rep_drug_mc_qty\": \"90\",\n" +
            "    \"rxclm_retail_claim_count\": \"2698\",\n" +
            "    \"rxRetailClaimCount\": \"2698\",\n" +
            "    \"rxclm_rtl_rep_drug_mc_qty\": \"\",\n" +
            //"    \"rxclm_rtl_rep_drug_mc_qty\": \"90\",\n" +
            "    \"strgh_desc\": \"10MG\",\n" +
            "    \"drug_gid\": \"12978\",\n" +
            "    \"drug_rxclm_src_flg\": \"1\",\n" +
            "    \"eff_date\": \"1997-01-28\",\n" +
            "    \"end_date\": \"2999-12-31\",\n" +
            "    \"gcn_nbr\": \"43720\",\n" +
            "    \"gnrc_flag\": \"0\",\n" +
            "    \"gpi_code_6\": \"394000\",\n" +
            "    \"gpi_name\": \"ATORVASTATIN CALCIUM TAB 10 MG (BASE EQUIVALENT)\",\n" +
            "    \"pkg_desc\": \"BOTTLE\",\n" +
            "    \"rx_otc_ind\": \"S\",\n" +
            "    \"rxclm_mail_claim_count\": \"924\",\n" +
            "    \"rxclm_ml_rep_drug_day_sply_qty\": \"90\",\n" +
            "    \"rxclm_obslt_date\": \"2039-12-31\",\n" +
            "    \"rxclm_retail_rep_drug_ind\": \"Y\",\n" +
            "    \"rxclm_rtl_rep_drug_dy_sply_qty\": \"90\",\n" +
            "    \"strgh_nbr\": \"10\",\n" +
            "    \"usc_code\": \"32100\",\n" +
            "    \"usc_desc\": \"ANTIHYPERLIPIDEMIC AGENTS\",\n" +
            "    \"currentdate\": \"2024-07-05\"\n" +
            "  }";

    public static final String ndc1Data = "{\n" +
            "    \"drug_gid\": \"84705\",\n" +
            "    \"ndc_code\": \"65757030001\",\n" +
            "    \"eff_date\": \"2009-05-19\",\n" +
            "    \"recap_eff_date\": null,\n" +
            "    \"ql_eff_date\": \"2009-05-19\",\n" +
            "    \"end_date\": \"2999-12-31\",\n" +
            "    \"recap_end_date\": null,\n" +
            "    \"ql_end_date\": \"2999-12-31\",\n" +
            "    \"brand_name\": \"VIVITROL\",\n" +
            "    \"recap_brand_name\": null,\n" +
            "    \"ql_brand_name\": \"VIVITROL\",\n" +
            "    \"desi_drug_ind\": \"0\",\n" +
            "    \"desi_eff_date\": null,\n" +
            "    \"drug_class\": \"F\",\n" +
            "    \"drug_form\": \"EA\",\n" +
            "    \"gnrc_prdct_ind\": null,\n" +
            "    \"lblr_code\": null,\n" +
            "    \"lblr_desc\": \"ALKERMES\",\n" +
            "    \"orng_book_code\": \"NR\",\n" +
            "    \"pkg_size\": \"1\",\n" +
            "    \"recap_pkg_size\": null,\n" +
            "    \"ql_pkg_size\": \"1\",\n" +
            "    \"pkg_desc\": \"VIAL\",\n" +
            "    \"innov_code\": null,\n" +
            "    \"lbl_name\": \"VIVITROL VIA 380MG\",\n" +
            "    \"maint_ind\": \"0\",\n" +
            "    \"recap_maint_ind\": null,\n" +
            "    \"ql_maint_ind\": \"0\",\n" +
            "    \"mfg_name\": \"ALKERMES\",\n" +
            "    \"gcn_code\": null,\n" +
            "    \"gcn_nbr\": \"27095\",\n" +
            "    \"recap_gnrc_clas_nb\": null,\n" +
            "    \"dsg_form\": \"VIA\",\n" +
            "    \"ql_dsg_form\": \"SUSR\",\n" +
            "    \"cat_type_code\": \" \",\n" +
            "    \"strgh_desc\": \"380MG\",\n" +
            "    \"strgh_nbr\": \"380\",\n" +
            "    \"strgh_unit\": \"MG\",\n" +
            "    \"strgh_vol_nbr\": \"0\",\n" +
            "    \"strgh_vol_unit\": \" \",\n" +
            "    \"route_name\": \"INTRAMUSCULAR INJECT\",\n" +
            "    \"gc3_code\": \"C0D\",\n" +
            "    \"gnrc_name\": \"NALTREXONE\",\n" +
            "    \"gnrc_flag\": \"0\",\n" +
            "    \"recap_gnrc_flag\": null,\n" +
            "    \"ms_gnrc_flag\": \"0\",\n" +
            "    \"ql_gnrc_flag\": \"0\",\n" +
            "    \"multi_type_code\": \"N\",\n" +
            "    \"recap_multi_typ_cd\": null,\n" +
            "    \"ql_multi_typ_cd\": \"N\",\n" +
            "    \"brand_name_code\": \"T\",\n" +
            "    \"gpi_code\": \"93400030001920\",\n" +
            "    \"gpi_code_6\": \"934000\",\n" +
            "    \"usc_code\": \"78300\",\n" +
            "    \"legal_status\": \" \",\n" +
            "    \"min_dly_unt_qty_vl\": null,\n" +
            "    \"min_dly_unt_frm_vl\": null,\n" +
            "    \"max_dly_unt_qty_vl\": null,\n" +
            "    \"max_dly_unt_frm_vl\": null,\n" +
            "    \"drug_fdb_src_flg\": \"1\",\n" +
            "    \"drug_mddb_src_flg\": \"1\",\n" +
            "    \"drug_recap_src_flg\": \"0\",\n" +
            "    \"drug_rxclm_src_flg\": \"1\",\n" +
            "    \"drug_ql_src_flg\": \"1\",\n" +
            "    \"src_flag\": null,\n" +
            "    \"dea_code\": \"0\",\n" +
            "    \"recap_obslt_date\": null,\n" +
            "    \"rxclm_obslt_date\": \"2039-12-31\",\n" +
            "    \"usc_desc\": \"SPECIFIC ANTAGONISTS/ANTIDOTES\",\n" +
            "    \"gpi_name\": \"NALTREXONE FOR IM EXTENDED RELEASE SUSP 380 MG\",\n" +
            "    \"tot_pkg_qty\": \"1\",\n" +
            "    \"ahfs_cd\": \"281000\",\n" +
            "    \"strg_cond\": \"R\",\n" +
            "    \"lmtd_stlty\": null,\n" +
            "    \"unit_dsg_code\": \"U\",\n" +
            "    \"rpkg_ind\": \"0\",\n" +
            "    \"med_d_ind\": \"Y\",\n" +
            "    \"lmt_dstrb_cd\": \"00\",\n" +
            "    \"orng_book_desc\": \"NOT RATED (DRUG PRODUCT HAS NOT YET BEEN RATED).\",\n" +
            "    \"rx_otc_ind\": \"R\",\n" +
            "    \"std500_drug_prfr_stus_cd\": null,\n" +
            "    \"gnrc_thcls_code\": \"99\",\n" +
            "    \"ql_obslt_date\": null,\n" +
            "    \"ql_nhu_type_cd\": \"0001\",\n" +
            "    \"gppc_id\": \"50270005\",\n" +
            "    \"drug_cd_typ_cd\": \"03\",\n" +
            "    \"currentdate\": \"2024-07-05\"\n" +
            "  }";
    public static final String ndc2Data = "{\n" +
            "    \"drug_gid\": \"39842617\",\n" +
            "    \"ndc_code\": \"00054028259\",\n" +
            "    \"eff_date\": \"2020-12-01\",\n" +
            "    \"recap_eff_date\": null,\n" +
            "    \"ql_eff_date\": \"2020-12-01\",\n" +
            "    \"end_date\": \"2999-12-31\",\n" +
            "    \"recap_end_date\": null,\n" +
            "    \"ql_end_date\": \"2999-12-31\",\n" +
            "    \"brand_name\": \"ALENDRONATE SODIUM\",\n" +
            "    \"recap_brand_name\": null,\n" +
            "    \"ql_brand_name\": \"ALENDRONATE SODIUM\",\n" +
            "    \"desi_drug_ind\": \"0\",\n" +
            "    \"desi_eff_date\": null,\n" +
            "    \"drug_class\": \"F\",\n" +
            "    \"drug_form\": \"ML\",\n" +
            "    \"gnrc_prdct_ind\": null,\n" +
            "    \"lblr_code\": null,\n" +
            "    \"lblr_desc\": \"HIKMA PHARMACEU\",\n" +
            "    \"orng_book_code\": \"AA\",\n" +
            "    \"pkg_size\": \"75\",\n" +
            "    \"recap_pkg_size\": null,\n" +
            "    \"ql_pkg_size\": \"75\",\n" +
            "    \"pkg_desc\": \"BOTTLE\",\n" +
            "    \"innov_code\": null,\n" +
            "    \"lbl_name\": \"ALENDRONATE SOL 70/75ML\",\n" +
            "    \"maint_ind\": \"1\",\n" +
            "    \"recap_maint_ind\": null,\n" +
            "    \"ql_maint_ind\": \"1\",\n" +
            "    \"mfg_name\": \"HIKMA PHARMACEUTICALS USA\",\n" +
            "    \"gcn_code\": null,\n" +
            "    \"gcn_nbr\": \"21109\",\n" +
            "    \"recap_gnrc_clas_nb\": null,\n" +
            "    \"dsg_form\": \"SOL\",\n" +
            "    \"ql_dsg_form\": \"SOLN\",\n" +
            "    \"cat_type_code\": \" \",\n" +
            "    \"strgh_desc\": \"70/75ML\",\n" +
            "    \"strgh_nbr\": \"70\",\n" +
            "    \"strgh_unit\": \"MG\",\n" +
            "    \"strgh_vol_nbr\": \"75\",\n" +
            "    \"strgh_vol_unit\": \"ML\",\n" +
            "    \"route_name\": \"ORAL\",\n" +
            "    \"gc3_code\": \"P4L\",\n" +
            "    \"gnrc_name\": \"ALENDRONATE SODIUM\",\n" +
            "    \"gnrc_flag\": \"1\",\n" +
            "    \"recap_gnrc_flag\": null,\n" +
            "    \"ms_gnrc_flag\": \"1\",\n" +
            "    \"ql_gnrc_flag\": \"1\",\n" +
            "    \"multi_type_code\": \"Y\",\n" +
            "    \"recap_multi_typ_cd\": null,\n" +
            "    \"ql_multi_typ_cd\": \"Y\",\n" +
            "    \"brand_name_code\": \"G\",\n" +
            "    \"gpi_code\": \"30042010102020\",\n" +
            "    \"gpi_code_6\": \"300420\",\n" +
            "    \"usc_code\": \"78300\",\n" +
            "    \"legal_status\": \" \",\n" +
            "    \"min_dly_unt_qty_vl\": null,\n" +
            "    \"min_dly_unt_frm_vl\": null,\n" +
            "    \"max_dly_unt_qty_vl\": null,\n" +
            "    \"max_dly_unt_frm_vl\": null,\n" +
            "    \"drug_fdb_src_flg\": \"1\",\n" +
            "    \"drug_mddb_src_flg\": \"1\",\n" +
            "    \"drug_recap_src_flg\": \"0\",\n" +
            "    \"drug_rxclm_src_flg\": \"1\",\n" +
            "    \"drug_ql_src_flg\": \"1\",\n" +
            "    \"src_flag\": null,\n" +
            "    \"dea_code\": \"0\",\n" +
            "    \"recap_obslt_date\": null,\n" +
            "    \"rxclm_obslt_date\": \"2039-12-31\",\n" +
            "    \"usc_desc\": \"SPECIFIC ANTAGONISTS/ANTIDOTES\",\n" +
            "    \"gpi_name\": \"ALENDRONATE SODIUM ORAL SOLN 70 MG/75ML\",\n" +
            "    \"tot_pkg_qty\": \"300\",\n" +
            "    \"ahfs_cd\": \"922400\",\n" +
            "    \"strg_cond\": \"N\",\n" +
            "    \"lmtd_stlty\": null,\n" +
            "    \"unit_dsg_code\": \"U\",\n" +
            "    \"rpkg_ind\": \"0\",\n" +
            "    \"med_d_ind\": \"Y\",\n" +
            "    \"lmt_dstrb_cd\": \"00\",\n" +
            "    \"orng_book_desc\": \"PRODUCTS IN CONVENTIONAL DOSAGE FORMS NOT PRESENTING BIOEQUIVALENCE PROBLEMS\",\n" +
            "    \"rx_otc_ind\": \"S\",\n" +
            "    \"std500_drug_prfr_stus_cd\": null,\n" +
            "    \"gnrc_thcls_code\": \"99\",\n" +
            "    \"ql_obslt_date\": null,\n" +
            "    \"ql_nhu_type_cd\": \"0001\",\n" +
            "    \"gppc_id\": \"38594HVK\",\n" +
            "    \"drug_cd_typ_cd\": \"03\",\n" +
            "    \"currentdate\": \"2024-07-05\"\n" +
            "  }";
    public static CacheResponse getCacheResponse() {
        CacheResponse cacheResponse = new CacheResponse();
        ResponseMetaData responseMetaData = new ResponseMetaData();
        responseMetaData.setStatusCode("0000");
        ResponsePayloadData responsePayloadData = new ResponsePayloadData();
        List<ResponseData> datalist = new ArrayList<>();
        ResponseData responseData = new ResponseData();
        responseData.setKey("key");
        responseData.setTtl(1);
        responseData.setValue("{\"statusCode\":\"200\",\"statusDescription\":\" Search is success! \",\"drugs\":[{\"drugName\":\"Lipitor\", \"detailsList\":[{\"drugName\":\"Lipitor\", \"ndc11\": \"00071015523\"}]}]}");
        datalist.add(responseData);
        responsePayloadData.setData(datalist);
        cacheResponse.setResponseMetaData(responseMetaData);
        cacheResponse.setResponsePayloadData(responsePayloadData);
        SearchResponseDto searchResponseDto = new SearchResponseDto();
        return cacheResponse;
    }
    public DrugDetailsEslResponse getDrugResponseV2() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        DrugDetailsEslResponse drugDetailsResponse = objectMapper.readValue(new File("src/test/resources/testdata/drugDtlsRespV2.json"),
                DrugDetailsEslResponse.class);
        return drugDetailsResponse;
    }

    public DrugSearchNdcidRequest getDrugSearchNdcidRequest(){
        DrugSearchNdcidRequest drugSearchNdcidRequest = new DrugSearchNdcidRequest();
        drugSearchNdcidRequest.setNdcId("00071015523");
        drugSearchNdcidRequest.setId("57226202");
        drugSearchNdcidRequest.setIsOEMember(true);
        drugSearchNdcidRequest.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        return drugSearchNdcidRequest;
    }

     public DrugConditionFDBResponse getDrugConditionFDBResponse() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        DrugConditionFDBResponse drugConditionFDBResponse = objectMapper.readValue(new File("src/test/resources/testdata/drugConditionFDBResponse.json"),
                DrugConditionFDBResponse.class);
        return drugConditionFDBResponse;
    }
}
