package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsV2Request;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FamilyInfoResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.GetPlanDetailsListResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.GetPlanDetailsResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.MemberInfoResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.GetPlanDetailsResponseV2;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.BeneficiaryKey;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.CrmService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.test.data.TestHelper;
import org.springframework.http.HttpHeaders;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CRMServiceTest extends BaseIntegrationTest{

    @InjectMocks
    private CrmService crmService;

    @Mock
    private RestService restService;

    ServiceUtils serviceUtils = new ServiceUtils(TestHelper.getObjectMapper());

    @BeforeEach
    void setup(TestInfo info) {
        if (info.getDisplayName().equalsIgnoreCase("testPatientInfoReturnNoDataAvailableException()")
                || info.getDisplayName().equalsIgnoreCase("testPlanDetailsReturnNoDataAvailable()")
                || info.getDisplayName().equalsIgnoreCase("testFamilyInfoReturnError()")) {
            return; // skip @BeforeEach in mySpecialTestName test
        }
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");

        String jsonResp = "{\"statusCode\":\"0000\",\"statusDescription\":\"Success\",\"beneficiary\":{\"userId\":\"57226202\",\"externalID\":\"05004206100\",\"beneficiaryId\":57226202,\"lastName\":\"EDUARDO\",\"firstName\":\"WARREN\",\"gender\":\"1\",\"dateOfBirth\":\"01/02/1954\",\"phoneNumbers\":[],\"personCode\":\"00\",\"sortByCode\":0,\"internalID\":57226202,\"underAgeMinor\":false,\"eisName\":\"rxclaim\",\"registered\":true,\"lockoutInd\":false,\"id\":\"57226202\",\"idtype\":\"PBM_QL_PARTICIPANT_ID_TYPE\"}}";
        MemberInfoResponse patientInfoResponse = serviceUtils.fromJson(jsonResp, MemberInfoResponse.class);
        lenient().when(restService.execute(eq("crm-service"), eq("getPatientInfo"), eq(request),
                eq(MemberInfoResponse.class), any(HttpHeaders.class), isNull())).thenReturn(patientInfoResponse);

        String jsonPlanDtlsResp = "{\"statusCode\":\"0000\",\"statusDescription\":\"Success\",\"beneficiaryKey\":{\"benefactorClientInternalID\":29047,\"cardholderInternalID\":57226202,\"carrierID\":\"22MV\",\"clientCode\":\"X22MV\",\"clientId\":29047,\"clientName\":\"IX DIRECT PAY MEDEX\",\"externalID\":\"05004206100\",\"groupID\":\"997445010\",\"accountID\":\"4015051\",\"eisName\":\"rxclaim\",\"provideClientIdentifier\":13627},\"primary\":false,\"personalizationId\":2043730,\"registrationOptedOut\":true,\"isEligible\":true,\"planStartDate\":\"2023-01-01\",\"earlyRegistrationAllowed\":true,\"medicare\":false,\"medBEligible\":false,\"aetnaClient\":false,\"nonPbmLobCode\":\"01\",\"personCode\":\"00\",\"coverageEffectiveDate\":\"2023-01-01\",\"coverageTerminationDate\":\"2039-12-31\",\"isFuturePlan\":false,\"stCob\":false,\"relationShipCode\":\"1\",\"qlMail\":true,\"planBenefitList\":[{\"active\":true,\"deliverySystem\":1,\"effective\":\"2023-01-01\",\"expiration\":\"2039-12-31\",\"planBenefitId\":\"-666\",\"planId\":\"TDMSHLPLNI\",\"retail90DaySupplyProgram\":false,\"maintenanceChoiceIndicator\":false},{\"active\":true,\"deliverySystem\":2,\"effective\":\"2023-01-01\",\"expiration\":\"2039-12-31\",\"mailOrderPharmacy\":\"SAT\",\"planBenefitId\":\"233559\",\"planId\":\"TDMSHLPLNM\",\"retail90DaySupplyProgram\":false,\"maintenanceChoiceIndicator\":false},{\"active\":true,\"deliverySystem\":3,\"effective\":\"2023-01-01\",\"expiration\":\"2039-12-31\",\"planBenefitId\":\"-666\",\"planId\":\"TDMSHLPLN\",\"retail90DaySupplyProgram\":false,\"maintenanceChoiceIndicator\":false}],\"prefPharmInd\":\"N\"}";
        GetPlanDetailsResponse planDtlsResponse = serviceUtils.fromJson(jsonPlanDtlsResp, GetPlanDetailsResponse.class);
        lenient().when(restService.execute(eq("crm-service"), eq("getPlanDetails"), eq(request),
                eq(GetPlanDetailsResponse.class), any(HttpHeaders.class), isNull()
        )).thenReturn(planDtlsResponse);
    }
    @Test
    public void testPatientInfo() {
        DrugDetailsV2Request patientRequest = new DrugDetailsV2Request();
        patientRequest.setId("57226202");
        patientRequest.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        MemberInfoResponse patientInfo = crmService.getPatientInfo(patientRequest, "");
        assertEquals(57226202, patientInfo.getBeneficiary().getBeneficiaryId());
    }

    @Test
    public void testPatientInfoReturnNoDataAvailableException() {
        DrugDetailsV2Request patientRequest = new DrugDetailsV2Request();
        patientRequest.setId("57226202");
        patientRequest.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        when(restService.execute(any(), any(), any(), any())).thenThrow(new RuntimeException());
        MemberInfoResponse patientInfo = crmService.getPatientInfo(patientRequest, "");
        assertEquals(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusCode(), patientInfo.getStatusCode());
    }

    // @Test
    public void testPlanDetails() {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        GetPlanDetailsResponse getPlanDetailsResponse = crmService.getV1PlanDetails(request, "");
        assertEquals(57226202, (int) getPlanDetailsResponse.getBeneficiaryKey().getCardholderInternalID());
    }

    @Test
    public void testPlanDetailsReturnNoDataAvailable() {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        when(restService.execute(any(), any(), any(), any())).thenThrow(new RuntimeException());
        GetPlanDetailsResponse getPlanDetailsResponse = crmService.getV1PlanDetails(request, "");
        assertEquals(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusCode(), getPlanDetailsResponse.getStatusCode());
    }


    @Test
    public void testFamilyInfo() throws ApiException {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("13654368");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        String jsonFamilyResp = "{\"id\":\"13654368\",\"statusCode\":\"0000\",\"statusDescription\":\"Success\",\"familyMemberList\":[{\"firstName\":\"STANLEY\",\"lastName\":\"LEGASPI\",\"middleName\":\"\",\"gender\":\"Male\",\"dateOfBirth\":\"01/01/1968\",\"familyMemberInternalD\":\"13654369\",\"externalID\":\"X7604277402\",\"underAgeMinor\":0,\"personCode\":\"002\",\"primary\":false,\"registered\":true,\"relationShipCode\":2,\"securityOptions\":{\"id\":\"13654369\",\"orderMyRefills\":false,\"viewMyOrders\":false,\"viewMyPrescriptionHistory\":false,\"viewSensitiveMedicationsAllowed\":true,\"viewMinorSensitiveMedicationsBlocked\":false,\"fastStart\":false,\"viewPriorAuthorizationStatus\":false,\"requestMyCoverageException\":false},\"viewMinorSensitiveMedicationsBlocked\":false,\"viewSensitiveMedicationsAllowed\":true},{\"firstName\":\"AMANDA\",\"lastName\":\"LEGASPI\",\"middleName\":\"\",\"gender\":\"Female\",\"dateOfBirth\":\"01/01/2014\",\"familyMemberInternalD\":\"13654370\",\"externalID\":\"X7604277403\",\"underAgeMinor\":0,\"personCode\":\"003\",\"primary\":false,\"registered\":false,\"relationShipCode\":3,\"securityOptions\":{\"id\":\"13654370\",\"orderMyRefills\":false,\"viewMyOrders\":false,\"viewMyPrescriptionHistory\":false,\"viewSensitiveMedicationsAllowed\":true,\"viewMinorSensitiveMedicationsBlocked\":false,\"fastStart\":false,\"viewPriorAuthorizationStatus\":false,\"requestMyCoverageException\":false},\"viewMinorSensitiveMedicationsBlocked\":false,\"viewSensitiveMedicationsAllowed\":true}],\"idType\":\"PBM_QL_PARTICIPANT_ID_TYPE\"}";
        FamilyInfoResponse familyInfoResponse = serviceUtils.fromJson(jsonFamilyResp, FamilyInfoResponse.class);
        when(restService.execute(eq("crm-service"), eq("getFamilyDetails"), eq(request),
                eq(FamilyInfoResponse.class))).thenReturn(familyInfoResponse);
        FamilyInfoResponse familyInfoActualResponse = crmService.getFamilyDetails(request, "");
        assertTrue(familyInfoActualResponse.getId().equalsIgnoreCase("13654368"));
    }

    @Test
    public void testFamilyInfoReturnError() {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("13654368");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        when(restService.execute(any(), any(), any(), any())).thenThrow(new RuntimeException());
        Assert.assertThrows(ApiException.class, () -> crmService.getFamilyDetails(request, ""));
    }

    // @Test
    public void testMemberInfoApis() throws ExecutionException, InterruptedException {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        List<CompletableFuture<?>> tasks = crmService.makeParallelCalls(request, "");
        CompletableFuture.allOf(tasks.toArray(new CompletableFuture[0])).join();
        GetPlanDetailsResponse planDetailsResponse = (GetPlanDetailsResponse) tasks.get(1).get();
        assertEquals(57226202, (int) planDetailsResponse.getBeneficiaryKey().getCardholderInternalID());
    }

    @Test
    public void getV2PlanDetailsReturnsCorrectResponse() {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        GetPlanDetailsListResponse mockResponse = new GetPlanDetailsListResponse();
        GetPlanDetailsResponse planDetailsResponse = new GetPlanDetailsResponse();
        planDetailsResponse.setBeneficiaryKey(new BeneficiaryKey());
        mockResponse.setPlanDetailsList(Arrays.asList(planDetailsResponse));
        when(restService.execute(
                eq("crm-service"),
                eq("getPlanDetailsV2"),
                eq(request),
                eq(GetPlanDetailsListResponse.class),
                any(HttpHeaders.class),
                isNull()
        )).thenReturn(mockResponse);
        GetPlanDetailsResponse result = crmService.getV2PlanDetails(request, "");
        assertNotNull(result);
        assertEquals(planDetailsResponse, result);
    }

    @Test
    public void getV2PlanDetailsReturnsNoDataWhenPlanDetailsListIsEmpty() {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        GetPlanDetailsListResponse mockResponse = new GetPlanDetailsListResponse();
        mockResponse.setPlanDetailsList(Collections.emptyList());
        when(restService.execute(eq("crm-service"), eq("getPlanDetailsV2"), eq(request), eq(GetPlanDetailsListResponse.class)))
                .thenReturn(mockResponse);
        GetPlanDetailsResponseV2 result = crmService.getV2PlanDetails(request, "");
        assertNull(result);
    }

    @Test
    public void getV2PlanDetailsReturnsFirstPlanDetail() {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        GetPlanDetailsListResponse mockResponse = new GetPlanDetailsListResponse();
        GetPlanDetailsResponse planDetailsResponse = new GetPlanDetailsResponse();
        planDetailsResponse.setBeneficiaryKey(new BeneficiaryKey());
        mockResponse.setPlanDetailsList(Arrays.asList(planDetailsResponse));
        when(restService.execute(
            eq("crm-service"),
            eq("getPlanDetailsV2"),
            eq(request),
            eq(GetPlanDetailsListResponse.class),
            any(HttpHeaders.class),
            isNull()
        )).thenReturn(mockResponse);
        GetPlanDetailsResponse result = crmService.getV2PlanDetails(request, "");
        assertNotNull(result);
        assertEquals(planDetailsResponse, result);
    }

    @Test
    public void getV2PlanDetailsReturnsNullWhenPlanDetailsListIsEmpty() {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        GetPlanDetailsListResponse mockResponse = new GetPlanDetailsListResponse();
        mockResponse.setPlanDetailsList(Collections.emptyList());
        when(restService.execute(eq("crm-service"), eq("getPlanDetailsV2"), eq(request), eq(GetPlanDetailsListResponse.class)))
                .thenReturn(mockResponse);
        GetPlanDetailsResponse result = crmService.getV2PlanDetails(request, "");
        assertNull(result);
    }

    @Test
    public void getV2PlanDetailsReturnsNullWhenPlanDetailsListIsNull() {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        GetPlanDetailsListResponse mockResponse = new GetPlanDetailsListResponse();
        mockResponse.setPlanDetailsList(null);
        when(restService.execute(eq("crm-service"), eq("getPlanDetailsV2"), eq(request), eq(GetPlanDetailsListResponse.class)))
                .thenReturn(mockResponse);
        GetPlanDetailsResponse result = crmService.getV2PlanDetails(request, "");
        assertNull(result);
    }
    @Test
    public void getV2PlanDetailsHandlesException() {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        when(restService.execute(eq("crm-service"), eq("getPlanDetailsV2"), eq(request), eq(GetPlanDetailsListResponse.class)))
                .thenThrow(new RuntimeException());
        GetPlanDetailsResponseV2 result = crmService.getV2PlanDetails(request, "");
        assertNull(result);
    }

}
