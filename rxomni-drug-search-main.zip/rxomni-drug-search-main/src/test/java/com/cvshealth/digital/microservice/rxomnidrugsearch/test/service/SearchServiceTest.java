package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.api.ApiNoDataAvailableException;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.ClientConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.DrugConditionConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiErrorStatus;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchRequestDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.Drug;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.ElasticIndexInfo;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.*;
import com.cvshealth.digital.microservice.rxomnidrugsearch.test.data.TestHelper;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.ConditionValidator;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.QueryHelper;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.assertj.core.util.Maps;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.Query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

import static com.cvshealth.digital.microservice.rxomnidrugsearch.test.data.TestHelper.*;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class SearchServiceTest extends BaseIntegrationTest{
    @Mock
    private ElasticsearchOperations elasticsearchOperations;

    @Mock
    private SearchConfig searchConfig;

    @Mock
    private ClientConfig clientConfig;

    @InjectMocks
    private SearchService searchService;

    @Mock
    private FuzzySearchService fuzzySearchService;

    @Mock
    private ElasticFallbackService elasticFallbackService;

    @Mock
    private ConditionSearchService conditionSearchService;

    @Mock
    private DrugConditionConfig drugConditionConfig;

    @Mock
    private QueryHelper queryHelper;

    @Mock
    private AIMLSuggestionService aimlSuggestionService;
    ServiceUtils serviceUtils = new ServiceUtils(getObjectMapper());

    @BeforeEach
    void setup() {
        lenient().when(searchConfig.getIndexName()).thenReturn("t_rep_drug");
        lenient().when(searchConfig.getTotalRecords()).thenReturn(1L);
        lenient().when(searchConfig.isConditionSearchEnabled()).thenReturn(false);
        lenient().when(searchConfig.isFallbackEnabled()).thenReturn(false);
        lenient().when(queryHelper.buildNgramQuery(Mockito.eq(TestHelper.LIPATOR))).thenReturn(NativeQuery.builder().build());
        lenient().when(queryHelper.buildNgramQuery(Mockito.eq("lip%^&#!@$tor"))).thenReturn(NativeQuery.builder().build());
        lenient().when(queryHelper.buildNgramQuery(Mockito.eq("STATIN"))).thenReturn(NativeQuery.builder().build());
        lenient().when(queryHelper.buildNgramQuery(Mockito.eq("SILDENAFIL CITRATE"))).thenReturn(NativeQuery.builder().build());
    }

    @Test
    public void testHealthSearchType() throws ApiException {
        when(searchConfig.isConditionSearchEnabled()).thenReturn(true);
        when(drugConditionConfig.getConditions()).thenReturn(Maps.newHashMap("abc", Lists.newArrayList("test")));
        Drug lipitorRecordData = serviceUtils.fromJson(LIPITOR_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(lipitorRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        SearchResponseDto responseDto = searchService.getSearch(SearchRequestDto.builder().searchType(SearchConstants.HEALTH_API)
                .name(TestHelper.LIPATOR).clientName("").build());

        assertTrue(responseDto.getDrugs().stream()
                .anyMatch(x -> x.getDrugName().equalsIgnoreCase(TestHelper.LIPITOR)));
        assertEquals("200", responseDto.getStatusCode());
    }

    @Test
    public void testDrugSearchReturnNoRecords() {
        when(searchConfig.isConditionSearchEnabled()).thenReturn(true);
        when(drugConditionConfig.getConditions()).thenReturn(Maps.newHashMap("abc", Lists.newArrayList("test")));
        when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList());
        SearchHits<Drug> drugHits = mock(SearchHits.class);
        when(drugHits.stream()).thenReturn(Stream.of());

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        Assert.assertThrows(ApiNoDataAvailableException.class,() -> searchService.getSearch(SearchRequestDto.builder().name(TestHelper.LIPATOR).searchType(SearchConstants.SEARCH_API).clientName("").build()));
    }

    @Test
    public void testLipitorSearchReturnMaxRecords() throws ApiException {
        when(searchConfig.isConditionSearchEnabled()).thenReturn(true);
        when(drugConditionConfig.getConditions()).thenReturn(Maps.newHashMap("abc", Lists.newArrayList("test")));
        when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()));
        Drug lipitorRecordData = serviceUtils.fromJson(LIPITOR_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(lipitorRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        SearchResponseDto responseDto = searchService.getSearch(SearchRequestDto.builder().name(TestHelper.LIPATOR).searchType(SearchConstants.SEARCH_API).clientName("").build());

        assertTrue(responseDto.getDrugs().stream()
                .anyMatch(x -> x.getDrugName().equalsIgnoreCase(TestHelper.LIPITOR)));
        assertEquals("200", responseDto.getStatusCode());
    }

    @Test
    public void testLipitorSearchReturnGPINames() throws ApiException {
        when(searchConfig.isConditionSearchEnabled()).thenReturn(true);
        when(searchConfig.getDosageEligibleClients()).thenReturn(new String[]{"CDC"});
        when(searchConfig.getTotalGPINameRecords()).thenReturn(10);
        Drug lipitorRecordData = serviceUtils.fromJson(LIPITOR_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(lipitorRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        SearchResponseDto responseDto = searchService.getSearch(SearchRequestDto.builder().name(TestHelper.LIPITOR).searchType(SearchConstants.SEARCH_API).clientName("CDC")
                .searchFilter("gpi_name").build());

        assertTrue(responseDto.getDrugs().stream()
                .anyMatch(x -> x.getDrugName().equalsIgnoreCase(TestHelper.LIPITOR)));
        assertTrue(responseDto.getDrugs().stream()
                .anyMatch(x -> x.getGpiName().equalsIgnoreCase("Lipitor Tab 10Mg")));
        assertEquals("200", responseDto.getStatusCode());
    }

    @Test
    public void testFallbackScenario() throws ApiException {
        when(searchConfig.isConditionSearchEnabled()).thenReturn(true);
        when(searchConfig.isFallbackEnabled()).thenReturn(true);
        ElasticIndexInfo elasticIndexInfo = new ElasticIndexInfo();
        elasticIndexInfo.setName("t_rep_drug");
        when(elasticFallbackService.getFallbackIndex()).thenReturn(elasticIndexInfo);
        when(drugConditionConfig.getConditions()).thenReturn(Maps.newHashMap("abc", Lists.newArrayList("test")));
        when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList())
                .thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()));

        SearchHits<Drug> drugHits1 = mock(SearchHits.class);
        when(drugHits1.stream()).thenReturn(Stream.of());

        Drug lipitorRecordData = serviceUtils.fromJson(LIPITOR_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(lipitorRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any()))
                .thenReturn(drugHits1)
                .thenReturn(drugHits);
        SearchResponseDto responseDto = searchService.getSearch(SearchRequestDto.builder().name(TestHelper.LIPATOR).searchType(SearchConstants.SEARCH_API).clientName("").build());

        assertTrue(responseDto.getDrugs().stream()
                .anyMatch(x -> x.getDrugName().equalsIgnoreCase(TestHelper.LIPITOR)));
        assertEquals("200", responseDto.getStatusCode());
    }

    @Test
    public void testConditionSearchUsingMigraine() throws ApiException {
        when(searchConfig.isConditionSearchEnabled()).thenReturn(true);
        when(drugConditionConfig.getConditions()).thenReturn(Maps.newHashMap("Migraine", Lists.newArrayList("Migraine")));
        List<DrugResponse> drugResponseLst = new ArrayList<>();
        drugResponseLst.add(DrugResponse.builder().drugName("Migraine").condition("Migraine").build());
        when(conditionSearchService.retrieveConditionDrugs(any())).thenReturn(drugResponseLst);

        try (MockedStatic<ConditionValidator> aStatic = Mockito.mockStatic(ConditionValidator.class, Mockito.CALLS_REAL_METHODS)) {
            aStatic.when(() -> ConditionValidator.lookUpCondition(Mockito.anyString(), Mockito.any()))
                    .thenReturn("drug-context:Migraine");
        }
        SearchResponseDto responseDto = searchService.getSearch(SearchRequestDto.builder().name("Migraine").searchType(SearchConstants.SEARCH_API).clientName("").build());

        assertTrue(responseDto.getDrugs().stream()
                .anyMatch(x -> x.getDrugName().equalsIgnoreCase("Migraine")));
        assertEquals("200", responseDto.getStatusCode());
    }

    @Test
    public void testStatinSearchReturnMaxRecords() throws ApiException {
        lenient().when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("ATORVASTATIN CALCIUM").build()));
        Drug atorvastatinRecordData = serviceUtils.fromJson(ATORVASTATIN_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(atorvastatinRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        SearchResponseDto responseDto = searchService.getSearch(SearchRequestDto.builder().name("STATIN").searchType(SearchConstants.SEARCH_API).clientName("").build());

        assertTrue(responseDto.getDrugs().stream()
                .anyMatch(x -> StringUtils.containsIgnoreCase(x.getDrugName(),"ATORVASTATIN")));
        assertEquals("200", responseDto.getStatusCode());
    }

    @Test
    public void testDrugWithSpecialCharsReturnRecords2() throws ApiException {
        when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()));
        Drug lipitorRecordData = serviceUtils.fromJson(LIPITOR_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(lipitorRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        SearchResponseDto responseDto = searchService.getSearch(SearchRequestDto.builder().name("lip%^&#!@$tor").searchType(SearchConstants.SEARCH_API).clientName("").build());
        assertTrue(responseDto.getDrugs().stream()
                .anyMatch(x -> StringUtils.containsIgnoreCase(x.getDrugName(),TestHelper.LIPITOR)));
        assertEquals("200", responseDto.getStatusCode());
    }

    //@Test
    public void testInvalidSearchReturnBadRequestException() {
        ApiException e = assertThrows(ApiException.class, () -> searchService.getSearch(SearchRequestDto.builder().name("----")
                .searchType(SearchConstants.SEARCH_API).clientName("").build()));
        assertEquals(ApiErrorStatus.REQUIRED_FIELD_MISSING.httpStatus().getReasonPhrase(), e.getApiError().getHttpStatus().getReasonPhrase());
    }

    @Test
    public void testEmptyStringReturnBadRequestException() {
        ApiException e = assertThrows(ApiException.class, () -> searchService.getSearch(SearchRequestDto.builder().name(" ")
                .searchType(SearchConstants.SEARCH_API).clientName("").build()));
        assertEquals(ApiErrorStatus.REQUIRED_FIELD_MISSING.httpStatus().getReasonPhrase(), e.getApiError().getHttpStatus().getReasonPhrase());
    }

    @Test
    public void testAllIntegersReturnBadRequestException() {
        ApiException e = assertThrows(ApiException.class, () -> searchService.getSearch(SearchRequestDto.builder().name("12345")
                .searchType(SearchConstants.SEARCH_API).clientName("").build()));
        assertEquals(ApiErrorStatus.REQUIRED_FIELD_MISSING.httpStatus().getReasonPhrase(), e.getApiError().getHttpStatus().getReasonPhrase());
    }

    @Test
    public void testAIMLCallForCDCWhenEnabled() throws ApiException {
        when(searchConfig.isAimlSuggestionEnabled()).thenReturn(true);
        when(searchConfig.getAimlSuggestionClients()).thenReturn(new String[]{"CDC"});
        when(searchConfig.getDosageEligibleClients()).thenReturn(new String[]{""});
        when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()));
        Drug lipitorRecordData = serviceUtils.fromJson(LIPITOR_RECORD, Drug.class);

        List<SearchHit<Drug>> hits = Lists.newArrayList(new SearchHit<>("t_rep_drug", "12978", null, 1f, null,
                new HashMap<>(), null, null, null, new ArrayList<>(), lipitorRecordData));

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(lipitorRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        when(aimlSuggestionService.getAIMLSuggestions(any(), any())).thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()));
        searchService.getSearch(SearchRequestDto.builder().name(TestHelper.LIPITOR).searchType(SearchConstants.SEARCH_API).clientName("CDC").build());
        verify(aimlSuggestionService, times(1)).getAIMLSuggestions(any(), any());
    }

    @Test
    public void testNoAIMLCallForExistingCDC() throws ApiException {
        when(searchConfig.isAimlSuggestionEnabled()).thenReturn(false);
        lenient().when(searchConfig.getAimlSuggestionClients()).thenReturn(new String[]{"CDC"});
        lenient().when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()));
        Drug lipitorRecordData = serviceUtils.fromJson(LIPITOR_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(lipitorRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        lenient().when(aimlSuggestionService.getAIMLSuggestions(any(), any())).thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()));
        searchService.getSearch(SearchRequestDto.builder().name(TestHelper.LIPITOR).searchType(SearchConstants.SEARCH_API).clientName("").build());
        verify(aimlSuggestionService, times(0)).getAIMLSuggestions(any(), any());
    }

    @Test
    public void testNoAIMLCallForCDT() throws ApiException {
        when(searchConfig.isAimlSuggestionEnabled()).thenReturn(false);
        lenient().when(searchConfig.getAimlSuggestionClients()).thenReturn(new String[]{"CDC"});
        lenient().when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()));
        Drug lipitorRecordData = serviceUtils.fromJson(LIPITOR_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(lipitorRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        searchService.getSearch(SearchRequestDto.builder().name(TestHelper.LIPITOR).searchType(SearchConstants.SEARCH_API).clientName("").build());
        verify(aimlSuggestionService, times(0)).getAIMLSuggestions(any(), any());
    }

    @Test
    public void testCDTApiFirstCallForSildenafil() throws ApiException {
        when(searchConfig.isAimlSuggestionEnabled()).thenReturn(false);
        when(searchConfig.getDosageEligibleClients()).thenReturn(new String[]{""});
        ConditionSearchService conidtionMock = mock(ConditionSearchService.class);
        lenient().when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("SILDENAFIL CITRATE").build()));
        Drug sildenafilRecordData = serviceUtils.fromJson(SILDENAFIL_CDT_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(sildenafilRecordData);
        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);

        // Verify condition search should not call for CDT, only CDC calls.
        verify(conidtionMock, times(0)).retrieveConditionDrugs(any());
        SearchResponseDto response = searchService.getSearch(SearchRequestDto.builder().name("Sildenafil").searchType(SearchConstants.SEARCH_API).clientName("CDT").drugDosageDetailsFlag("false").build());
        long drugCount = response.getDrugs().stream().filter(a -> StringUtils.containsIgnoreCase(a.getDrugName(), "Sildenafil")).count();
        assertEquals(1, drugCount);
    }

    @Test
    public void testCDTApiSecondCallForSildenafil() throws ApiException {
        when(searchConfig.isAimlSuggestionEnabled()).thenReturn(false);
        when(searchConfig.getDosageEligibleClients()).thenReturn(new String[]{""});
        when(fuzzySearchService.getFuzziSearch(any(), eq(false)))
                .thenReturn(Lists.newArrayList(DrugResponse.builder().drugName("SILDENAFIL CITRATE").build()));
        Drug sildenafilRecordData = serviceUtils.fromJson(SILDENAFIL_CDT_RECORD, Drug.class);

        SearchHits<Drug> drugHits = mock(SearchHits.class);
        SearchHit<Drug> drug1 = mock(SearchHit.class);
        Stream<SearchHit<Drug>> drugHitsStream = Stream.of(drug1);

        when(drugHits.stream()).thenReturn(drugHitsStream);
        when(drug1.getContent()).thenReturn(sildenafilRecordData);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        SearchResponseDto response = searchService.getSearch(SearchRequestDto.builder().name("SILDENAFIL CITRATE").searchType(SearchConstants.SEARCH_API).clientName("CDT").drugDosageDetailsFlag("true").build());
        List<DrugResponse> drugs = response.getDrugs();
        assertEquals(1, drugs.size());
        Assert.assertTrue(drugs.get(0).getDrugName().equalsIgnoreCase("SILDENAFIL CITRATE"));
    }
}
