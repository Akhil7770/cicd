package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import lombok.Data;

import java.util.List;

@Data
public class DrugDetailsRequest {
    private List<String> ndcIdList;
}
