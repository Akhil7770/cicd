package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiErrorStatus;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.HealthCheckException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.HealthCheckResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchRequestDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchUtils;
import com.cvshealth.digital.framework.service.logging.service.CvsLogger;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

import static com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants.*;

@Service
@Slf4j
@AllArgsConstructor
public class ElasticSearchHealthCheckService {

    @Autowired
    private SearchConfig searchConfig;

    @Autowired
    private SearchService searchService;

    public HealthCheckResponseDto getESHealthCheck() throws HealthCheckException {
        SearchResponseDto searchResponse;
        try{
            List<String> drugNames = Arrays.asList(searchConfig.getDrugNames().split(","));
            searchResponse = searchService.getSearch(SearchRequestDto.builder().name(drugNames.get(SearchUtils.getRandomNumber(drugNames.size()))).searchType(HEALTH_API)
                    .clientName("").build());
        }catch(Exception e){
            CvsLogger.error("Elastic Health check failed for reason :" + e.getMessage());
            throw getHealthCheckException();
        }

        if(CollectionUtils.isEmpty(searchResponse.getDrugs())){
            CvsLogger.error("Elastic Health check failed, No Drugs found");
            throw getHealthCheckException();
        }

        return HealthCheckResponseDto.builder().status(UP).build();
    }

    private HealthCheckException getHealthCheckException() {
        return new HealthCheckException(DOWN, ApiErrorStatus.INTERNAL_SERVER_ERROR.httpStatus());
    }
}
