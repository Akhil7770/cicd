/**
 * CVS Health
 */
package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

/**
 * Hash code.
 *
 * @return the int
 */

/**
 * Instantiates a new token model.
 */

/**
 * Instantiates a new token model.
 *
 * @param token_type   the token type
 * @param access_token the access token
 * @param expires_in   the expires in
 * @param scope        the scope
 * @param error        the error
 */

/**
 * Sets the error.
 *
 * @param error the new error
 */

public class TokenModel {

	public String token_type;
	public int expires_in;
	public int ext_expires_in;
	public String access_token;

	public String getToken_type() {
		return token_type;
	}

	public void setToken_type(String token_type) {
		this.token_type = token_type;
	}

	public int getExpires_in() {
		return expires_in;
	}

	public void setExpires_in(int expires_in) {
		this.expires_in = expires_in;
	}

	public int getExt_expires_in() {
		return ext_expires_in;
	}

	public void setExt_expires_in(int ext_expires_in) {
		this.ext_expires_in = ext_expires_in;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

}