package com.cvshealth.digital.microservice.rxomnidrugsearch.exception;

import org.springframework.http.HttpStatus;

public class HealthCheckException extends Exception {
  private static final long serialVersionUID = 1L;

  public HttpStatus getHttpStatus() {
    return httpStatus;
  }

  private final HttpStatus httpStatus;

  public HealthCheckException(String message, HttpStatus httpStatus) {
    super(message);
    this.httpStatus = httpStatus;
  }
}
