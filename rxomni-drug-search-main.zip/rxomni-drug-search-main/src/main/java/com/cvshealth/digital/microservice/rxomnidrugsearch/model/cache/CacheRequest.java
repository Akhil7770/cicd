package com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode
@Data
public class CacheRequest {
	
	private RequestMetaData requestMetaData;
	private RequestPayloadData requestPayloadData;
	
}
