package com.cvshealth.digital.microservice.rxomnidrugsearch.service;
 
import java.net.URI;

import java.util.HashMap;

import java.util.Map;

import java.util.stream.Collectors;
 
import com.cvshealth.digital.framework.service.rest.RestHttpService;

import com.cvshealth.digital.framework.service.rest.RestRequestInfo;

import com.cvshealth.digital.framework.service.rest.RestService;

import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;

import com.cvshealth.digital.framework.starter.exception.model.FaultTypes;

import com.cvshealth.digital.framework.starter.utils.ServiceUtils;

import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiErrorStatus;

import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiException;

import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyTherapeuticClasses;

import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.TokenModel;

import com.cvshealth.digital.microservice.rxomnidrugsearch.util.OAuthTokenService;
 
import org.apache.http.client.utils.URIBuilder;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;

import org.springframework.http.HttpEntity;

import org.springframework.http.HttpHeaders;

import org.springframework.http.HttpMethod;

import org.springframework.http.MediaType;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;
 
@Service

public class GetFormularyDrugClassSearchService {
 
	@Value("${service.formularyDrugSearchEndPoint}")

	private String formularyDrugSearchEndPoint;
 
	/** The rest service. */

	@Autowired

	private RestService restService;
 
	/** The oauth token service. */

	@Autowired

	private OAuthTokenService oAuthTokenService;

	@Autowired

	private ServiceUtils serviceUtils;
 
	public FormularyTherapeuticClasses getFormularyDrugClassSearch(String drugClassName, String page, String pageSize)

			throws ApiException {

		String finalResponse = null;

		try {

			// Build URI with parameters

			drugClassName = org.springframework.web.util.HtmlUtils.htmlUnescape(drugClassName);

			URI uri = new URIBuilder(formularyDrugSearchEndPoint).setParameter("therapeuticClass", drugClassName)

					.setParameter("page", page).setParameter("pageSize", pageSize).build();

			TokenModel token = oAuthTokenService.getAuthToken();

			HttpHeaders headers = new HttpHeaders();

			headers.add("Authorization", "Bearer " + token.getAccess_token());

			headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);

			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
 
			// Set URL manually without service or operation name

			// NOTE: As service and operation is not used, it will not pull or override

			// config from properties file

			RestRequestInfo requestInfo = new RestRequestInfo();

			requestInfo.setUri(uri);

			requestInfo.setHttpMethod(HttpMethod.GET);

			requestInfo.setHeaders(headers);

			ResponseEntity<String> response = ((RestHttpService) restService).executeHttpRequest(requestInfo, "");

			finalResponse = response.getBody();
 
		} catch (Exception e) {

			throw new ApiException(ApiErrorStatus.INTERNAL_SERVER_ERROR.reason(),

					ApiErrorStatus.INTERNAL_SERVER_ERROR.httpStatus());

		}
 
		return serviceUtils.fromJson(finalResponse, FormularyTherapeuticClasses.class);
 
	}

}
