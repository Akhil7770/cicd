package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import com.cvshealth.digital.framework.service.rest.RestHttpService;
import com.cvshealth.digital.framework.service.rest.RestRequestInfo;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiErrorStatus;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyDrugNameSearch;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyTherapeuticClasses;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.TokenModel;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.OAuthTokenService;

import org.apache.http.client.utils.URIBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;

@Service
public class FormularyDrugNameSearchService {

	@Value("${service.formularyDrugNameSearchServiceEndPoint}")
	private String formularyDrugNameSearchServiceEndPoint;

	/** The rest service. */
	@Autowired
	private RestService restService;

	/** The oauth token service. */
	@Autowired
	private OAuthTokenService oAuthTokenService;
	@Autowired
	private ServiceUtils serviceUtils;

	public FormularyDrugNameSearch fetchFormularyDrugNameSearch(String drugName, String searchType, String page,
			String pageSize) throws ApiException {
		String finalResponse = null;

		try {
			drugName = org.springframework.web.util.HtmlUtils.htmlUnescape(drugName);
			URI uri = new URIBuilder(formularyDrugNameSearchServiceEndPoint).setParameter("drugName", drugName)
					.setParameter("searchType", searchType).setParameter("pageSize", pageSize).build();
			TokenModel token = oAuthTokenService.getAuthToken();
			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Bearer " + token.getAccess_token());
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
			RestRequestInfo requestInfo = new RestRequestInfo();
			requestInfo.setUri(uri);
			requestInfo.setHttpMethod(HttpMethod.GET);
			requestInfo.setHeaders(headers);
			ResponseEntity<String> response = ((RestHttpService) restService).executeHttpRequest(requestInfo, "");
			finalResponse = response.getBody();
		} catch (Exception e) {
			throw new ApiException(ApiErrorStatus.INTERNAL_SERVER_ERROR.reason(),
					ApiErrorStatus.INTERNAL_SERVER_ERROR.httpStatus());
		}

		return serviceUtils.fromJson(finalResponse, FormularyDrugNameSearch.class);
	}

}