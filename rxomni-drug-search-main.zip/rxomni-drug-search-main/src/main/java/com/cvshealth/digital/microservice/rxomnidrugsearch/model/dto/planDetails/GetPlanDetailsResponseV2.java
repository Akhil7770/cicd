package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails;

@lombok.Data
public class GetPlanDetailsResponseV2 extends GetPlanDetailsV2Response {

    /** The cag. */
    private String cag;

}