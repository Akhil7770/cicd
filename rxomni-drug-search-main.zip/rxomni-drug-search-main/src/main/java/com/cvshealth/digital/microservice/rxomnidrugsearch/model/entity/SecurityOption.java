package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

@lombok.Data
public class SecurityOption implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private long id;
    private boolean orderMyRefills;
    private boolean viewMyOrders;
    private boolean viewMyPrescriptionHistory;
    private boolean viewSensitiveMedicationsAllowed;
    private boolean viewMinorSensitiveMedicationsBlocked;
    private boolean fastStart;
    private boolean viewPriorAuthorizationStatus;
    private boolean requestMyCoverageException;
}
