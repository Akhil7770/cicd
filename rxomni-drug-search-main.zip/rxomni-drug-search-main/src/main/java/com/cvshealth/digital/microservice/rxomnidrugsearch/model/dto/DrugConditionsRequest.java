package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import lombok.Data;

@Data
public class DrugConditionsRequest {

    private String ndcId;
    
}