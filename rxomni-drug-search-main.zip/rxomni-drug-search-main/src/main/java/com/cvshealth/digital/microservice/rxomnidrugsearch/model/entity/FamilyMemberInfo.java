package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FamilyMemberInfo {

    String firstName;
    String id;
    String idType;
    String lastName;

    String middleName;
    String gender;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern="MM/dd/yyyy")
    Date dateOfBirth;
    String familyMemberInternalD;
    String cardholderInternalID;
    String externalID;
    short underAgeMinor;
    String linkedInternalID;
    String personCode;
    boolean primary;
    boolean registered;
    int relationShipCode;

    List<FamilyMemberInfo> familyMembersList;
    @JsonIgnore
    Long participantId;
    SecurityOption securityOptions;

}
