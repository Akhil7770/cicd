package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FDBDrugConditionItem {

    @JsonProperty("DrugID")
    private String drugId;

    @JsonProperty("DrugConceptType")
    private String drugConceptType;

    @JsonProperty("DrugDesc")
    private String drugDesc;

    @JsonProperty("DXID")
    private String dxid;

    @JsonProperty("ConditionID")
    private String conditionId;

    @JsonProperty("ConditionType")
    private String conditionType;

    @JsonProperty("ConditionTypeDesc")
    private String conditionTypeDesc;

    @JsonProperty("ConditionDesc")
    private String conditionDesc;

    @JsonProperty("IndicationLabeledCode")
    private String indicationLabeledCode;

    @JsonProperty("IndicationLabeledCodeDesc")
    private String indicationLabeledCodeDesc;

    @JsonProperty("IndicationProxyPredictorCode")
    private String indicationProxyPredictorCode;

    @JsonProperty("IndicationProxyPredictorCodeDesc")
    private String indicationProxyPredictorCodeDesc;

    @JsonProperty("HitConditionID")
    private String hitConditionId;

    @JsonProperty("HitConditionDesc")
    private String hitConditionDesc;

    @JsonProperty("HitConditionNavCode")
    private String hitConditionNavCode;

    @JsonProperty("HitConditionNavCodeDesc")
    private String hitConditionNavCodeDesc;

    @JsonProperty("HitDrugDesc")
    private String hitDrugDesc;

}