package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

import java.util.List;

@Data
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class MedispanDetail {


	@JsonProperty(value = "genericName")
	private String genericName;

	@JsonProperty(value = "therapeuticCategory")
	private String therapeuticCategory;

	@JsonProperty(value = "therapeuticClass")
	private String therapeuticClass;     

}
