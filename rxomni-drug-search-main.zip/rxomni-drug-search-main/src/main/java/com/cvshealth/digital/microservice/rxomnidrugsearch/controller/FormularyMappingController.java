package com.cvshealth.digital.microservice.rxomnidrugsearch.controller;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.ApiErrorResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FetchFormularyMappingResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyMapping;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.FetchFormularyMappingService;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/microservices/rxomni-drug-search")
public class FormularyMappingController {

	@Autowired
	private FetchFormularyMappingService fetchFormularyMappingService;

	@GetMapping(value = "/drug/search/v1/fetchFormularyMapping", produces = MediaType.APPLICATION_JSON_VALUE)
	@Tag(name = "Search")
	@Operation(summary = "fetchFormularyMapping", description = "Get Formulary Mapping Information")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Success Response", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = FetchFormularyMappingResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }),
			@ApiResponse(responseCode = "404", description = "No Drugs Found", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }) })
	@CrossOrigin(origins = { "cvshealth.com", "caremark.com", "cvs.com" })
	public ResponseEntity<FormularyMapping[]> fetchFormularyMapping(
			@RequestParam(value = "clientId", required = true) String clientId)
			throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
		FormularyMapping[] res = fetchFormularyMappingService.fetchFormularyMapping(clientId);
		return new ResponseEntity<>(res, HttpStatus.OK);
	}

}
