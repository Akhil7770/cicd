package com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode
@Data
public class KeyValueData {
	
	private String key;
	
	@JsonProperty(required = false)
	private String value;

}
