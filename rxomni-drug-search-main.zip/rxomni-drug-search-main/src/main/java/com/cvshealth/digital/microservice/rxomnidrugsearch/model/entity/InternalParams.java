package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import lombok.Data;

@Data
public class InternalParams {

    private long personalizationId;
}
