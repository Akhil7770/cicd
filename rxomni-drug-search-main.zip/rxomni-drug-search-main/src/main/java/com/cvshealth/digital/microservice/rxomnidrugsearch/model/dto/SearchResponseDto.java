package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data

@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchResponseDto {
  @JsonProperty("statusCode")
  private String statusCode;

  @JsonProperty("statusDescription")
  private String statusDescription;

  private List<DrugResponse> drugs;

  private SearchByNdcDrugResponse drugInfo;

  private List<String> drugConditions;
  
}
