package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

import java.util.List;

@Data
@JsonInclude(value = JsonInclude.Include.NON_NULL)

public class CoverageTier {

	@JsonProperty(value = "tierNumber")
	private int tierNumber;

	@JsonProperty(value = "tierCode")
	private String tierCode;

	@JsonProperty(value = "tierCodeDescription")
	private String tierCodeDescription;
	
	@JsonProperty(value = "pdlCode")
	private String pdlCode;

	@JsonProperty(value = "pdlCodeDescription")
	private String pdlCodeDescription;

	@JsonProperty(value = "onFormulary")
	private boolean onFormulary;
	
	@JsonProperty(value = "defaultTier")
	private boolean defaultTier;

}
