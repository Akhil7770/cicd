package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude
public class ApiErrorResponseDto {
  @JsonProperty("statusCode")
  private String statusCode;

  @JsonProperty("statusDescription")
  private String statusDescription;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("fault")
  private Fault fault;

  @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
  private String errorType;

  @Data
  public static class Fault {

    @JsonProperty("type")
    private String type;

    @JsonProperty("title")
    private String title;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("errors")
    private List<Error> error;

    @Data
    public static class Error {

      @JsonProperty("type")
      private String type;

      @JsonProperty("title")
      private String title;

      @JsonProperty("field")
      private String field;

    }
  }
}
