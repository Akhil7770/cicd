package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import com.cvshealth.digital.framework.service.logging.service.CvsLogger;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.AIMLServiceRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.AIMLServiceResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.framework.service.logging.service.LogServiceContext;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@AllArgsConstructor
public class AIMLSuggestionService {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private SearchConfig searchConfig;

    @Autowired
    private ServiceUtils serviceUtils;

    public List<DrugResponse> getAIMLSuggestions(List<DrugResponse> elasticSuggestedDrugs, String name) {
        List<String> aimlSuggestedDrugs = callAIMLService(name);
        LogServiceContext.addTags("AIML_Suggestions_for_search_term",  name + " response::"+ aimlSuggestedDrugs);
        List<String> newAimlList = new ArrayList(aimlSuggestedDrugs);

        try {
            if (!aimlSuggestedDrugs.isEmpty() && !elasticSuggestedDrugs.isEmpty()) {
                if (aimlSuggestedDrugs.get(0).equalsIgnoreCase(elasticSuggestedDrugs.get(0).getDrugName()) ||
                        (elasticSuggestedDrugs.size() > 1 && aimlSuggestedDrugs.get(0).equalsIgnoreCase(elasticSuggestedDrugs.get(1).getDrugName()))) {
                    newAimlList.remove(aimlSuggestedDrugs.get(0));
                }
                if (aimlSuggestedDrugs.size() > 1 &&
                        ((elasticSuggestedDrugs.size() > 1 && aimlSuggestedDrugs.get(1).equalsIgnoreCase(elasticSuggestedDrugs.get(1).getDrugName()))
                        || aimlSuggestedDrugs.get(1).equalsIgnoreCase(elasticSuggestedDrugs.get(0).getDrugName()))) {
                    newAimlList.remove(aimlSuggestedDrugs.get(1));
                }
            }
            List<DrugResponse> aimlDrugs = elasticSuggestedDrugs.stream()
                    .filter(a -> newAimlList.stream().anyMatch(b -> b.equalsIgnoreCase(a.getDrugName())))
                    .map(c -> {
                        c.setAimlSuggested(true);
                        return c;
                    }).toList();

            //combine both elastic and aiml records and insert at position 2.
            if (elasticSuggestedDrugs.size() > 1) {
                elasticSuggestedDrugs.addAll(2, aimlDrugs);
            } else {
                elasticSuggestedDrugs.addAll(aimlDrugs);
            }
        }catch(Exception e){
            CvsLogger.error("AIMLResponse processing failed with error: "+ e.getMessage());
        }

        return elasticSuggestedDrugs;
    }

    private List<String> callAIMLService(String name) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);

        List<String> aimlSuggestedDrugs = new ArrayList<>();
        ResponseEntity<AIMLServiceResponse> aimlServiceResponse;
        try {
            aimlServiceResponse = restTemplate.postForEntity(searchConfig.getAimlServiceUrl(),
                    new HttpEntity<>(serviceUtils.toJson(AIMLServiceRequest.builder().name(name).build()), headers), AIMLServiceResponse.class);
            if(aimlServiceResponse != null && aimlServiceResponse.getBody() != null){
                AIMLServiceResponse body = aimlServiceResponse.getBody();
                if(body.getSuggestedDrugs().size()>2){
                    aimlSuggestedDrugs = body.getSuggestedDrugs().subList(0,2);
                }else{
                    aimlSuggestedDrugs = body.getSuggestedDrugs();
                }
            }
        } catch (Exception ex) {
            CvsLogger.error("AIML Service call failed with error: "+ ex.getMessage());
        }

        return aimlSuggestedDrugs;
    }

}
