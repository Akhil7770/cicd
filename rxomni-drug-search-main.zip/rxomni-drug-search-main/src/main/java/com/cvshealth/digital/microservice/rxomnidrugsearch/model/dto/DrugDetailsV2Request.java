package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DrugDetailsV2Request {
	private String id;
	private String idType;

	private String ndcId;
	private String drugName;
	private Boolean isOEMember;
	private String searchFilter;
	private String cag;

	private boolean moreNdcs;
}
