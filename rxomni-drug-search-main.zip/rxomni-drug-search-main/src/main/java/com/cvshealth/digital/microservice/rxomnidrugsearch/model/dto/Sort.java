package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

import java.util.List;

@Data
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class Sort {

    @JsonProperty(value = "empty")
    private boolean empty;

    @JsonProperty(value = "sorted")
    private boolean sorted;

    @JsonProperty(value = "unsorted")
    private boolean unsorted;


}
