package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import lombok.Data;

import java.util.ArrayList;

@Data
public class DrugV2Response {

    private String name;
    private String genericName;
    private String condition;
    private boolean generic;
    private boolean otc;

    private String uniformSystemOfClassification;

    private ArrayList<DrugDetails> drugDetailsList;


}
