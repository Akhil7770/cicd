package com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode
@Data
public class CacheResponse {

	private ResponseMetaData responseMetaData;
	private ResponsePayloadData responsePayloadData;
}
