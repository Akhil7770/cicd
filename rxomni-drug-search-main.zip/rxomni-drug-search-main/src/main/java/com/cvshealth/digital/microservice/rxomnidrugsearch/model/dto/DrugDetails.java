package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class DrugDetails {

    private String ndc11;
    private String formName;
    private String formStrengthName;
    private Double retailMostCommonlyDispensedQty;
    private Integer retailMostCommonlyPrescribedDays;
    private Double mailMostCommonlyDispensedQty;
    private Integer mailMostCommonlyPrescribedDays;
    private boolean generic;
    private String  overTheCounter;
    private int  genericCodeNumber;
    private boolean brand;
    private String nhu;
    private String genericProductId;
    private boolean maintenance;
    private boolean repack;
    private int drugEnforcementAdministrationClassCode;
    private double packageSize;
    private double strengthQuantity;
    private String orangeCode;
    private String orangeDesc;
    private boolean speciality;
    private String targeted;
    private String formulary;
    private String repIndicator;
    private List<PharmacyType> pharmacyTypes;
    private String status;
    private long retailClaimCount;
    private boolean maxDaysEligible;
    private String maxDaysSupply;
    private String strengthDescription;
    private String dosageFormTypeCodeDescription;
    private String routeName;
    private String strengthCondition;
    private String strengthUnit;
    private double strengthVolumeNumber;
    private String strengthVolumeUnit;
    private String biosimilarGroup;
    private String totalPackageQuantity;
    private String packageDescription;
}
