package com.cvshealth.digital.microservice.rxomnidrugsearch.config;

import lombok.Data;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.elc.ElasticsearchConfiguration;

import javax.net.ssl.SSLContext;
import java.io.File;

@Configuration
@ComponentScan(basePackages = { "com.cvshealth.digital.drugsearch.service" })
@Data
public class ClientConfig extends ElasticsearchConfiguration {


    @Autowired
    private SearchConfig searchConfig;

    @Override
    public ClientConfiguration clientConfiguration() {
        String[] nodes = searchConfig.getElasticSearchHost().split(",");
        try {
            return ClientConfiguration.builder()
                    .connectedTo(nodes).usingSsl(getSSLContext())
                    //.connectedTo(nodes).usingSsl(getSSLContext(), NoopHostnameVerifier.INSTANCE)
                    .withBasicAuth(searchConfig.getElasticSearchUserId(), searchConfig.getElasticSearchAuth()).build();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public SSLContext getSSLContext() throws Exception {
        SSLContextBuilder builder = SSLContexts.custom();
        builder.loadTrustMaterial(new File(searchConfig.getEnvironment().getProperty("javax.net.ssl.trustStore")),
                searchConfig.getEnvironment().getProperty("javax.net.ssl.trustStorePassword").toCharArray(),
                new TrustSelfSignedStrategy());
        return builder.build();
    }
}