package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import lombok.Data;

import java.util.Date;
@Data
public class MemberFamily {

    private long cardholderId = 0;
    private boolean isMigrated = false;
    private Date migratedDate;
    private DependentList dependentList;
}
