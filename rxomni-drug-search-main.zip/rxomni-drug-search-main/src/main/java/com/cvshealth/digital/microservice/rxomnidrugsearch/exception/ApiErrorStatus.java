package com.cvshealth.digital.microservice.rxomnidrugsearch.exception;

import com.cvshealth.digital.framework.starter.exception.model.ErrorTypes;
import com.cvshealth.digital.framework.starter.model.api.FaultSection;
import org.springframework.http.HttpStatus;

/**
 * Api Error Status Enum
 */
public enum ApiErrorStatus {
  SUCCESS("SUCCESS", HttpStatus.OK),
  REQUIRED_FIELD_MISSING("REQUIRED_FIELD_MISSING", HttpStatus.BAD_REQUEST),
  MUST_MATCH_PATTERN("MUST_MATCH_PATTERN", HttpStatus.BAD_REQUEST),
  BAD_HEADER("BAD_HEADER", HttpStatus.BAD_REQUEST),
  UNPROCESSABLE_ENTITY("UNPROCESSABLE_ENTITY", HttpStatus.UNPROCESSABLE_ENTITY),
  EXCEEDED_PARAMS("EXCEEDED_PARAMS", HttpStatus.BAD_REQUEST),
  METHOD_NOT_ALLOWED("METHOD_NOT_ALLOWED", HttpStatus.METHOD_NOT_ALLOWED),
  NOT_FOUND("NOT_FOUND", HttpStatus.NOT_FOUND),
  INTERNAL_SERVER_ERROR("INTERNAL_SERVER_ERROR", HttpStatus.INTERNAL_SERVER_ERROR),

  NDCID_NOT_FOUND("NDCID_NOT_FOUND", HttpStatus.BAD_REQUEST),

  MEMBER_NOT_FOUND("MEMBER_NOT_FOUND", HttpStatus.BAD_REQUEST),

  PLAN_DETAILS_NOT_FOUND("PLAN_DETAILS_NOT_FOUND", HttpStatus.BAD_REQUEST),

  DRUGNAME_NOT_FOUND("DRUG_NOT_FOUND", HttpStatus.BAD_REQUEST),

  INVALID_ID_ID_TYPE("INVALID_ID_ID_TYPE", HttpStatus.BAD_REQUEST),

  BAD_REQUEST("BAD_REQUEST", HttpStatus.BAD_REQUEST),
  SERVICE_UNAVAILABLE("SERVICE_UNAVAILABLE", HttpStatus.SERVICE_UNAVAILABLE),

  MAIL_ONLY_DRUG("MAIL_ONLY_DRUG", HttpStatus.UNPROCESSABLE_ENTITY);

  public static final FaultSection.ErrorsDetails DRUG_NOT_FOUND = new FaultSection.ErrorsDetails(
          ErrorTypes.DATA_ERROR.getType(), "drug not found", "");

  public static final FaultSection.ErrorsDetails REQUIRED_FIELD_MISSING_ERROR= new FaultSection.ErrorsDetails(
          ErrorTypes.INVALID_REQUEST.getType(), "REQUIRED_FIELD_MISSING", "");

  public static final FaultSection.ErrorsDetails MUST_MATCH_PATTERN_ERROR = new FaultSection.ErrorsDetails(
          ErrorTypes.MUST_MATCH_PATTERN.getType(), "MUST_MATCH_PATTERN", "");

  public static final FaultSection.ErrorsDetails NOT_FOUND_ERROR = new FaultSection.ErrorsDetails(
          ErrorTypes.DATA_ERROR.getType(), "NOT_FOUND", "");

  public static final FaultSection.ErrorsDetails SERVICE_ERROR = new FaultSection.ErrorsDetails(
          ErrorTypes.DATA_ERROR.getType(), "Search by ndc failed!", "");

  public static final FaultSection.ErrorsDetails INVALID_NDC_ID_ERROR = new FaultSection.ErrorsDetails(
          ErrorTypes.DATA_ERROR.getType(), "INVALID_ID_ID_TYPE", "");

  /**
   * Enum Fields
   */
  private final String reason;
  private final HttpStatus httpStatus;

  /**
   * Constructor
   *
   * @param reason
   * @param httpStatus
   */
  private ApiErrorStatus(String reason, HttpStatus httpStatus) {
    this.reason = reason;
    this.httpStatus = httpStatus;
  }

  /**
   * Reason
   *
   * @return reason
   */
  public String reason() {
    return this.reason;
  }

  /**
   * Http Status
   *
   * @return httpStatus
   */
  public HttpStatus httpStatus() {
    return this.httpStatus;
  }

}
