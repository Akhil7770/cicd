package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.cvshealth.digital.framework.service.logging.service.CvsLogger;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.exception.model.FaultTypes;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.CacheRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.CacheResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.KeyValueData;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.RequestData;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.RequestMetaData;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.RequestPayloadData;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;

@Service
public class CacheService {

    @Value("${service.setCache}")
    private String setCache;

    @Value("${service.getCache}")
    private String getCache;

    @Autowired
    private RestService restService;

    @Autowired
    private ServiceUtils serviceUtils;

    public String checkCache(String cacheKey, String trackingId, String context) {
        String cacheValue = "";
        try {
            CacheRequest cacheRequest = prepareCacheRequest(cacheKey, cacheValue, context, trackingId);
            CacheResponse response = callCacheEndpoint(cacheRequest, getCache, trackingId);
            if (null == response || null == response.getResponseMetaData()) {
                throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
            }

            String statusCode = response.getResponseMetaData().getStatusCode();
            if (!SearchConstants.STATUS_CODE_0000_SUCCESS.equals(statusCode)
                    && !SearchConstants.STATUS_CODE_1001.equals(statusCode)) {
                throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
            }
            if ((null != response.getResponsePayloadData().getData())
                    && (null == response.getResponsePayloadData().getData().get(0).getKey())
                    && (null == response.getResponsePayloadData().getData().get(0).getValue())) {
                throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
            }
            if (response.getResponsePayloadData().getData().get(0).getTtl() > 0
                    && !StringUtils.isEmpty(response.getResponsePayloadData().getData().get(0).getValue())) {
                cacheValue = response.getResponsePayloadData().getData().get(0).getValue();
            }
        } catch (Exception e) {
            CvsLogger.error("Cache failed: " + e.getMessage());
        }
        return cacheValue;
    }

    public void updateCache(String cacheKey, String cacheValue, String trackingId, String context) {
        try {
            CacheRequest cacheRequest = prepareCacheRequest(cacheKey, cacheValue, context, trackingId);
            CacheResponse response = callCacheEndpoint(cacheRequest, setCache, trackingId);

            if (null == response || null == response.getResponseMetaData()) {
                throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
            }
            if (!SearchConstants.STATUS_CODE_0000_SUCCESS.equals(response.getResponseMetaData().getStatusCode())) {
                throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
            }
            if ((null == response.getResponsePayloadData().getData())
                    && (null == response.getResponsePayloadData().getData().get(0).getKey())) {
                throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
            }
        } catch (ApiException e) {
            CvsLogger.error("Update cache failed: " + e.getMessage());
        }
    }

    private CacheResponse callCacheEndpoint(CacheRequest request, String url, String trackingId) {
        CacheResponse cacheResponse;
        if (null != url && url.contains("getdata")) {
            cacheResponse = restService.execute("cache-service", "get-data", request, CacheResponse.class);
        } else {
            cacheResponse = restService.execute("cache-service", "set-data", request, CacheResponse.class);
        }
        return cacheResponse;
    }

    public boolean checkForValidCacheForCommonDrugs(String cacheValue, String ndcId) {
        try {
            SearchResponseDto searchResponseDto = serviceUtils.fromJson(cacheValue, SearchResponseDto.class);
            //check drugs and details list
            if (null == searchResponseDto || CollectionUtils.isEmpty(searchResponseDto.getDrugs())) {
            	return false;
            }            
            for (DrugResponse response : searchResponseDto.getDrugs()) {
            	if (CollectionUtils.isEmpty(response.getDetailsList())) {
            		return false;
            	}
            }
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean checkForValidCacheForDrugConditions(String cacheValue, String ndcId) {
        try {
            SearchResponseDto drugConditions = serviceUtils.fromJson(cacheValue, SearchResponseDto.class);
            return drugConditions.getStatusCode().equals(ApiStatusCodes.SUCCESS.getStatusCode());
        } catch (Exception ex) {
            return false;
        }
    }

    public CacheRequest prepareCacheRequest(String cacheKey, String cacheValue, String context, String trackingId) {
        CacheRequest cacheRequest = new CacheRequest();
        RequestMetaData requestMetaData = new RequestMetaData();
        RequestPayloadData requestPayloadData = new RequestPayloadData();
        requestMetaData.setAppName(SearchConstants.APP_NAME);
        requestMetaData.setLineOfBusiness(SearchConstants.LOB);
        requestMetaData.setConversationID(trackingId);
        cacheRequest.setRequestMetaData(requestMetaData);
        RequestData requestData = new RequestData();
        KeyValueData keyData = new KeyValueData();
        keyData.setKey(cacheKey);
        if (null != cacheValue) {
            keyData.setValue(cacheValue);
        }
        List<KeyValueData> keyDataList = new ArrayList<>();
        keyDataList.add(0, keyData);
        requestData.setContext(context);
        requestData.setData(keyDataList);
        requestPayloadData.setData(requestData);
        cacheRequest.setRequestPayloadData(requestPayloadData);
        return cacheRequest;
    }

}