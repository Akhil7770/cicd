package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class AIMLServiceResponse {
    @JsonProperty(value = "drug_recommendations")
    private List<String> suggestedDrugs;
}
