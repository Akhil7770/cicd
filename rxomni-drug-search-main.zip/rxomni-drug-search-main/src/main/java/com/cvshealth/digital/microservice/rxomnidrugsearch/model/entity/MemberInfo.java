package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Date;

@Data
public class MemberInfo {
    private String eisName;

    private String externalID;

    private Integer cardholderRelationCode;

    //	private String enrollmentCode;
    private MemberEligibility eligibility;
    private String personCode;

    private String accountID;
    private String groupID;
    //	private String payerID;
    private String coverageEffectiveDate;
    private Integer benefactorClientInternalID;
    //	private Integer eligibilityProviderClientID;
    private String coverageTerminationDate;
    private long internalID;
    private InternalParams internalParams;
    private boolean primary;

    private String firstName;
    private String lastName;
    private String gender;
    private String clientName;
    private String carrierID;
    private long clientId;
    private Date dateOfBirth;
//	private long providerClientId;

    private Date planStartDate;
    private String clientCode;
    private Integer cardholderInternalID;
    private MemberFamily family;
    private Date planEffectiveDate;
    @JsonProperty("IsfuturePlan")
    private boolean futurePlan;

}
