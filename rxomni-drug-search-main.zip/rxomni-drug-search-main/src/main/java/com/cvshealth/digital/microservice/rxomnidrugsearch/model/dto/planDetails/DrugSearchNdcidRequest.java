package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails;

import lombok.Data;

@Data
public class DrugSearchNdcidRequest {
    private String id;
    private String ndcId;
    private String drugName;
    private String idType;
    private Boolean isOEMember;
    private String cag;
}