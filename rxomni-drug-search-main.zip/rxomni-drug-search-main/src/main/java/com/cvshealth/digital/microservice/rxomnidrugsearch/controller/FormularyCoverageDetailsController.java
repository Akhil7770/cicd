package com.cvshealth.digital.microservice.rxomnidrugsearch.controller;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.ApiErrorResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyCoverageDetails;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.GetFormularyCoverageDetailsResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.GetFormularyCoverageDetailsService;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/microservices/rxomni-drug-search")

public class FormularyCoverageDetailsController {

	@Autowired
	private GetFormularyCoverageDetailsService getFormularyCoverageDetailsService;

	@GetMapping(value = "/drug/search/v1/getFormularyCoverageDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@Tag(name = "Search")
	@Operation(summary = "getFormularyCoverageDetails", description = "Get Formulary Coverage Details Information")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Success Response", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = GetFormularyCoverageDetailsResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }),
			@ApiResponse(responseCode = "404", description = "No Drugs Found", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }) })
	@CrossOrigin("cvshealth.com")
	public ResponseEntity<FormularyCoverageDetails[]> getFormularyCoverageDetails(
			@RequestParam(value = "formularyId", required = true) String formularyId,
			@RequestParam(value = "drugName", required = true) String drugName)
			throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
		FormularyCoverageDetails[] res = getFormularyCoverageDetailsService.getFormularyCoverageDetails(formularyId,
				drugName);
		return new ResponseEntity<>(res, HttpStatus.OK);
	}

}