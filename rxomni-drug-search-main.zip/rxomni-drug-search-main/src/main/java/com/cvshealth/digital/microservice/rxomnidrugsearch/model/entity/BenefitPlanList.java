package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Collection;

@Data
public class BenefitPlanList {
    @JsonProperty("benefitPlan")
    private Collection<BenefitPlan> benefitPlan;
}
