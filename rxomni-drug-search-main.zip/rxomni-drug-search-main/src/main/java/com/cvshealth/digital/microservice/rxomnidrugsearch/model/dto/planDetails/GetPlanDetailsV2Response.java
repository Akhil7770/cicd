package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails;

import com.cvshealth.digital.framework.starter.model.api.ApiResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.BeneficiaryKey;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new gets the plan details response.
 */
@AllArgsConstructor

/**
 * Instantiates a new gets the plan details response.
 */
@NoArgsConstructor

/**
 * Hash code.
 *
 * @return the int
 */
@EqualsAndHashCode(callSuper = true)

/**
 * To string.
 *
 * @return the java.lang. string
 */
@lombok.Data

public class GetPlanDetailsV2Response extends ApiResponse {
    private String statusCode;
    private String statusDescription;
    /** The beneficiary key. */
    private BeneficiaryKey beneficiaryKey;

    /** The linked beneficiary key. */
    // private BeneficiaryKeyResponseObject linkedBeneficiaryKey;

    /** The primary. */
    private Boolean primary;

    /** The personalization id. */
    private Integer personalizationId;

    /** The registration opted out. */
    private Boolean registrationOptedOut;

    /** Member Eligibility. */
    private Boolean isEligible;

    /** The plan start date. */
    private String planStartDate;

    /** The early registration allowed. */
    private Boolean earlyRegistrationAllowed;

    /** The mail order pharmacy code. */
    private String mailOrderPharmacyCode;

    /** The medicare. */
    private Boolean medicare;

    /** The med B eligible. */
    private Boolean medBEligible;

    /** The aetna client. */
    private Boolean aetnaClient;

    /** The non Pbm Lob Code. */
    private String nonPbmLobCode;

    /** The person code. */
    private String personCode;

    /** The coverage effective date. */
    // private String coverageEffectiveDate;

    /** The cag. */
    private String cag;

    /** The coverage termination date. */
    //private String coverageTerminationDate;

    /** The family type. */
    private String familyType;

    /** The payer ID. */
    private String payerID;

    /** The cardholder relation code. */
    private Integer cardholderRelationCode;

    /** The enrollment code. */
    private String enrollmentCode;

    /** The eligibility provider client ID. */
    private Long eligibilityProviderClientID;

    /** The provider client ID. */
    private Long providerClientID;

    /** The is future plan. */
    private Boolean isFuturePlan;

    /** The st cob. */
    private Boolean stCob;

    /** The relation ship code. */
    private String relationShipCode;

    /** The ql mail. */
    private Boolean qlMail;

    /** The plan benefit list. */
    //private List<BenefitPlanResponseObject> planBenefitList;

    private Address address;

    private PlanCardDetail planCard;

    @JsonIgnore()
    private String csAreaCode;

    @JsonIgnore()
    private String csPhoneNumber;
    private String prefPharmInd;

    @JsonIgnore()
    private String state;

    @JsonIgnore()
    private ClientPlanGroup cpg;
}