package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails;

import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.BeneficiaryKey;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.BenefitPlan;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * rxpbm-plan-details getPlanDetails response.
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@lombok.Data
@Builder
public class GetPlanDetailsResponse extends GetPlanDetailsResponseV2 {

    private String statusCode;
    private String statusDescription;
    private BeneficiaryKey beneficiaryKey;
    private Boolean primary;
    private Integer personalizationId;
    private Boolean registrationOptedOut;
    private String planStartDate;
    private Boolean earlyRegistrationAllowed;
    private String mailOrderPharmacyCode;
    private Boolean medicare;
    private Boolean medBEligible;
    private Boolean aetnaClient;
    private String personCode;
    private String superClientCode;
    private String coverageEffectiveDate;
    private String coverageTerminationDate;
    private String familyType;
    private String payerID;
    private Integer cardholderRelationCode;
    private String enrollmentCode;
    private Long eligibilityProviderClientID;
    private Long providerClientID;
    private Boolean isFuturePlan;
    private Boolean stCob;
    private String relationShipCode;
    private boolean qlMail;
    private List<BenefitPlan> planBenefitList;
    private String cag;

}