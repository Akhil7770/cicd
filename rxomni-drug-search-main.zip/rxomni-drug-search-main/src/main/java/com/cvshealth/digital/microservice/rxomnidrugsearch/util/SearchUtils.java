package com.cvshealth.digital.microservice.rxomnidrugsearch.util;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.SearchHit;

import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.Drug;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.experimental.UtilityClass;

@UtilityClass
public class SearchUtils {

    @Autowired
    private ObjectMapper mapper;

    public <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        //Remove by drugName - branded and generic with same name.
        Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    public static String stripDrugName(String name) {
        if(StringUtils.isBlank(name)){
            return "";
        }
        return name.replaceAll(SearchConstants.DRUG_NAME_FILTER, " ");
    }

    public static String sanitizeData(String data) {
        String sanData = null;
        if (data != null) {
            sanData = data.replace('\n', ' ')
                    .replace('\r', ' ')
                    .replace('\t', ' ');
        }
        return sanData;
    }

    public static void sanitizeDrudDetailsRequest(DrugDetailsRequest drugDetailsRequest) {
        drugDetailsRequest.setNdcIdList(drugDetailsRequest.getNdcIdList()
                .stream().map(SearchUtils::sanitizeData).collect(Collectors.toList()));
    }

    public static int getRandomNumber(int size){
        //Use SecureRandom to generate random values instead of Random class or Math.random which uses weak method nextInt to produce random value
        SecureRandom secureRandom = new SecureRandom();
        return secureRandom.nextInt(size);
    }

    public static boolean filterObsoleteDrugs(SearchHit<Drug> drug){
        LocalDate currentDate = LocalDate.now();
        boolean indFlag = "1".equalsIgnoreCase(drug.getContent().getDrug_rxclm_src_flg())
                && ("Y".equalsIgnoreCase(drug.getContent().getRxclm_retail_rep_drug_ind()) || "Y".equalsIgnoreCase(drug.getContent().getRxclm_mail_rep_drug_ind()));
        boolean cond = (currentDate.isBefore(LocalDate.parse(drug.getContent().getEnd_date())) &&
                currentDate.isAfter(LocalDate.parse(drug.getContent().getEff_date())))
                || currentDate.isBefore(LocalDate.parse(drug.getContent().getRxclm_obslt_date()));
        return indFlag &&  cond;
    }

    public static boolean filterExpiredDrugs(SearchHit<Drug> drug){
        LocalDate currentDate = LocalDate.now();

        return (currentDate.isBefore(LocalDate.parse(drug.getContent().getEnd_date())) &&
                currentDate.isAfter(LocalDate.parse(drug.getContent().getEff_date())))
                || (StringUtils.isNotBlank(drug.getContent().getRxclm_obslt_date()) && currentDate.isBefore(LocalDate.parse(drug.getContent().getRxclm_obslt_date())));

    }

    public static boolean filterRetailAndMailPrice(SearchHit<Drug> drug){
        if( (drug.getContent().getRxclm_rtl_rep_drug_mc_qty()!= null && !drug.getContent().getRxclm_rtl_rep_drug_mc_qty().isEmpty()) && (drug.getContent().getRxclm_mail_rep_drug_mc_qty()!= null &&  !drug.getContent().getRxclm_mail_rep_drug_mc_qty().isEmpty()))
            return true;
        return false;
    }

    public static boolean filterRetailOrMailPrice(SearchHit<Drug> drug){
        if( (drug.getContent().getRxclm_rtl_rep_drug_mc_qty()!= null && !drug.getContent().getRxclm_rtl_rep_drug_mc_qty().isEmpty()) || (drug.getContent().getRxclm_mail_rep_drug_mc_qty()!= null &&  !drug.getContent().getRxclm_mail_rep_drug_mc_qty().isEmpty()))
            return true;
        return false;
    }

    public static boolean isRetailDrug(SearchHit<Drug> drug){
        if( (drug.getContent().getRxclm_rtl_rep_drug_mc_qty()!= null
                && !drug.getContent().getRxclm_rtl_rep_drug_mc_qty().isEmpty())
                && (drug.getContent().getRxclm_rtl_rep_drug_dy_sply_qty()!= null
                &&  !drug.getContent().getRxclm_rtl_rep_drug_dy_sply_qty().isEmpty())
        )
            return true;
        return false;
    }

    public static boolean isMailDrug(SearchHit<Drug> drug){
        if( (drug.getContent().getRxclm_mail_rep_drug_mc_qty()!= null
                && !drug.getContent().getRxclm_mail_rep_drug_mc_qty().isEmpty())
                && (drug.getContent().getRxclm_ml_rep_drug_day_sply_qty()!= null
                &&  !drug.getContent().getRxclm_ml_rep_drug_day_sply_qty().isEmpty())
        )
            return true;
        return false;
    }

    public static boolean isGeneric(SearchHit<Drug> drug){
        if( drug.getContent().getGnrc_flag().equals("1") )
            return true;
        return false;
    }

    public static boolean isBrand(SearchHit<Drug> drug){
        if( drug.getContent().getGnrc_flag().equals("0") )
            return true;
        return false;
    }

    public static boolean isAIMLSearchEnabled(String clientName, String[] customClients) {
        return StringUtils.isBlank(clientName) || Arrays.stream(customClients).anyMatch(clientName::equalsIgnoreCase);
    }

    public static boolean isCashDiscountToolClientCall(String clientName, String[] customClients) {
        if(StringUtils.isNotBlank(clientName)){
            //return StringUtils.containsIgnoreCase(clientName,"CDT");
            return Arrays.stream(customClients).anyMatch(clientName::equalsIgnoreCase);
        }
        return false;
    }

    public static long formatValueToLong(String value){
        if(NumberUtils.isDigits(value)){
            return NumberUtils.toLong(value);
        }
        return 0;
    }

    public static long formatValueToLong(Long value){
        if(value != null){
            return value;
        }
        return 0;
    }

    public static double formatValueToDouble(String value){
        if(NumberUtils.isDigits(value)){
            return NumberUtils.toDouble(value);
        }
        return 0d;
    }

    public static float formatValueToFloat(String value){
        if(NumberUtils.isDigits(value)){
            return NumberUtils.toFloat(value);
        }
        return 0f;
    }

}