/**
 * CVS Health
 */
package com.cvshealth.digital.microservice.rxomnidrugsearch.util;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.cvshealth.digital.framework.service.rest.RestHttpService;
import com.cvshealth.digital.framework.service.rest.RestRequestInfo;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsEslResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyCoverageDetails;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyMapping;
import org.apache.http.client.utils.URIBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.TokenModel;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
//@ComponentScan({"com.cvshealth.digital.drugsearch.model.dto"})
public class OAuthTokenService {

	private ObjectMapper objectMapper = new ObjectMapper();


	@Value("${service.mypbmaccesstokenURL}")
	private String mypbmaccesstokenURL; 
	
	@Value("${mypbmoauth2client.scope}")
	private String scope;
	
	@Value("${mypbmoauth2client.grantType}")
	private String grantType;
	
	@Value("${mypbmoauth2client.myPBMAppId}")
	private String appId;
	
	@Value("${mypbmoauth2client.myPBMAppSecValue}")
	private String appSecValue;

	@Autowired
	private RestService restService;
	@Autowired
	ServiceUtils serviceUtils;

	private static final String SERVICE_NAME = "myPBMservices";

	private static final String OPERATION_NAME = "mypbmaccesstokenURL";
	/**
	 * Gets the auth token.
	 *
	 * @return the auth token
	 * @throws ApiException the api exception
	 */
	@Cacheable("oauthtokenkey")
	public TokenModel getAuthToken() {
		ResponseEntity<TokenModel> responseEntity = null;
		String credentials = appId.concat(":").concat(appSecValue);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("Authorization", "Basic " + new String(serviceUtils.base64Encode(credentials.getBytes())));
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		RestRequestInfo requestInfo = restService.buildRestRequestInfo(SERVICE_NAME, OPERATION_NAME,
				HttpMethod.POST, null, headers, null);
		responseEntity = restService.httpRequest(requestInfo,
				"scope=" + scope + "&grant_type=" + grantType,
				TokenModel.class);
		TokenModel tokenModel = responseEntity.getBody();
		return tokenModel;

	}

	/**
	 * Empty apic token cache.
	 */
	// @CacheEvict(value = "oauthtokenkey, oauthAncillarytokenkey", allEntries =
	// true)
	@Caching(evict = { @CacheEvict(cacheNames = "oauthtokenkey", allEntries = true),
			@CacheEvict(cacheNames = "oauthAncillarytokenkey", allEntries = true) })
	@Scheduled(fixedRateString = "${caching.spring.oauthTokenKeyTTL}")
	public void emptyApicTokenCache() {
//		CvsLogger.info("Completed emptyApicTokenCache Service :: Cache is Evicted as per TTL");
	}
}