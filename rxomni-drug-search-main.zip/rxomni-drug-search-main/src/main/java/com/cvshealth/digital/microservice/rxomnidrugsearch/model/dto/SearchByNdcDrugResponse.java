package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SearchByNdcDrugResponse {
    private String drugName;
    private String ndcId;
    private String formName;
    private String formStrengthName;
    private String gpiName;
    private String productName;
}
