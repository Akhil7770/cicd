package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import com.cvshealth.digital.framework.service.rest.RestHttpService;
import com.cvshealth.digital.framework.service.rest.RestRequestInfo;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyTherapeuticClasses;
import org.apache.http.client.utils.URIBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;

import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.exception.model.FaultTypes;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyCoverageDetails;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.TokenModel;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.OAuthTokenService;

@Service
public class GetFormularyCoverageDetailsService {

	@Value("${service.getFomularyCoverageDetailsEndPoint}")
	private String getFomularyCoverageDetailsEndPoint;

	@Autowired
	private RestService restService;

	/** The oauth token service. */
	@Autowired
	private OAuthTokenService oAuthTokenService;

	@Autowired
	private ServiceUtils serviceUtils;

	private static final String SERVICE_NAME = "myPBMservices";

	public FormularyCoverageDetails[] getFormularyCoverageDetails(String formularies, String drugName)
			throws ApiException {

		String finalResponse = null;
		try {
			drugName = org.springframework.web.util.HtmlUtils.htmlUnescape(drugName);
			URI uri = new URIBuilder(getFomularyCoverageDetailsEndPoint).setParameter("formularies", formularies).setParameter("drugName",drugName).build();
			TokenModel token = oAuthTokenService.getAuthToken();
			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Bearer " + token.getAccess_token());
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
			HttpEntity request = new HttpEntity<>(headers);
			RestRequestInfo requestInfo = new RestRequestInfo();
			requestInfo.setUri(uri);
			requestInfo.setHttpMethod(HttpMethod.GET);
			requestInfo.setHeaders(headers);
			ResponseEntity<String> response = ((RestHttpService) restService).executeHttpRequest(requestInfo, "");
			finalResponse = response.getBody();
		} catch (Exception e) {
			throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
		}
		return serviceUtils.fromJson(finalResponse, FormularyCoverageDetails[].class);
	}

}


