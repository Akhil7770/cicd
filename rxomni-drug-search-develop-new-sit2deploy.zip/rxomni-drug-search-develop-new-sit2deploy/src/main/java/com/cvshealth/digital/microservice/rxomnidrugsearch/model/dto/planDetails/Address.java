package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.extern.slf4j.Slf4j;

@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Slf4j
public class Address {

    private String name;
    private String line1 ;
    private String city;
    private String state;
    private String zip;
    private String carePhoneNumber;
    private String pharmacyPhoneNumber;



}