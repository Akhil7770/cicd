package com.cvshealth.digital.microservice.rxomnidrugsearch.controller;



import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.ApiErrorResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyTherapeuticClasses;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.GetFormularyDrugClassSearchService;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/microservices/rxomni-drug-search")
public class FormularyDrugClassSearchController {

    @Autowired
    private GetFormularyDrugClassSearchService getFormularyDrugClassSearchService;

    @GetMapping(value = "/drug/search/v1/getFormularyDrugClassSearch", produces = MediaType.APPLICATION_JSON_VALUE)
    @Tag(name = "Search")
    @Operation(summary = "getFormularyDrugClassSearch", description = "Get Drug Class Information")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Success Response", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = FormularyTherapeuticClasses.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }),
            @ApiResponse(responseCode = "404", description = "No Drug classes Found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }) })
    @CrossOrigin("cvshealth.com")
    public ResponseEntity<FormularyTherapeuticClasses> getFormularyDrugClassSearch(
            @RequestParam(value = "drugClassName", required = true) String drugClassName,
            @RequestParam(value = "page", required = false) String page,
            @RequestParam(value = "pageSize", required = false) String pageSize)
            throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {

        FormularyTherapeuticClasses formularyDrugClassSearchResponse = getFormularyDrugClassSearchService
                .getFormularyDrugClassSearch(drugClassName, page, pageSize);

        return new ResponseEntity<>(formularyDrugClassSearchResponse, HttpStatus.OK);
    }
}

