package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ElasticIndexInfo {

    @JsonProperty("i")
    private String name;
    @JsonProperty("creation.date.string")
    private String creationDate;
}
