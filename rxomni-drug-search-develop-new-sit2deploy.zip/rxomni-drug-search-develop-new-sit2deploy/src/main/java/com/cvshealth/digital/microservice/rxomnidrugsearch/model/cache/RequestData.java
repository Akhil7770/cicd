package com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode
@Data
public class RequestData {
	
	private String context;
	private List<KeyValueData> data;	

}
