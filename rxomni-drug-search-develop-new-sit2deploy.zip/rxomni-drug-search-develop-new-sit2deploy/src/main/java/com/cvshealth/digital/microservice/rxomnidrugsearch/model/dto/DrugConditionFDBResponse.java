package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class DrugConditionFDBResponse {

    @JsonProperty("ServiceCallID")
    private String serviceCallId;

    @JsonProperty("RequestedDrugID")
    private String requestedDrugId;

    @JsonProperty("offset")
    private Integer offset;

    @JsonProperty("RequestedDrugConceptType")
    private String requestedDrugConceptType;

    @JsonProperty("limit")
    private Integer limit;

    @JsonProperty("RequestedDrugDesc")
    private String requestedDrugDesc;

    @JsonProperty("TotalResultCount")
    private Integer totalResultCount;

    @JsonProperty("Items")
    private List<FDBDrugConditionItem> items;

}