package com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode
@Data
public class ResponseMetaData {
	
	private String statusCode;
    private String statusDesc;
    private String conversationID;

}
