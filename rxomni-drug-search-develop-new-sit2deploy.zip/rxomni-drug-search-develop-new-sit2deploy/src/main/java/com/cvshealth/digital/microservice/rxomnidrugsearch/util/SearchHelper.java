package com.cvshealth.digital.microservice.rxomnidrugsearch.util;

import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;

import static com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants.*;

@Slf4j
public class SearchHelper {

    public static List<DrugResponse> mergeDosageDetailsByDrugName(List<DrugResponse> nGramPartialMatchDrugList, String drugName, long totalRecords) {
        return nGramPartialMatchDrugList.stream()
                .collect(Collectors.groupingBy(DrugResponse::getDrugName, LinkedHashMap::new, Collectors.toList()))
                .values().stream()
                .map(grouped -> DrugResponse.builder()
                        .drugName(grouped.get(0).getDrugName())
                        .genericName(grouped.get(0).getGenericName())
                        .repDrugClaimCount(grouped.get(0).getRepDrugClaimCount()).score(grouped.get(0).getScore())
                        .otc(grouped.get(0).isOtc()).generic(grouped.get(0).isGeneric())
                        .condition(grouped.get(0).getCondition()).uscDescription(grouped.get(0).getUscDescription())
                        .detailsList(grouped.stream().map(s-> {
                            DrugResponse.Details details = s.getDetails();
                            details.setGpiName(capitalizeFirstLetterInWord((StringUtils.isBlank(details.getGpiName()) || !StringUtils.containsIgnoreCase(details.getGpiName(),drugName))
                                    ? details.getDrugName() + " " + details.getFormName() + " " + details.getFormStrengthName()
                                    : details.getGpiName()));
                            /*details.setGcn(SearchUtils.formatValueToLong(details.getGcn_number()));
                            details.setRetailMostCommonlyPrescribedDays(SearchUtils.formatValueToLong(details.getRetailMCPDays()));
                            details.setMailMostCommonlyPrescribedDays(SearchUtils.formatValueToLong(details.getMailMCPDays()));*/
                            return details;
                        }).filter(SearchUtils.distinctByKey(DrugResponse.Details::getNdcId))
                                .collect(Collectors.groupingBy(details ->
                                        details.getDrugName() + details.getFormName() + details.getFormStrengthName()))
                                .values()
                                .stream()
                                .map(detailsGroup -> detailsGroup.stream()
                                        .max(Comparator.comparingLong(DrugResponse.Details::getRetailClaimCount)))
                                .filter(Optional::isPresent)
                                .map(Optional::get)
                                .sorted(Comparator.comparingLong(DrugResponse.Details::getRetailClaimCount).reversed())
                                .distinct()
                                .collect(Collectors.toList())).build())
                .limit(totalRecords)
                .collect(Collectors.toList());
    }

    public static List<DrugResponse> mergeDosageDetailsByGpiNames(List<DrugResponse> nGramPartialMatchDrugList, String drugName, long totalRecords) {
        List<DrugResponse> drugsByBrandNames = mergeDosageDetailsByDrugName(nGramPartialMatchDrugList, drugName, totalRecords);
        return drugsByBrandNames.stream()
                .flatMap(c -> c.getDetailsList().stream())
                .toList().stream()
                .map(x -> DrugResponse.builder()
                        .drugName(x.getDrugName())
                        .genericName(x.getGenericName())
                        .gpiName(x.getGpiName())
                        .generic(x.isGeneric())
                        .detailsList(Lists.newArrayList(x))
                        .otc(x.isOtc()).build())
                .filter(SearchUtils.distinctByKey(DrugResponse::getGpiName))
                .limit(totalRecords)
                .collect(Collectors.toList());
    }

    public static String capitalizeFirstLetterInWord(String name){
//        return Arrays.stream(name.split(SPACE))
//                .map(word ->
//                        word.trim().substring(0, 1).toUpperCase() + word.substring(1).toLowerCase())
//                .collect(Collectors.joining(SPACE));
        if(name == null){
            return "";
        }
        name = name.toLowerCase();
        return name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    public static List<DrugResponse> mergeDosageDetailsByGenericName(List<DrugResponse> drugDetailsList, long totalRecords,
                                                                     String isCDTDosageDetailsCall) {
        return drugDetailsList.stream()
                .collect(Collectors.groupingBy(drugResponse -> {
                    //String[] name = drugResponse.getGenericName().split("\\s", 2);
                    String name = new StringTokenizer(drugResponse.getGenericName(), "(").nextToken();
                    return StringUtils.trim(name+drugResponse.isGeneric());
                }, LinkedHashMap<String, List<DrugResponse>>::new, Collectors.toList()))
                .values().stream()
                .map(grouped -> { DrugResponse response = DrugResponse.builder()
                                //.drugName(grouped.get(0).getDrugName()).genericName(grouped.get(0).getDrugName())
                                //.genericName(grouped.get(0).getDrugName()).genericName(grouped.get(0).getGenericName())
                                .repDrugClaimCount(grouped.get(0).getRepDrugClaimCount()).score(grouped.get(0).getScore())
                                .otc(grouped.get(0).isOtc()).generic(grouped.get(0).isGeneric())
                                .condition(grouped.get(0).getCondition()).uscDescription(grouped.get(0).getUscDescription())
                                .detailsList(grouped.stream().map(DrugResponse::getDetails)
                                        .collect(Collectors.collectingAndThen(
                                                Collectors.toMap(x -> Arrays.asList(x.getFormName(), x.getFormStrengthName()), x -> x,
                                                        BinaryOperator.maxBy(Comparator.comparing(DrugResponse.Details::getRetailClaimCount))),
                                                map -> new ArrayList<>(map.values())))
                                        .stream()
                                        .filter(SearchUtils.distinctByKey(DrugResponse.Details::getNdcId))
                                        .sorted(Comparator.comparingLong(DrugResponse.Details::getRetailClaimCount).reversed())
                                        .collect(Collectors.toList()))
                                .build();
                            response.setDetails(response.getDetailsList().get(0));
                            response.setDrugName(response.getDetailsList().get(0).getDrugName());
                            response.setGenericName(response.getDetailsList().get(0).getGenericName());
                            return response;
                        }
                ).filter(SearchUtils.distinctByKey(DrugResponse::getDrugName))
                .limit(Boolean.valueOf(isCDTDosageDetailsCall) ? 1: totalRecords)
                .collect(Collectors.toList());
    }
}
