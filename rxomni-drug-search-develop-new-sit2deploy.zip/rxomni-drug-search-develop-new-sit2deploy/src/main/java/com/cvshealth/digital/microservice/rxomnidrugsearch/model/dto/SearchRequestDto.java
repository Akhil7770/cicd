package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchRequestDto {
    private String name;
    private String searchType;
    private String clientName;
    private String searchFilter;

    //Flag used to retrieve ndcIds given gpiCode.
    private boolean moreNdcs;

    //CDT flag
    //false - retrieves only one drug with highest retail count, filtered based on the generic name.
    //true - retrieve the selected  drugs ALL form and dosage details
    private String drugDosageDetailsFlag;
}
