package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.stereotype.Service;

import com.cvshealth.digital.framework.service.logging.service.CvsLogger;
import com.cvshealth.digital.framework.service.logging.service.LogServiceContext;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.Drug;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.DrugUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.QueryHelper;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FuzzySearchService {

    @Autowired
    private SearchConfig searchConfig;

    @Autowired
    private ElasticsearchOperations elasticsearchOperations;

    @Autowired
    private QueryHelper queryHelper;


    @Autowired
    private DrugUtils drugUtils;

    public List<DrugResponse> getFuzziSearch(String drugName, boolean isDosageDetailsRequired) {
        LogServiceContext.addTags( "getFuzziSearchFor", drugName);
        return sortFuzzyDruglist(getFuzziDrugList(drugName, "2", isDosageDetailsRequired), drugName);
    }

    private List<DrugResponse> getFuzziDrugList(String drugName, String fuzziness, boolean isDosageDetailsRequired) {
        /*QueryBuilder queryBuilder = QueryBuilders.matchQuery(searchConfig.getNGramFieldName(), drugName)
                //.analyzer("standard")
                .fuzziness(fuzziness);*/

        try {
            // 2. Execute search
            /*SearchHits<Drug> drugHits = elasticsearchOperations.search(new NativeSearchQueryBuilder().withQuery(queryBuilder)
                    .withMaxResults(searchConfig.getMaxRecords())
                    .build(), Drug.class, IndexCoordinates.of(searchConfig.getIndexName()));*/
            SearchHits<Drug> drugHits = elasticsearchOperations.search(queryHelper.buildFuzzyQuery(drugName),
                    Drug.class, IndexCoordinates.of(searchConfig.getIndexName()));

            // 3. Map searchHits to drug list
            return drugHits.stream()
                    .filter(SearchUtils::filterObsoleteDrugs)
                    .filter(x -> x.getContent().getRxclm_retail_claim_count() > 0)
                    .filter(isDosageDetailsRequired ? x -> true : SearchUtils.distinctByKey(x -> x.getContent().getBrand_name()))
                    //.limit(searchConfig.getTotalRecords())
                    .map(x -> DrugResponse.builder().drugName(x.getContent().getBrand_name()).genericName(x.getContent().getGnrc_name())
                            .repDrugClaimCount(x.getContent().getRxclm_retail_claim_count())
                            .generic("1".equals(x.getContent().getGnrc_flag()))
                            .otc(SearchConstants.OTC_SINGLE_SOURCE.equalsIgnoreCase(x.getContent().getRx_otc_ind()))
                            .details(DrugResponse.Details.builder()
                                    .drugName(x.getContent().getBrand_name())
                                    .gpiName(x.getContent().getGpi_name())
                                    .genericName(x.getContent().getGnrc_name())
                                    .ndcId(x.getContent().getNdc_code())
                                    .formName(x.getContent().getDsg_form())
                                    .formStrengthName(x.getContent().getStrgh_desc())
                                    .generic("1" .equals(x.getContent().getGnrc_flag()))
                                    .otc(SearchConstants.OTC_SINGLE_SOURCE.equalsIgnoreCase(x.getContent().getRx_otc_ind()))
                                    .gcn_number(x.getContent().getGcn_nbr())
                                    .gpiCode(x.getContent().getGpi_code())
                                    .controlledSubstance(StringUtils.isNotBlank(x.getContent().getDea_code()) &&
                                            drugUtils.isControlledSubstance(Integer.parseInt(x.getContent().getDea_code())))
                                    .drugForm(x.getContent().getDrug_form())
                                    .retailClaimCount(x.getContent().getRxclm_retail_claim_count())
                                    .retailMostCommonlyDispensedQty(x.getContent().getRxclm_rtl_rep_drug_mc_qty())
                                    .retailMCPDays(x.getContent().getRxclm_rtl_rep_drug_dy_sply_qty())
                                    .gcn(SearchUtils.formatValueToLong(x.getContent().getGcn_nbr()))
                                    .mailMostCommonlyPrescribedDays(SearchUtils.formatValueToLong(x.getContent().getRxclm_ml_rep_drug_day_sply_qty()))
                                    .retailMostCommonlyPrescribedDays(SearchUtils.formatValueToLong(x.getContent().getRxclm_rtl_rep_drug_dy_sply_qty()))
                                    .nhu(x.getContent().getQl_nhu_type_cd())
                                    .strengthQuantity(x.getContent().getStrgh_nbr())
                                    .strengthDescription(x.getContent().getStrgh_desc())
                                    .dosageFormTypeCodeDescription(x.getContent().getDigital_dsg_form())
                                    .routeName(x.getContent().getRoute_name())
                                    .strengthCondition(x.getContent().getStrg_cond())
                                    .strengthUnit(x.getContent().getStrgh_unit())
                                    .strengthVolumeNumber(x.getContent().getStrgh_vol_nbr())
                                    .strengthVolumeUnit(x.getContent().getStrgh_vol_unit())
                                    .biosimilarGroup(x.getContent().getBiologic_name_grouper())
                                    .totalPackageQuantity(x.getContent().getTot_pkg_qty())
                                    .packageDescription(x.getContent().getPkg_desc())
                                    .packSize(SearchUtils.formatValueToFloat(x.getContent().getPackageSize()))
                                    .build())
                            .build())
                    .collect(Collectors.toList());
        } catch (Exception e) {
            CvsLogger.error("Fuzzy search failed with exception :"+ e.getMessage() );
        }

        return new ArrayList<>();
    }

    private List<DrugResponse> sortFuzzyDruglist(List<DrugResponse> fuzzyOneList, String drugName) {
        List<DrugResponse> startsWith2or3Letters = fuzzyOneList.stream()
                .filter(item -> (StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName.substring(0, 3))
                        || StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName
                        .substring(0, 2))))
                .limit(searchConfig.getTotalRecords())
                .collect(Collectors.toList());

        List<DrugResponse> startsWithOtherLetters = fuzzyOneList.stream()
                .filter(item -> !(StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName.substring(0, 3)) &&
                        StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName.substring(0, 2))))
                .limit(searchConfig.getTotalRecords())
                .collect(Collectors.toList());

        return Stream.of(startsWith2or3Letters, startsWithOtherLetters).flatMap(Collection::stream).collect(Collectors.toList());
    }

}
