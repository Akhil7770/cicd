package com.cvshealth.digital.microservice.rxomnidrugsearch.util;

import com.cvshealth.digital.framework.service.logging.service.CvsLogger;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public final class DateUtil {    
    
    public static final String FORMAT_MM_DD_YYYY_0 = "MM/dd/yyyy";

    public static final String FORMAT_MM_DD_YYYY_1 = "MM-dd-yyyy";

    public static final String FORMAT_YYYY_MM_DD = "yyyy-MM-dd";

    public static final String FORMAT_YYYYMMDD = "yyyyMMdd";

    public static final String FORMAT_MM_YYYY = "MM/yyyy";

    public static final String FORMAT_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

    public static final String FORMAT_YYYY_MM_DD_HH_MM_SS_SS = "yyyy-MM-dd HH:mm:ss.SSSSSS";
    
    public static final String FORMAT_YYYY_MM_DD_T_HH_MM_SS_SS = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS";
    public static final String FORMAT_YYYY_MM_DD_T_HH_MM_SS_SS_SS = "yyyy-MM-dd'T'HH:mm:ss-SS:SS";
    public static final String FORMAT_YYYY_MM_DD_T_HH_MM_SSS_SS_SS = "yyyy-MM-dd'T'HH:mm:ss.SSS-SS:SS";

    /**
     * 
     * @param date
     * @param format
     * @return
     */
    public static String formatDateAsString(Date date, String format) {

        // Create an instance of SimpleDateFormat used for formatting 
        // the string representation of date (month/day/year)
        DateFormat df = new SimpleDateFormat(format);

        // Using DateFormat format method we can create a string 
        // representation of a date with the defined format.
        String stringDate = df.format(date);

        return stringDate;
    }

    /**
     * @description format the date in mm/dd/yyyy format
     * @param inputDate
     * @return
     */
    public static String formatDate(String inputDate) {
        String[] dateElements = inputDate.split("-");
        String yy = dateElements[0];
        String mm = dateElements[1];
        String dd = dateElements[2];
        String date = mm + "/" + dd + "/" + yy;
        return date;
    }

    /**
     * 
     * @param date
     * @return
     */
    public static boolean isDateValid(String date) {
        SimpleDateFormat mySimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date myTestDate = null;
        boolean isValidDate = true;
        try {
            myTestDate = mySimpleDateFormat.parse(date);
        }
        catch(ParseException aParseException) {
            isValidDate = false;
        }
        if(!mySimpleDateFormat.format(myTestDate).equals(date)) {
            isValidDate = false;
        }
        return isValidDate;
    }

    /**
     * Converts a String to Date Object
     * @return Date
     * @param date java.lang.String
     */
    public static Date getDate(String date) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            formatter.setLenient(false);
            return formatter.parse(date);
        }
        catch(ParseException ex) {
            return null;
        }
    }

    public static Date getDate(String date, String format) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat(format);
            formatter.setLenient(false);
            return formatter.parse(date);
        }
        catch(Exception ex) {
            CvsLogger.error("ParseException : " + ex);
            return null;
        }
    }

    /**
     * 
     * @param date
     * @return
     */
    public static String dateAsString(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat(FORMAT_YYYY_MM_DD);
        formatter.setLenient(false);
        return formatter.format(date);
    }

    public static java.sql.Timestamp getDateAsTimestamp(Date date) {
        return date != null ? new java.sql.Timestamp(date.getTime()) : null;
    }

    public static java.sql.Date getDateAsDBDate(Date date) {
        return date != null ? new java.sql.Date(date.getTime()) : null;
    }

    public static java.sql.Timestamp createTimestamp() {
        return new java.sql.Timestamp(new Date().getTime());
    }
    
    public static Date parseDateWithMultipleFormats(String strDate){
        final List<String> dateFormats = Arrays.asList(FORMAT_YYYY_MM_DD_T_HH_MM_SS_SS_SS, FORMAT_YYYY_MM_DD_T_HH_MM_SSS_SS_SS);    
        for(String format: dateFormats){
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            try{
                return sdf.parse(strDate);
            } catch (ParseException e) {

            }
        }
        return null;
    }

}
