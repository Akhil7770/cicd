package com.cvshealth.digital.microservice.rxomnidrugsearch;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * rxomni-drug-search application.
 *
 * @author Harish Paravasthu
 */
@ComponentScan("com.cvshealth.*")
@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = "${info.app.name}", version = "${info.app.version}", description = "${info.app.description}"))
public class RxOmniDrugSearchApplication {

    public static void main(String[] args) {
        SpringApplication.run(RxOmniDrugSearchApplication.class, args);
    }
}
