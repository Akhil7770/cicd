package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors; 
import java.util.concurrent.Future;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cvshealth.digital.framework.service.logging.service.LogServiceContext;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.exception.model.FaultTypes;
import com.cvshealth.digital.framework.starter.model.api.FaultSection.ErrorsDetails;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.framework.starter.utils.ThreadPoolUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchRequestDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CommonDrugSearchService {

    @Autowired
    private RestService restService;

    @Autowired
    private SearchService searchService;

    @Autowired
    private ThreadPoolUtils threadPoolUtils;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private ServiceUtils serviceUtils;

    public SearchResponseDto retrieveCommonDrugs(SearchRequestDto searchRequestDto) throws ApiException, Exception {

        SearchResponseDto response = new SearchResponseDto();
        String cacheKey = "commonDrugs";

        String cacheValue = cacheService.checkCache(cacheKey, "", SearchConstants.SEARCH_COMMON_DRUGS_CONTEXT);
        boolean isValid = false;
        if (!StringUtils.isBlank(cacheValue)) {
            isValid = cacheService.checkForValidCacheForCommonDrugs(cacheValue, "");
        }

        if (!isValid) {
            try{
                response = fetchCommonDrugs(searchRequestDto);
                cacheService.updateCache(cacheKey, serviceUtils.toJson(response), "", SearchConstants.SEARCH_COMMON_DRUGS_CONTEXT);
                LogServiceContext.addTags("CommonDrugs_CacheUpdated", true);
            } catch (Exception e) {
                LogServiceContext.addTags("error:retrieveCommonDrugs", "ERROR_WHILE_EXECUTING_QUERY");
                throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR,
				    new ErrorsDetails("common-drug-search-service.getCommonDrugs.ERROR", e.getMessage(), ""));
            }
        } else{
            LogServiceContext.addTags("CommonDrugs_CacheRetrieved", true);
            return serviceUtils.fromJson(cacheValue, SearchResponseDto.class);
        }
        return response;
    }

    private SearchResponseDto fetchCommonDrugs(SearchRequestDto searchRequestDto) throws Exception {
        SearchResponseDto commonDrugsResponse = new SearchResponseDto();
        try {
            long startTime = System.currentTimeMillis();
            commonDrugsResponse = restService.execute("common-drug-search-service", "getCommonDrugs", null, SearchResponseDto.class);
            LogServiceContext.addRestApiMetrics("COMMON_DRUG_SEARCH", "retrieveCommonDrugs", System.currentTimeMillis()-startTime);
        }catch (Exception e) {
            LogServiceContext.addTags("error:getCommonDrugs", e.getMessage());
            throw e;
        }
        List<Future<SearchResponseDto>> futureList = new ArrayList<>();
        ExecutorService pool = Executors.newFixedThreadPool(5);

        List<DrugResponse> commonDrugs = commonDrugsResponse.getDrugs();

        if(commonDrugs != null && !commonDrugs.isEmpty()){
            for (DrugResponse commonDrug : commonDrugs) {
                futureList.add(pool.submit(() -> searchService.getSearch(SearchRequestDto.builder()
                        .name(String.valueOf(commonDrug.getDrugName()))
                        .clientName(searchRequestDto.getClientName())
                        .searchType(searchRequestDto.getSearchType()).build())));
            }
        }
        List<SearchResponseDto> responseList = threadPoolUtils.waitToCompleteAndReturn(futureList);

        List<DrugResponse> drugs = new ArrayList<>();
        for (int i = 0; i < responseList.size(); i++) {
            try {
                if(null != responseList.get(i)){
                    SearchResponseDto resp = futureList.get(i).get();
                    drugs.add(resp.getDrugs().get(0));                    
                }
            } catch (Exception e) {
                LogServiceContext.addTags("skip::error:retrieveCommonDrugs", e.getMessage());
            }
        }
        SearchResponseDto searchResponseDto = SearchResponseDto.builder()
        .statusCode(commonDrugsResponse.getStatusCode()).statusDescription(commonDrugsResponse.getStatusDescription()).drugs(drugs).build();

        return searchResponseDto;
    }

}