package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.MemberInfo;
import lombok.Data;

@Data
public class DrugDetailsEslRequest {

    private String drugNdcId;

    private String drugName;

    private String memberId;

    private String appName;

    private MemberInfo memberInfo;

}
