package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import co.elastic.clients.elasticsearch._types.query_dsl.Operator;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryStringQuery;
import com.cvshealth.digital.framework.service.logging.service.CvsLogger;
import com.cvshealth.digital.framework.service.logging.service.LogServiceContext;
import com.cvshealth.digital.framework.service.rest.RestHttpServiceException;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.exception.api.ApiBadRequestException;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.api.ApiNoDataAvailableException;
import com.cvshealth.digital.framework.starter.exception.api.ApiServiceException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.exception.model.FaultTypes;
import com.cvshealth.digital.framework.starter.model.api.FaultSection;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiErrorStatus;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.*;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.DrugSearchNdcidRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.GetPlanDetailsResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.*;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import org.springframework.http.HttpHeaders;

@Service
@Slf4j
public class SearchByNdcService {

	@Value("${service.drugDetailsEndpoint}")
	private String drugDetailEndPoint;

	@Value("${service.setCache}")
	private String setCache;

	@Value("${service.getCache}")
	private String getCache;

	@Autowired
	private SearchConfig searchConfig;

	@Autowired
	private ElasticsearchOperations elasticsearchOperations;

	@Autowired
	private CrmService crmService;

	@Autowired
	private ServiceUtils serviceUtils;

	@Autowired
	private RestService restService;

	@Autowired
	private CacheService cacheService;

	@Autowired
	private DrugUtils drugUtils;

	@Autowired
	private DrugDetailsService drugDetailsService;

	public SearchResponseDto searchByNdcId(String ndcId) throws ApiException {

		// Searches by NdcId from elastic
		// Handle special characters in the ndcId, replace with space.
		ndcId = SearchUtils.stripDrugName(ndcId);

		// validate ndcId with empty/null and numeric.
		DrugValidator.validateNDCId(ndcId);

		SearchByNdcDrugResponse ndcSearchResponse = constructNDCMatchQuery(ndcId, searchConfig.getMediSpanIndexName());

		return SearchResponseDto.builder().drugInfo(ndcSearchResponse).statusCode("0000").statusDescription("Success")
				.build();
	}

	public SearchResponseDto searchNdcId(DrugSearchNdcidRequest request, String trackingId)
			throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
		// Searches by NdcId from ESL.

		SearchResponseDto searchResponseDto = null;
		DrugDetailsEslResponse response = null;
		if (request.getId() != null && request.getIdType() != null) {
			String cacheKey = String.valueOf("ndcSearch-" + request.getId());
			if (null != request.getIsOEMember() && request.getIsOEMember()) {
				cacheKey += "-oe";
			}
			String cacheValue = cacheService.checkCache(cacheKey, trackingId, SearchConstants.SEARCH_NDC_CONTEXT);
			boolean isValid = false;
			if (!StringUtils.isBlank(cacheValue)) {
				isValid = checkForValidCache(cacheValue, request.getNdcId());
			    LogServiceContext.addTags("checkForValidCache-isValid", isValid);
			}
			if (!isValid) {
				MemberInfo memberInfo = buildMemberInfo(request, trackingId, "getSearchByNdcId");
				DrugDetailsEslRequest drugDetailsEslRequest = new DrugDetailsEslRequest();
				drugDetailsEslRequest.setDrugNdcId(request.getNdcId());
				drugDetailsEslRequest.setMemberId(String.valueOf(memberInfo.getInternalID()));
				drugDetailsEslRequest.setAppName("caremark");
				drugDetailsEslRequest.setMemberInfo(memberInfo);
			    LogServiceContext.addTags("drugDetailsEsl", "calling DrugDetailList");
				response = callDrugDetailListByNdcId(drugDetailsEslRequest, trackingId);
				searchResponseDto = constructEslSearchResponse(response);
				if (null != searchResponseDto) {
					searchResponseDto.setStatusCode(SearchConstants.STATUS_CODE_0000_SUCCESS);
					searchResponseDto.setStatusDescription(SearchConstants.SUCCESS_MESSAGE);
					cacheService.updateCache(cacheKey, serviceUtils.toJson(searchResponseDto), trackingId, SearchConstants.SEARCH_NDC_CONTEXT);
				}
			} else {
				searchResponseDto = serviceUtils.fromJson(cacheValue, SearchResponseDto.class);
			}
		} else {
			searchResponseDto = getElasticSearchResponseDrug(request);
		}

		return searchResponseDto;
	}

	public SearchResponseDto searchByName(DrugSearchNdcidRequest request, String trackingId)
			throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
		SearchResponseDto searchResponseDto = null;
		DrugDetailsEslResponse response = null;
		if (request.getId() != null && request.getIdType() != null) {
			String cacheKey = "ndcSearchByName-" + request.getId();
			if (null != request.getIsOEMember() && request.getIsOEMember()) {
				cacheKey += "-oe";
			}
			String cacheValue = cacheService.checkCache(cacheKey, trackingId, SearchConstants.SEARCH_NDC_CONTEXT);
			boolean isValid = false;
			if (!StringUtils.isBlank(cacheValue)) {
				isValid = checkForValidCacheByName(cacheValue, request.getDrugName());
			    LogServiceContext.addTags("checkForValidCacheByName-isValid", isValid);
			}
			if (!isValid) {
				MemberInfo memberInfo = buildMemberInfo(request, trackingId, "getSearchByName");
				DrugDetailsEslRequest drugDetailsEslRequest = new DrugDetailsEslRequest();
				drugDetailsEslRequest.setDrugName(request.getDrugName());
				drugDetailsEslRequest.setMemberId(String.valueOf(memberInfo.getInternalID()));
				drugDetailsEslRequest.setAppName("caremark");
				drugDetailsEslRequest.setMemberInfo(memberInfo);
			    LogServiceContext.addTags("drugDetailsEsl", "calling DrugDetailList");
				response = callDrugDetailListByNdcId(drugDetailsEslRequest, trackingId);
				searchResponseDto = constructEslSearchResponse(response);
				if (null != searchResponseDto) {
					searchResponseDto.setStatusCode(SearchConstants.STATUS_CODE_0000_SUCCESS);
					searchResponseDto.setStatusDescription(SearchConstants.SUCCESS_MESSAGE);
					cacheService.updateCache(cacheKey, serviceUtils.toJson(searchResponseDto), trackingId, SearchConstants.SEARCH_NDC_CONTEXT);
				}
			} else {
				searchResponseDto = serviceUtils.fromJson(cacheValue, SearchResponseDto.class);
			}
		} else {
			throw new ApiBadRequestException(ApiErrorStatus.REQUIRED_FIELD_MISSING_ERROR);
		}

		return searchResponseDto;
	}

	private boolean checkForValidCache(String cacheValue, String ndcId) {
		try {
			SearchResponseDto searchResponseDto = serviceUtils.fromJson(cacheValue, SearchResponseDto.class);
			DrugResponse.Details drugDetails = searchResponseDto.getDrugs().get(0).getDetailsList().get(0);
			if (drugDetails.getNdc11().equals(ndcId))
				return true;
			return false;
		} catch (Exception ex) {
			return false;
		}
	}

	private boolean checkForValidCacheByName(String cacheValue, String name) {
		LogServiceContext.addTags("checkForValidCacheByName", name);
		try {
			SearchResponseDto searchResponseDto = serviceUtils.fromJson(cacheValue, SearchResponseDto.class);
			DrugResponse.Details drugDetails = searchResponseDto.getDrugs().get(0).getDetailsList().get(0);
			LogServiceContext.addTags("drugDetails", drugDetails);
			if (null != drugDetails && name.equalsIgnoreCase(drugDetails.getDrugName()))
				return true;
			return false;
		} catch (Exception ex) {
			LogServiceContext.addTags("checkForValidCacheByName.ERROR", ex.getMessage());
			return false;
		}
	}
	private SearchResponseDto getElasticSearchResponseDrug(DrugSearchNdcidRequest request)
			throws ExecutionException, InterruptedException, ApiException, JsonProcessingException {
		CompletableFuture<SearchHits<Drug>> drugResponseForTRepDrug = constructNDCMatchQueryForDrug(request.getNdcId(),
				searchConfig.getIndexName(), "ndc_code");
		List<SearchHit<Drug>> filterTRepDrugForExpiry = filterExpiredDrugs(drugResponseForTRepDrug);
		List<SearchHit<Drug>> genericSearchHits = null;
		List<SearchHit<Drug>> brandSearchHits = null;

		if (filterTRepDrugForExpiry.size() > 0) {
			List<SearchHit<Drug>> brandDrugs = getBrandDrugs(filterTRepDrugForExpiry);

			if (brandDrugs.size() > 0) {
				for (SearchHit<Drug> drugSearchHit : brandDrugs) {
					setPharmacyTypeForDrug(drugSearchHit.getContent());
				}

				String gpiCode = filterTRepDrugForExpiry.get(0).getContent().getGpi_code();
				genericSearchHits = getGenericSearchHits(gpiCode);
				brandSearchHits = new ArrayList<>(brandDrugs);
			} else {
				for (SearchHit<Drug> drugSearchHit : filterTRepDrugForExpiry) {
					setPharmacyTypeForDrug(drugSearchHit.getContent());
				}
				genericSearchHits = filterTRepDrugForExpiry;
			}

			return constructSearchResponse(brandSearchHits, genericSearchHits, request);
		} else {
			throw new ApiNoDataAvailableException(ApiErrorStatus.NOT_FOUND_ERROR);
		}
	}

	private List<SearchHit<Drug>> filterExpiredDrugs(CompletableFuture<SearchHits<Drug>> drugResponse)
			throws InterruptedException, ExecutionException {
		return drugResponse.get().stream().filter(SearchUtils::filterExpiredDrugs).collect(Collectors.toList());
	}

	private List<SearchHit<Drug>> getBrandDrugs(List<SearchHit<Drug>> drugs)
			throws ApiException, ExecutionException, InterruptedException {
		List<SearchHit<Drug>> brandDrugs = drugs.stream().filter(SearchUtils::isBrand).collect(Collectors.toList());

		if (brandDrugs.size() > 0) {
			List<SearchHit<Drug>> brandWithRetailAndMail = brandDrugs.stream()
					.filter(SearchUtils::filterRetailAndMailPrice).collect(Collectors.toList());

			if (brandWithRetailAndMail.size() > 0) {
				brandDrugs = brandWithRetailAndMail;
			} else {
				List<SearchHit<Drug>> brandWithRetailOrMail = brandDrugs.stream()
						.filter(SearchUtils::filterRetailOrMailPrice).collect(Collectors.toList());

				if (brandWithRetailOrMail.size() > 0) {
					String gpiCode = brandWithRetailOrMail.get(0).getContent().getGpi_code();
					CompletableFuture<SearchHits<Drug>> drugResponseForGpiCode = constructNDCMatchQueryForDrug(gpiCode,
							searchConfig.getIndexName(), "gpi_code");
					List<SearchHit<Drug>> brandDrugsWithMailRetailValue = drugResponseForGpiCode.get().stream()
							.filter(SearchUtils::isBrand).collect(Collectors.toList());

					SearchHit<Drug> retailDrug = brandDrugsWithMailRetailValue.stream()
							.sorted((x1, x2) -> Math.round(x2.getContent().getRxclm_retail_claim_count().intValue())
									- x1.getContent().getRxclm_retail_claim_count().intValue())
							.findFirst().get();

					SearchHit<Drug> mailDrug = brandDrugsWithMailRetailValue.stream()
							.sorted((x1, x2) -> Math.round(Integer.valueOf(x2.getContent().getRxclm_mail_claim_count()))
									- Integer.valueOf(x1.getContent().getRxclm_mail_claim_count()))
							.findFirst().get();

					String retailCount = retailDrug.getContent().getRxclm_rtl_rep_drug_mc_qty();
					String retailSplyCount = retailDrug.getContent().getRxclm_rtl_rep_drug_dy_sply_qty();

					String mailCount = mailDrug.getContent().getRxclm_mail_rep_drug_mc_qty();
					String mailSplyCount = mailDrug.getContent().getRxclm_ml_rep_drug_day_sply_qty();

					if ((!retailCount.isEmpty() || !retailCount.equals(""))
							&& (!retailSplyCount.isEmpty() || !retailSplyCount.equals(""))) {
						brandWithRetailOrMail.get(0).getContent().setRxclm_rtl_rep_drug_mc_qty(retailCount);
						brandWithRetailOrMail.get(0).getContent().setRxclm_rtl_rep_drug_dy_sply_qty(retailSplyCount);
					}
					if ((!mailCount.isEmpty() || !mailCount.equals(""))
							&& (!mailSplyCount.isEmpty() || !mailSplyCount.equals(""))) {
						brandWithRetailOrMail.get(0).getContent().setRxclm_mail_rep_drug_mc_qty(mailCount);
						brandWithRetailOrMail.get(0).getContent().setRxclm_ml_rep_drug_day_sply_qty(mailSplyCount);
					}

					brandDrugs = brandWithRetailOrMail;
				}
			}
		}

		return brandDrugs;
	}

	private void setPharmacyTypeForDrug(Drug drug) {
		if (!drug.getRxclm_mail_rep_drug_mc_qty().isEmpty() && !drug.getRxclm_rtl_rep_drug_mc_qty().isEmpty())
			drug.setPhramacyType("Retail & Mail");
		else if (!drug.getRxclm_mail_rep_drug_mc_qty().isEmpty())
			drug.setPhramacyType(PharmacyType.MAIL.name());
		else if (!drug.getRxclm_rtl_rep_drug_mc_qty().isEmpty())
			drug.setPhramacyType(PharmacyType.RETAIL.name());
	}

	private List<SearchHit<Drug>> getGenericSearchHits(String gpiCode)
			throws InterruptedException, ExecutionException, ApiException {
		CompletableFuture<SearchHits<Drug>> drugResponseForGpiCode = constructNDCMatchQueryForDrug(gpiCode,
				searchConfig.getIndexName(), "gpi_code");
		List<SearchHit<Drug>> genericSearchHits = new ArrayList<>();

		long retailCount = drugResponseForGpiCode.get().stream().filter(SearchUtils::isGeneric)
				.filter(SearchUtils::isRetailDrug).count();

		if (retailCount > 0) {
			SearchHit<Drug> retailGenericDrugs = drugResponseForGpiCode.get().stream().filter(SearchUtils::isGeneric)
					.filter(SearchUtils::isRetailDrug)
					.sorted((x1, x2) -> Math.round(x2.getContent().getRxclm_retail_claim_count().intValue())
							- x1.getContent().getRxclm_retail_claim_count().intValue())
					.findFirst().get();

			retailGenericDrugs.getContent().setPhramacyType(PharmacyType.RETAIL.name());
			genericSearchHits.add(retailGenericDrugs);
		}

		long mailCount = drugResponseForGpiCode.get().stream().filter(SearchUtils::isGeneric)
				.filter(SearchUtils::isMailDrug).count();

		if (mailCount > 0) {
			SearchHit<Drug> mailGenericDrugs = drugResponseForGpiCode.get().stream().filter(SearchUtils::isGeneric)
					.filter(SearchUtils::isMailDrug)
					.sorted((x1, x2) -> Math.round(Integer.parseInt(x2.getContent().getRxclm_mail_claim_count())
							- Integer.parseInt(x1.getContent().getRxclm_mail_claim_count())))
					.findFirst().get();

			mailGenericDrugs.getContent().setPhramacyType(PharmacyType.MAIL.name());
			genericSearchHits.add(mailGenericDrugs);
		}

		long count = drugResponseForGpiCode.get().stream().filter(SearchUtils::isGeneric)
				.filter(SearchUtils::filterRetailAndMailPrice).count();

		if (count > 0) {
			SearchHit<Drug> genericDrugs = drugResponseForGpiCode.get().stream().filter(SearchUtils::isGeneric)
					.filter(SearchUtils::filterRetailAndMailPrice)
					.sorted((x1, x2) -> Math.round(Integer.parseInt(x2.getContent().getRxclm_mail_claim_count())
							- Integer.parseInt(x1.getContent().getRxclm_mail_claim_count())))
					.findFirst().get();

			genericDrugs.getContent().setPhramacyType("Retail & Mail");
			genericSearchHits.add(genericDrugs);
		}

		return genericSearchHits;
	}

	private SearchResponseDto constructSearchResponse(List<SearchHit<Drug>> brandSearchHits,
			List<SearchHit<Drug>> genericSearchHits, DrugSearchNdcidRequest request)
			throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
		List<DrugResponse> drugResponseList = new ArrayList<>();
		if (brandSearchHits != null) {
			if (brandSearchHits.size() > 0) {
				DrugResponse drugResponsesForBrand = getDrugResponse(brandSearchHits, request);
				drugResponseList.add(drugResponsesForBrand);
			}
		}
		if (genericSearchHits != null) {
			if (genericSearchHits.size() > 0) {
				DrugResponse drugResponseForGeneric = getDrugResponse(genericSearchHits, request);
				drugResponseList.add(drugResponseForGeneric);
			}
		}

		return SearchResponseDto.builder().drugs(drugResponseList).statusCode("0000").statusDescription("Success")
				.build();
	}

	private SearchResponseDto constructEslSearchResponse(DrugDetailsEslResponse response)
			throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
		List<DrugResponse> drugResponseList = new ArrayList<>();
		for (DrugV2Response drugV2Response : response.getDrugs()) {
			List<DrugResponse.Details> details = getEslDrugDetails(drugV2Response);
			DrugResponse drugResponses = DrugResponse.builder().drugName(drugV2Response.getName())
					.genericName(drugV2Response.getGenericName()).condition(drugV2Response.getCondition())
					.uscDescription(drugV2Response.getUniformSystemOfClassification()).otc((drugV2Response.isOtc()))
					.generic(drugV2Response.isGeneric()).detailsList(details).build();

			drugResponseList.add(drugResponses);

		}

		return SearchResponseDto.builder().drugs(drugResponseList).statusCode("0000").statusDescription("Success")
				.build();
	}

	private DrugResponse getDrugResponse(List<SearchHit<Drug>> drugSearchHitList, DrugSearchNdcidRequest request)
			throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
		List<DrugResponse.Details> details = getDrugDetails(drugSearchHitList, request);
		DrugResponse drugResponses = DrugResponse.builder()
				.drugName(drugSearchHitList.get(0).getContent().getBrand_name())
				.genericName(drugSearchHitList.get(0).getContent().getGnrc_name())
				.condition(drugSearchHitList.get(0).getContent().getCondition())
				.uscDescription(drugSearchHitList.get(0).getContent().getUsc_desc())
				.otc("O".equalsIgnoreCase(drugSearchHitList.get(0).getContent().getRx_otc_ind()))
				.generic("1".equalsIgnoreCase(drugSearchHitList.get(0).getContent().getGnrc_flag()))
				.detailsList(details).build();
		return drugResponses;
	}

	private List<DrugResponse.Details> getEslDrugDetails(DrugV2Response response) {
		List<DrugResponse.Details> details = new ArrayList<>();

		for (DrugDetails drugDetails : response.getDrugDetailsList()) {
			ArrayList<PharmacyType> pharmacyTypes = setPharmacyType(drugDetails);
			details.add(DrugResponse.Details.builder().drugName(response.getName())
					.genericName(response.getGenericName()).ndc11(StringUtils.leftPad(drugDetails.getNdc11(), 11, '0'))
					.formName(drugDetails.getFormName()).formStrengthName(drugDetails.getFormStrengthName())
					.retailMostCommonlyDispensedQty(
							((pharmacyTypes.get(0).toString().equalsIgnoreCase("RETAIL") || pharmacyTypes.size() > 1)
									? String.valueOf(drugDetails.getRetailMostCommonlyDispensedQty())
									: null))
					.retailMostCommonlyPrescribedDays(
							(pharmacyTypes.get(0).toString().equalsIgnoreCase("RETAIL") || pharmacyTypes.size() > 1)
									? drugDetails.getRetailMostCommonlyPrescribedDays()
									: 0)
					.mailMostCommonlyDispensedQty(
							(pharmacyTypes.get(0).toString().equalsIgnoreCase("MAIL") || pharmacyTypes.size() > 1)
									? String.valueOf(drugDetails.getMailMostCommonlyDispensedQty())
									: null)
					.mailMostCommonlyPrescribedDays(
							(pharmacyTypes.get(0).toString().equalsIgnoreCase("MAIL") || pharmacyTypes.size() > 1)
									? drugDetails.getMailMostCommonlyPrescribedDays()
									: 0)
					.retailClaimCount(drugDetails.getRetailClaimCount())
                    .mailClaimCount(drugDetails.getMailClaimCount())
					.generic(drugDetails.isGeneric()).genericCodeNumber(drugDetails.getGenericCodeNumber())
					.brand(drugDetails.isBrand()).genericProductId(drugDetails.getGenericProductId())
					.maintenance(drugDetails.isMaintenance())
					.drugEnforcementAdministrationClassCode(drugDetails.getDrugEnforcementAdministrationClassCode())
					.packageSize((long)drugDetails.getPackageSize())
					.packSize((float)drugDetails.getPackageSize())
					.drugPackageInSize(drugDetails.getPackageSize())
					.strengthQuantity(drugDetails.getStrengthQuantity()).orangeCode(drugDetails.getOrangeCode())
					.orangeDesc(drugDetails.getOrangeDesc()).preferredStatus(drugDetails.getStatus())
					.speciality(drugDetails.isSpeciality())
					.maxDaysEligible(drugDetails.isMaxDaysEligible())
					.maxDaysSupply(drugDetails.getMaxDaysSupply())
					.strengthDescription(drugDetails.getStrengthDescription())
					.dosageFormTypeCodeDescription(getDosageFormFromElastic(drugDetails))
					.routeName(drugDetails.getRouteName())
					.strengthCondition(drugDetails.getStrengthCondition())
					.strengthUnit(drugDetails.getStrengthUnit())
					.strengthVolumeNumber(drugDetails.getStrengthVolumeNumber())
					.strengthVolumeUnit(drugDetails.getStrengthVolumeUnit())
					.biosimilarGroup(drugDetails.getBiosimilarGroup())
//					.nhu((Integer.parseInt((drugDetails.getNhu() == null || drugDetails.getNhu().equals("")) ? "0"
//							: drugDetails.getNhu())))
					.nhu(drugDetails.getNhu())
					.pharmacyTypes(pharmacyTypes)
					.totalPackageQuantity(drugDetails.getTotalPackageQuantity())
					.packageDescription(drugDetails.getPackageDescription())
					.repack(drugDetails.isRepack())
					.controlledSubstance(
						drugDetails.getDrugEnforcementAdministrationClassCode() != 0 &&
						drugUtils.isControlledSubstance(drugDetails.getDrugEnforcementAdministrationClassCode())
					)
					.build());
		}
		return details;
	}

	private String getDosageFormFromElastic(DrugDetails drugDetails) {
		String dosageFormTypeCodeDescription = null;
		try {
			Optional<DrugResponse> v2DrugFormAndDosageDetailsOptional = drugDetailsService.getV2DrugFormAndDosageDetails(DrugDetailsV2Request.builder().ndcId(drugDetails.getNdc11()).build())
					.getDrugs().stream()
					.filter(a -> a.getDetailsList().stream().anyMatch(t -> t.getNdcId().equalsIgnoreCase(drugDetails.getNdc11())))
					.findFirst();
			if (v2DrugFormAndDosageDetailsOptional.isPresent()) {
				dosageFormTypeCodeDescription = v2DrugFormAndDosageDetailsOptional.get().getDetailsList().stream()
						.filter(t -> t.getNdcId().equalsIgnoreCase(drugDetails.getNdc11()))
						.map(DrugResponse.Details::getDosageFormTypeCodeDescription)
						.findFirst().orElse(null);
			}
		} catch (Exception e) {
			LogServiceContext.addTags("dosage_mapping_error", drugDetails.getNdc11()+"::"+e.getMessage());
		}
		return dosageFormTypeCodeDescription;
	}

	private List<DrugResponse.Details> getDrugDetails(List<SearchHit<Drug>> drugSearchHitList,
			DrugSearchNdcidRequest request) {
		List<DrugResponse.Details> details = new ArrayList<>();
		for (SearchHit<Drug> drugSearchHit : drugSearchHitList) {
			ArrayList<PharmacyType> pharmacyTypes = getPharmacyType(drugSearchHit);
			details.add(DrugResponse.Details.builder().drugName(drugSearchHit.getContent().getBrand_name())
					.genericName(drugSearchHit.getContent().getGnrc_name())
					.ndc11(drugSearchHit.getContent().getNdc_code()).formName(drugSearchHit.getContent().getDsg_form())
					.formStrengthName(drugSearchHit.getContent().getStrgh_desc())
					.retailMostCommonlyDispensedQty(drugSearchHit.getContent().getRxclm_rtl_rep_drug_mc_qty())
					.retailMostCommonlyPrescribedDays(
							Integer.parseInt((drugSearchHit.getContent().getRxclm_rtl_rep_drug_dy_sply_qty() == null
									|| drugSearchHit.getContent().getRxclm_rtl_rep_drug_dy_sply_qty().trim().equals(""))
											? "0"
											: drugSearchHit.getContent().getRxclm_rtl_rep_drug_dy_sply_qty()))
					.mailMostCommonlyDispensedQty(drugSearchHit.getContent().getRxclm_mail_rep_drug_mc_qty())
					.mailMostCommonlyPrescribedDays(
							Integer.parseInt((drugSearchHit.getContent().getRxclm_ml_rep_drug_day_sply_qty() == null
									|| drugSearchHit.getContent().getRxclm_ml_rep_drug_day_sply_qty().trim().equals(""))
											? "0"
											: drugSearchHit.getContent().getRxclm_ml_rep_drug_day_sply_qty()))
					.retailClaimCount(drugSearchHit.getContent().getRxclm_retail_claim_count())
					.mailClaimCount(Integer.parseInt((drugSearchHit.getContent().getRxclm_mail_claim_count() == null
							|| drugSearchHit.getContent().getRxclm_mail_claim_count().trim().equals("")) ? "0"
									: drugSearchHit.getContent().getRxclm_mail_claim_count()))
					.generic("1".equals(drugSearchHit.getContent().getGnrc_flag()))
					.genericCodeNumber(Integer.parseInt((drugSearchHit.getContent().getGcn_nbr() == null
							|| drugSearchHit.getContent().getGcn_nbr().trim().equals("")) ? "0"
									: drugSearchHit.getContent().getGcn_nbr()))
					.brand("0".equals(drugSearchHit.getContent().getGnrc_flag()))
					.genericProductId(drugSearchHit.getContent().getGpi_code())
					.maintenance(drugSearchHit.getContent().isMaintenance())
					.drugEnforcementAdministrationClassCode(SearchUtils.formatValueToLong(
							(drugSearchHit.getContent().getDrugEnforcementAdministrationClassCode())))
					.packageSize(SearchUtils.formatValueToLong(drugSearchHit.getContent().getPackageSize()))
					.packSize((SearchUtils.formatValueToFloat(drugSearchHit.getContent().getPackageSize())))
					.controlledSubstance(StringUtils.isNotBlank(drugSearchHit.getContent().getDea_code()) && drugUtils.isControlledSubstance(Integer.parseInt(drugSearchHit.getContent().getDea_code())))
					.strengthQuantity(drugSearchHit.getContent().getStrgh_nbr())
					.orangeCode(drugSearchHit.getContent().getOrangeCode())
					.orangeDesc(drugSearchHit.getContent().getOrangeDesc())
					.strengthDescription(drugSearchHit.getContent().getStrgh_desc())
					.dosageFormTypeCodeDescription(drugSearchHit.getContent().getDigital_dsg_form())
					.biosimilarGroup(drugSearchHit.getContent().getBiologic_name_grouper())
					.routeName(drugSearchHit.getContent().getRoute_name())
					.strengthCondition(drugSearchHit.getContent().getStrg_cond())
					.strengthUnit(drugSearchHit.getContent().getStrgh_unit())
					.strengthVolumeNumber(drugSearchHit.getContent().getStrgh_vol_nbr())
					.strengthVolumeUnit(drugSearchHit.getContent().getStrgh_vol_unit())
					.nhu(drugSearchHit.getContent().getQl_nhu_type_cd())
					.pharmacyTypes(pharmacyTypes)
					.totalPackageQuantity(drugSearchHit.getContent().getTot_pkg_qty())
					.packageDescription(drugSearchHit.getContent().getPkg_desc())
					.repack(drugSearchHit.getContent().isRepack())
					.build());
		}
		return details;
	}

	private DrugDetailsEslResponse callDrugDetailListByNdcId(DrugDetailsEslRequest request, String trackingId)
			throws JsonProcessingException, ApiException {
		DrugDetailsEslResponse drugDetailsEslResponse;
		boolean isNdcIdSearch = StringUtils.isNotBlank(request.getDrugNdcId());
		String operation = isNdcIdSearch ? "getSearchByNdcId" + "." + ApiErrorStatus.NDCID_NOT_FOUND.reason()
				: "getSearchByName" + "." + ApiErrorStatus.DRUGNAME_NOT_FOUND.reason();
		String errorTitle = isNdcIdSearch ? "NDCID_NOT_FOUND" : "DRUG_NOT_FOUND";
		String fieldName = isNdcIdSearch ? "ndcId" : "drugName";
        long startTime = System.currentTimeMillis();
		try {
            HttpHeaders headers = new HttpHeaders();
            headers.add("x-grid", trackingId);
			drugDetailsEslResponse = restService.execute("drug-details-service", "getV2DrugDetails", request,
                    DrugDetailsEslResponse.class, headers, null);
            LogServiceContext.addMetrics("getDrugDetailsESLCallTime", System.currentTimeMillis() - startTime);
		} catch (RestHttpServiceException ex) {
			CvsLogger.error(operation + " rest call failed with exception :"+ ex.getMessage());
			if(ex.getMessage().contains("UNPROCESSABLE_ENTITY")) {
				operation = "getSearchByNdcId"+"."+ApiErrorStatus.MAIL_ONLY_DRUG.reason();
				errorTitle = "NcdId only available at Mail";
				fieldName = "ndcId";
				throw new ApiException(ApiStatusCodes.UNPROCESSABLE_ENTITY, FaultTypes.UNPROCESSABLE_ENTITY, new FaultSection.ErrorsDetails(
						operation, errorTitle, fieldName));
			}
			throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE, new FaultSection.ErrorsDetails(
					operation, errorTitle, fieldName));
		} catch (Exception ex) {
			CvsLogger.error(operation + "drug details call failed with exception :" + ex.getMessage());
			throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE,
					new FaultSection.ErrorsDetails(operation, errorTitle, fieldName));
		}
		if (drugDetailsEslResponse != null && CollectionUtils.isEmpty(drugDetailsEslResponse.getDrugs())) {
			CvsLogger.error(operation + " failed in drugDetailsEslResponse");
			throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE,
					new FaultSection.ErrorsDetails(operation, errorTitle, fieldName));
		}
		return drugDetailsEslResponse;
	}

	private MemberInfo buildMemberInfo(DrugSearchNdcidRequest request, String trackingId, String operation)
			throws ApiException, ExecutionException, InterruptedException {
		MemberInfo memberInfo = new MemberInfo();

		long startTime = System.currentTimeMillis();
		DrugDetailsV2Request crmRequest = new DrugDetailsV2Request();
		crmRequest.setId(request.getId());
		crmRequest.setIdType(request.getIdType());
		crmRequest.setIsOEMember(request.getIsOEMember());
		crmRequest.setCag(request.getCag());
		List<CompletableFuture<?>> tasks = crmService.makeParallelCalls(crmRequest, trackingId);

		// Wait for all tasks to complete and retrieve the results
		try {

			CompletableFuture.allOf(tasks.toArray(new CompletableFuture[0])).join();
			MemberInfoResponse patientInfoResponse = (MemberInfoResponse) tasks.get(0).get();
			GetPlanDetailsResponse planDetailsResponse = (GetPlanDetailsResponse) tasks.get(1).get();
			// FamilyInfoResponse familyDetailsResponse = (FamilyInfoResponse)
			// tasks.get(2).get();
			LogServiceContext.addRestApiMetrics("SEARCH_BY_NDC_SERVICE", "buildMemberInfoTasks", System.currentTimeMillis()-startTime);

			if (null != patientInfoResponse && null != patientInfoResponse.getBeneficiary()) {
				Beneficiary beneficiary = patientInfoResponse.getBeneficiary();

				memberInfo.setExternalID(beneficiary.getExternalID());
				memberInfo.setInternalID(beneficiary.getInternalID());
				memberInfo.setLastName(beneficiary.getLastName());
				memberInfo.setFirstName(beneficiary.getFirstName());
				memberInfo.setGender(beneficiary.getGender());
				memberInfo.setDateOfBirth(DateUtil.getDate(beneficiary.getDateOfBirth(), DateUtil.FORMAT_MM_DD_YYYY_0));
				// memberInfo.setEisName(beneficiary.getEisName());

				MemberAddress memberAddress = new MemberAddress();
				memberAddress.setState(beneficiary.getStateCode());
				memberAddress.setZipCode(beneficiary.getZipCode());
				// memberInfo.setAddresses(memberAddress);
			} else if (null != patientInfoResponse && "5013".equalsIgnoreCase(patientInfoResponse.getStatusCode())) {
				throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE,
						new FaultSection.ErrorsDetails(operation + "." + ApiErrorStatus.MEMBER_NOT_FOUND.reason(),
								ApiErrorStatus.MEMBER_NOT_FOUND.reason(), ""));
			} else {
				throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE,
						new FaultSection.ErrorsDetails(operation + "." + ApiErrorStatus.MEMBER_NOT_FOUND.reason(),
								ApiErrorStatus.MEMBER_NOT_FOUND.reason(), ""));
			}

			if (null != planDetailsResponse
					&& SearchConstants.STATUS_CODE_SUCCESS.equalsIgnoreCase(planDetailsResponse.getStatusCode())) {
				memberInfo.setPrimary(planDetailsResponse.getPrimary());
				memberInfo.setPersonCode(planDetailsResponse.getPersonCode());
				memberInfo.setCoverageEffectiveDate((planDetailsResponse.getCoverageEffectiveDate()));
				memberInfo.setCoverageTerminationDate((planDetailsResponse.getCoverageTerminationDate()));
				memberInfo.setCardholderRelationCode(planDetailsResponse.getCardholderRelationCode());
				memberInfo.setFuturePlan(planDetailsResponse.getIsFuturePlan());
				memberInfo.setPlanStartDate(DateUtil.getDate(planDetailsResponse.getPlanStartDate()));
				if (null != planDetailsResponse.getPersonalizationId()) {
					InternalParams internalParams = new InternalParams();
					internalParams.setPersonalizationId(planDetailsResponse.getPersonalizationId());
					memberInfo.setInternalParams(internalParams);
				}

				BeneficiaryKey bKey = planDetailsResponse.getBeneficiaryKey();
				if (null != bKey) {
					memberInfo.setBenefactorClientInternalID(bKey.getBenefactorClientInternalID());
					memberInfo.setCardholderInternalID(bKey.getCardholderInternalID());
					memberInfo.setCarrierID(bKey.getCarrierID());
					memberInfo.setAccountID(bKey.getAccountID());
					memberInfo.setGroupID(bKey.getGroupID());
					memberInfo.setExternalID(bKey.getExternalID());
					memberInfo.setClientCode(bKey.getClientCode());
					if (null != bKey.getClientId()) {
						memberInfo.setClientId(bKey.getClientId());
					}
					memberInfo.setClientName(bKey.getClientName());
					memberInfo.setEisName(bKey.getEisName());
				}

				if (null != planDetailsResponse.getPlanBenefitList()
						&& !planDetailsResponse.getPlanBenefitList().isEmpty()) {

					MemberEligibility eligibility = new MemberEligibility();
					List<BenefitPlan> bpList = new ArrayList<BenefitPlan>();

					for (BenefitPlan bPlan : planDetailsResponse.getPlanBenefitList()) {
						BenefitPlan benefitPlan = new BenefitPlan();
						benefitPlan.setDeliverySystem(bPlan.getDeliverySystem());
						benefitPlan.setFormularyId(bPlan.getFormularyId());
						benefitPlan.setActive(bPlan.isActive());
						if (null != bPlan.getPlanBenefitId()) {
							benefitPlan.setPlanBenefitId(bPlan.getPlanBenefitId());
						}
						bpList.add(benefitPlan);
					}
					BenefitPlanList benefitPlanList = new BenefitPlanList();
					benefitPlanList.setBenefitPlan(bpList);
					eligibility.setBenefitPlanList(benefitPlanList);
					memberInfo.setEligibility(eligibility);
				}

			} else if (null != planDetailsResponse && "5013".equalsIgnoreCase(planDetailsResponse.getStatusCode())) {
				throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE,
						new FaultSection.ErrorsDetails(operation + "." + ApiErrorStatus.PLAN_DETAILS_NOT_FOUND.reason(),
								ApiErrorStatus.PLAN_DETAILS_NOT_FOUND.reason(), ""));
			} else {
				throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE,
						new FaultSection.ErrorsDetails(operation + "." + ApiErrorStatus.PLAN_DETAILS_NOT_FOUND.reason(),
								ApiErrorStatus.PLAN_DETAILS_NOT_FOUND.reason(), ""));
			}

//            if (null != familyDetailsResponse && null != familyDetailsResponse.getFamilyMemberList()) {
//                MemberFamily memberFamily = new MemberFamily();
//                //memberFamily.setCardholderId(0);
//
//                DependentList dependentList = new DependentList();
//
//                dependentList.setDependentsList(null);
//                memberFamily.setDependentList(dependentList);
//                memberInfo.setFamily(memberFamily);
//            }
		} catch (ApiException e) {
			CvsLogger.error("CRMService ApiException:" + e.getApiError());
			throw e;
		} catch (Exception exception) {
			CvsLogger.error("CRMService error:" + exception.getMessage());
			// throw new ApiBadRequestException(ApiErrorStatus.INVALID_NDC_ID_ERROR);
			throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE,
					new FaultSection.ErrorsDetails(operation + "." + ApiErrorStatus.MEMBER_NOT_FOUND.reason(),
							ApiErrorStatus.MEMBER_NOT_FOUND.reason(), ""));
		}

		return memberInfo;
	}

	private ArrayList<PharmacyType> getPharmacyType(SearchHit<Drug> drugSearchHit) {
		ArrayList<PharmacyType> pharmacyTypes = new ArrayList<>();
		if (drugSearchHit.getContent().getPhramacyType().equalsIgnoreCase("Mail")) {
			pharmacyTypes.add(PharmacyType.MAIL);
		} else if (drugSearchHit.getContent().getPhramacyType().equalsIgnoreCase("Retail")) {
			pharmacyTypes.add(PharmacyType.RETAIL);
		} else {
			pharmacyTypes.add(PharmacyType.MAIL);
			pharmacyTypes.add(PharmacyType.RETAIL);
		}
		return pharmacyTypes;
	}

	private ArrayList<PharmacyType> setPharmacyType(DrugDetails drugDetails) {
		ArrayList<PharmacyType> pharmacyTypes = new ArrayList<>();
		if (drugDetails.getPharmacyTypes().size() > 1) {
			pharmacyTypes.add(PharmacyType.MAIL);
			pharmacyTypes.add(PharmacyType.RETAIL);
		} else {
			if (drugDetails.getPharmacyTypes().get(0).toString().equalsIgnoreCase(("Mail"))) {
				pharmacyTypes.add(PharmacyType.MAIL);
			} else if (drugDetails.getPharmacyTypes().get(0).toString().equalsIgnoreCase("Retail")) {
				pharmacyTypes.add(PharmacyType.RETAIL);
			}
		}

		return pharmacyTypes;

	}

	@Async
	public CompletableFuture<SearchHits<Drug>> constructNDCMatchQueryForDrug(String ndcId, String indexName,
			String code) throws ApiException {
		try {
			SearchHits<Drug> searchByNDCHits = callElasticSearch(code, ndcId, indexName);
			return CompletableFuture.completedFuture(searchByNDCHits);

		} catch (Exception e) {
			CvsLogger.error("NdcId search failed with exception :" + e.getMessage());
			throw new ApiServiceException(ApiErrorStatus.SERVICE_ERROR);
		}
	}

	private SearchHits<Drug> callElasticSearch(String code, String ndcId, String indexName) throws ApiException {

		try {
			LogServiceContext.addTags("callElasticSearchFor", ndcId + " " + indexName);
			QueryStringQuery testStrQuery = new QueryStringQuery.Builder().fields(code).query(ndcId)
					.defaultOperator(Operator.And).build();

			String[] indexNames = indexName.split(",");
			SearchHits<Drug> searchByNDCHits = elasticsearchOperations.search(
					NativeQuery.builder().withQuery(q -> q.queryString(testStrQuery)).withMaxResults(5).build(),
					Drug.class, IndexCoordinates.of(indexNames));
			return searchByNDCHits;
		} catch (Exception e) {
			throw new ApiBadRequestException(ApiErrorStatus.INVALID_NDC_ID_ERROR);
		}
	}

	private SearchByNdcDrugResponse constructNDCMatchQuery(String ndcId, String indexName) throws ApiException {
		LogServiceContext.addTags("constructNDCMatchQueryFor", ndcId + " " + indexName);
		QueryStringQuery testStrQuery = new QueryStringQuery.Builder().fields("ndc_code").query(ndcId)
				.defaultOperator(Operator.And).build();

		String[] indexNames = indexName.split(",");
		try {
			SearchHits<Drug> searchByNDCHits = elasticsearchOperations.search(
					NativeQuery.builder().withQuery(q -> q.queryString(testStrQuery)).withMaxResults(5).build(),
					Drug.class, IndexCoordinates.of(indexNames));

			return searchByNDCHits.stream().filter(SearchUtils::filterExpiredDrugs)
					.map(SearchByNdcService::applyAndConstructResponse).findFirst()
					.orElseThrow(() -> new ApiNoDataAvailableException(ApiErrorStatus.NOT_FOUND_ERROR));
		} catch (ApiException e) {
			CvsLogger.error("NDC Search failed :" + e.getMessage());
			throw e;
		} catch (Exception e) {
			CvsLogger.error("nGram search failed with exception :" + e.getMessage());
			throw new ApiServiceException(ApiErrorStatus.INVALID_NDC_ID_ERROR);
		}
	}

	private static SearchByNdcDrugResponse applyAndConstructResponse(SearchHit<Drug> x) {
		return SearchByNdcDrugResponse
				.builder().drugName(x.getContent().getBrand_name()).ndcId(x.getContent().getNdc_code())
				.formName(x.getContent().getDsg_form()).formStrengthName(x.getContent().getStrgh_desc())
				.gpiName(x.getContent().getGpi_name()).productName(String.format("%s %s %s",
						x.getContent().getBrand_name(), x.getContent().getDsg_form(), x.getContent().getStrgh_desc()))
				.build();
	}

}