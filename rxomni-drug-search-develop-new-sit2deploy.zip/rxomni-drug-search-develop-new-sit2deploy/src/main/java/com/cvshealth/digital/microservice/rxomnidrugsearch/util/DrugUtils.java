package com.cvshealth.digital.microservice.rxomnidrugsearch.util;

import co.elastic.clients.elasticsearch._types.FieldValue;
import co.elastic.clients.elasticsearch._types.query_dsl.*;
import co.elastic.clients.elasticsearch.core.search.FieldSuggester;
import co.elastic.clients.elasticsearch.core.search.SuggestFuzziness;
import co.elastic.clients.elasticsearch.core.search.Suggester;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class DrugUtils {

    @Autowired
    private SearchConfig searchConfig;
    /**
     * Based on the input code determine if the drug is a controlled substance
     *
     * @param deaClassCode
     * @return boolean
     */
    public boolean isControlledSubstance(int deaClassCode) {
        return searchConfig.getDeaClassCodes().contains(String.valueOf(deaClassCode));
    }
}
