package com.cvshealth.digital.microservice.rxomnidrugsearch.util;

import lombok.experimental.UtilityClass;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

@UtilityClass
public class ConditionValidator {

    public static String lookUpCondition(String drugName, Map<String, List<String>> contextMap) {
        List<String> matchedConditions = contextMap.entrySet().stream()
                .filter(a -> a.getValue().stream().anyMatch(drugName::equalsIgnoreCase))
                .map(Map.Entry::getKey).collect(Collectors.toList());

        String condition = !CollectionUtils.isEmpty(matchedConditions)
                ? matchedConditions.size() > 1 ? matchedConditions.stream().filter(c -> c.equalsIgnoreCase(drugName)).findFirst().orElse(null)
                : matchedConditions.get(0)
                : null;

        return isNotBlank(condition) ? "drug-context:"+condition : drugName;
    }

}
