package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FormularyTherapeuticClasses {

	@JsonProperty(value = "content")
	public ArrayList<Object> content;

	@JsonProperty(value = "pageable")
	private Pageable pageable;

	@JsonProperty(value = "last")
	private boolean last;

	@JsonProperty(value = "totalPages")
	private int totalPages;

	@JsonProperty(value = "totalElements")
	private int totalElements;

	@JsonProperty(value = "first")
	private boolean first;

	@JsonProperty(value = "size")
	private int size;

	@JsonProperty(value = "number")
	private int number;

	@JsonProperty(value = "sort")
	private Sort sort;

	@JsonProperty(value = "numberOfElements")
	private int numberOfElements;

	@JsonProperty(value = "empty")
	private boolean empty;

	public static class Content {

	}

}
