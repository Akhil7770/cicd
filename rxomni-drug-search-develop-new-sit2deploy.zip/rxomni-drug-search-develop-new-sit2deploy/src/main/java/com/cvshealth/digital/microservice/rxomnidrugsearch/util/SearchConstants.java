package com.cvshealth.digital.microservice.rxomnidrugsearch.util;

public final class SearchConstants {
    public static final String SUCCESS_MESSAGE = "Search is success!";
    //public static final String DRUG_NAME_FILTER = "[ ,.{}\\[\\]|\\:+;=\'<>,?/!@~#$%^\\&*()_\\-`]";
    
    //fix the SFDC 10896904 - Production Support Ticket Request, handled column and hyphen
    public static final String DRUG_NAME_FILTER = "[ ,.{}\\[\\]|\\+;=\'<>,?/!@~#$%^\\&*()_`]";
    
    public static final String SEARCH_API = "search";

    //Health check constants
    public static final String HEALTH_API = "health";
    public static final String UP = "UP";
    public static final String DOWN = "DOWN";

    //OTC - Single source
    public static final String OTC_SINGLE_SOURCE = "O";

    public static final String STATUS_CODE_SUCCESS = "0000";

    public static final String APP_NAME = "CVS_WEB";

    public static final String LOB = "Retail";

    public static final String SEARCH_NDC_CONTEXT = "drug_search_ndc_id";
    public static final String SEARCH_COMMON_DRUGS_CONTEXT ="big_query_common_drugs";

    public static final String STATUS_CODE_0000_SUCCESS = "0000";
    public static final String STATUS_CODE_1001 = "1001";

    public static final String GPI_NAME_SEARCH_FILTER = "gpi_name";
    public static final String SPACE = " ";

    public static final String SEARCH_FOR_CLIENT = "SearchForClient";

    public static final String CRM_SERVICE ="crm-service";

    public static final String OPERATION_SEARCH_BY_NDC_ID = "getSearchByNdcId";

    public static final String FDB_SERVICE = "fdb-service";

    public static final String DRUG_CONDITIONS = "getDrugConditions";

    public static final String DRUG_CONDITION_CONTEXT = "drug-conditions";

    public static final String CRM_SERVICE_GET_PATIENT_INFO = "getPatientInfo";
    public static final String CRM_SERVICE_GET_PLAN_DETAILS_V2 = "getPlanDetailsV2";

    //Private Constructor
    private SearchConstants() { }
}
