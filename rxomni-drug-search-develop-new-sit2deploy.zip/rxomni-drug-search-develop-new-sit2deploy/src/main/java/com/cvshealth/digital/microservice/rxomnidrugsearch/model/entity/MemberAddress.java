package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import lombok.Data;

@Data
public class MemberAddress {

	int country;
	short sequenceNumber = 0;
	String line1;
	String line2;
	String line3;
	String line4;
	String line5;
	String city;
	String state;
	String zipCode;
	String zipCodeSuffix;
	String internationalPostalCode;
}
