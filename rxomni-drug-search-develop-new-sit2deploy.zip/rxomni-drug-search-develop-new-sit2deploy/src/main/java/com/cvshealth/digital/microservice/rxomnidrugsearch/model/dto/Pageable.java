package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

import java.util.List;

@Data
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class Pageable {

    @JsonProperty(value = "pageNumber")
    private int pageNumber;

    @JsonProperty(value = "pageSize")
    private String pageSize;

    @JsonProperty(value = "sort")
    private Sort sort;

    @JsonProperty(value = "offset")
    private int offset;

    @JsonProperty(value = "paged")
    private boolean paged;

    @JsonProperty(value = "unpaged")
    private String unpaged;

}

