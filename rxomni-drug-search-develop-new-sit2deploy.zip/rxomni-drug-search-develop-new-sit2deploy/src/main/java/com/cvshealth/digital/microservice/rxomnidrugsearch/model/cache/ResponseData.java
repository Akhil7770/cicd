package com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode
@Data
public class ResponseData {
	
	private String key;
	
	@JsonProperty(required = false)
	private String value;
	
	private String timestamp;
	
	@JsonProperty(required = false)
	private int ttl;

}
