package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Drug {
    private String drug_gid;
    private String brand_name;
    private String gnrc_name;
    private String gnrc_flag;
    private String gpi_code;
    private String eff_date;
    private String end_date;
    private String rxclm_retail_rep_drug_ind;
    private String rxclm_mail_rep_drug_ind;
    private String drug_rxclm_src_flg;
    private String rxclm_obslt_date;
    @JsonProperty("rxRetailClaimCount")
    private Long rxclm_retail_claim_count;
    private String rxclm_mail_claim_count;
    private String rx_otc_ind;

    private String condition;
    private String usc_desc;

    private String gcn_nbr;

    //Drug details
    private String gpi_code_6;
    private String gpi_name;
    private String dsg_form;
    private String ndc_code;
    private String strgh_desc;
    private String lbl_name;
    private String pkg_desc;

    //common dispense
    private String rxclm_mail_rep_drug_mc_qty;
    private String rxclm_ml_rep_drug_day_sply_qty;
    private String rxclm_rtl_rep_drug_mc_qty;
    private String rxclm_rtl_rep_drug_dy_sply_qty;

    private double strgh_nbr;

    @JsonIgnore
    private String phramacyType;

    //private String nhu;
    private String ql_nhu_type_cd;

    private boolean maintenance;

    private String drugEnforcementAdministrationClassCode;

    private String packageSize;

    private String orangeCode;

    private String orangeDesc;

    private String imz_type_cd;

    private String drug_form;

    private String dea_code;

    private String mddb_drug_lbl_nm;

    private String digital_dsg_form;

    private String route_name;

    private String strg_cond;

    private String strgh_unit;

    private double strgh_vol_nbr;

    private String strgh_vol_unit;

    private String biologic_name_grouper;

    private String tot_pkg_qty;

    private boolean repack;
}
