package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import co.elastic.clients.elasticsearch._types.FieldSort;
import co.elastic.clients.elasticsearch._types.SortOptions;
import co.elastic.clients.elasticsearch._types.SortOrder;
import co.elastic.clients.elasticsearch._types.query_dsl.Operator;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryStringQuery;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.Drug;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchUtils;
import com.cvshealth.digital.framework.service.logging.service.CvsLogger;
import com.cvshealth.digital.framework.service.logging.service.LogServiceContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ConditionSearchService {

    @Autowired
    private SearchConfig searchConfig;

    @Autowired
    private ElasticsearchOperations elasticsearchOperations;

    public List<DrugResponse> retrieveConditionDrugs(String condition) {
        condition = condition.replaceAll("drug-context:","");
        LogServiceContext.addTags("conditionName", condition);

        try {
            //QueryBuilder queryBuilder = QueryBuilders.matchQuery("condition", condition);
            /*QueryStringQueryBuilder queryBuilder = QueryBuilders.queryStringQuery(condition);
            queryBuilder.field("condition.keyword");
            queryBuilder.defaultOperator(Operator.AND);*/

            QueryStringQuery testStrQuery = new QueryStringQuery.Builder()
                    .fields("condition.keyword")
                    .query(condition)
                    .defaultOperator(Operator.And).build();

            // 2. Execute search
            /*SearchHits<Drug> drugHits = elasticsearchOperations.search(new NativeSearchQueryBuilder().withQuery(queryBuilder)
                    //.withMaxResults(searchConfig.getMaxRecords())
                    .withSorts(SortBuilders
                            .fieldSort("rxclm_retail_claim_count")
                            .order(SortOrder.DESC))
                    .withMaxResults(500)
                    .build(), Drug.class, IndexCoordinates.of(searchConfig.getIndexName()));*/

            SearchHits<Drug> drugHits = elasticsearchOperations.search(NativeQuery.builder()
                    .withQuery(q -> q.queryString(testStrQuery))
                    .withSort(new SortOptions.Builder()
                            .field(new FieldSort.Builder().field("rxclm_retail_claim_count").order(SortOrder.Desc).build()).build())
                           .withMaxResults(500)
                    .build(), Drug.class, IndexCoordinates.of(searchConfig.getIndexName()));

            // 3. Map searchHits to drug list
            return drugHits.stream()
                    .filter(SearchUtils::filterObsoleteDrugs)
                    .filter(SearchUtils.distinctByKey(x -> x.getContent().getBrand_name()))
                    .limit(searchConfig.getTotalRecords())
                    .map(x -> DrugResponse.builder().drugName(x.getContent().getBrand_name()).genericName(x.getContent().getGnrc_name())
                            .repDrugClaimCount(x.getContent().getRxclm_retail_claim_count())
                            .condition(x.getContent().getCondition())
                            .uscDescription(x.getContent().getUsc_desc())
                            .otc("O".equalsIgnoreCase(x.getContent().getRx_otc_ind()))
                            .build())
                    .collect(Collectors.toList());
        } catch (Exception e) {
            CvsLogger.error("Condition search failed with exception :"+ e.getMessage());
        }

        return new ArrayList<>();
    }

}
