package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PlanCardDetail {

    @JsonIgnore()
    protected String name;
    //@JsonIgnore()
    //protected String externalId;
    @JsonIgnore()
    protected String rxBin;
    @JsonIgnore()
    protected String rxPCN;
    @JsonIgnore()
    protected String rxGRP;
    @JsonIgnore()
    protected String issuer;
    @JsonIgnore()
    protected String carePhoneNumber;
    @JsonIgnore()
    protected String claimAddress1;
    @JsonIgnore()
    protected String claimAddress2;
    @JsonIgnore()
    protected String claimAddress3;
    @JsonIgnore()
    protected String pharmacyPhoneNumber;

    protected String logoURL;

    protected String clientLogoURL;

    protected boolean showRequestId;

    protected boolean showPrintId;

    protected String regulatoryEntity;

}