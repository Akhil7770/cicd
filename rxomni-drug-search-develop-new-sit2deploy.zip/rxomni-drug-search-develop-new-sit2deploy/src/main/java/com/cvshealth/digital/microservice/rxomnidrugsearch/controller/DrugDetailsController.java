package com.cvshealth.digital.microservice.rxomnidrugsearch.controller;

import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.*;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.DrugDetailsService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/microservices/rxomni-drug-search")
public class DrugDetailsController {

  @Autowired
  private DrugDetailsService drugDetailsService;

  @PostMapping(value = "/drug/search/v1/drug-info", produces = MediaType.APPLICATION_JSON_VALUE)
  @Tag(name = "Search")
  @Operation(summary = "drugDetails", description = "Get Drug Form and Strength Information")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Success Response",      content = {@Content(mediaType = "application/json", schema = @Schema(implementation = SearchResponseDto.class))}),
    @ApiResponse(responseCode = "400", description = "Bad Request",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "404", description = "No Drugs Found",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
    @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))})
  })
  @CrossOrigin(origins = {"cvshealth.com", "caremark.com", "cvs.com"})
  public ResponseEntity<List<DrugDetailsResponse>> getDrugFormAndStrengthDetails(@Validated @RequestHeader Map<String, String> headers,
                                                                                 @RequestBody DrugDetailsRequest drugDetailsRequest) throws ApiException {
    //sanitize data before use.
    SearchUtils.sanitizeDrudDetailsRequest(drugDetailsRequest);
    List<DrugDetailsResponse> drugFormAndDosageDetails = drugDetailsService.getDrugFormAndDosageDetails(drugDetailsRequest);

    return new ResponseEntity<>(drugFormAndDosageDetails, HttpStatus.OK);
  }

  @PostMapping(value = "/drug/search/v2/drug-info", produces = MediaType.APPLICATION_JSON_VALUE)
  @Tag(name = "Search")
  @Operation(summary = "drugDetails", description = "Get Drug Form and Strength Information")
  @ApiResponses(value = {
          @ApiResponse(responseCode = "200", description = "Success Response",      content = {@Content(mediaType = "application/json", schema = @Schema(implementation = SearchResponseDto.class))}),
          @ApiResponse(responseCode = "400", description = "Bad Request",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "404", description = "No Drugs Found",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))})
  })
  @CrossOrigin(origins = {"cvshealth.com", "caremark.com", "cvs.com"})
  public ResponseEntity<SearchResponseDto> getV2DrugFormAndStrengthDetailsByNdcId(@Validated @RequestHeader Map<String, String> headers,
  @RequestBody DrugDetailsV2Request drugDetailsRequest) throws ApiException {
    SearchResponseDto searchResponseDto = drugDetailsService.getV2DrugFormAndDosageDetails(drugDetailsRequest);

    return new ResponseEntity<>(searchResponseDto, HttpStatus.OK);
  }

  @PostMapping(value = "/drug/search/v1/drug-condition", produces = MediaType.APPLICATION_JSON_VALUE)
  @Tag(name = "Search")
  @Operation(summary = "drugCondition", description = "Get Drug Condition Information")
  @ApiResponses(value = {
          @ApiResponse(responseCode = "200", description = "Success Response",      content = {@Content(mediaType = "application/json", schema = @Schema(implementation = SearchResponseDto.class))}),
          @ApiResponse(responseCode = "400", description = "Bad Request",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "404", description = "No Drugs Found",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))})
  })
  @CrossOrigin(origins = {"cvshealth.com", "caremark.com", "cvs.com"})
  public ResponseEntity<SearchResponseDto> getV1DrugCondition(@Validated @RequestHeader Map<String, String> headers,
  @RequestBody DrugConditionsRequest drugConditionsRequest) throws ApiException, Exception {
    SearchResponseDto searchResponseDto = drugDetailsService.getDrugConditions(drugConditionsRequest, headers);
    return new ResponseEntity<>(searchResponseDto, HttpStatus.OK);
  }

}
