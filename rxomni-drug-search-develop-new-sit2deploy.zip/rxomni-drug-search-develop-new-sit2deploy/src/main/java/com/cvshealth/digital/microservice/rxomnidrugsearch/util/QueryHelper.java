package com.cvshealth.digital.microservice.rxomnidrugsearch.util;

import co.elastic.clients.elasticsearch._types.FieldValue;
import co.elastic.clients.elasticsearch._types.query_dsl.*;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
public class QueryHelper {

    @Autowired
    private SearchConfig searchConfig;

    public NativeQuery buildNgramQuery(String drugName){
        FieldValueFactorScoreFunction fieldFunc = new FieldValueFactorScoreFunction.Builder()
                .field(searchConfig.getRxRetailClaimCount()).modifier(FieldValueFactorModifier.Log2p)
                .factor(1d).build();

        QueryStringQuery testStrQuery = new QueryStringQuery.Builder()
                .fields(searchConfig.getNGramFieldName())
                .query(drugName)
                .analyzer(searchConfig.getNGramAnalyzer()).defaultOperator(Operator.And)
                .boost(1f)
                .type(TextQueryType.BestFields)
                .maxDeterminizedStates(10000)
                .enablePositionIncrements(true)
                .fuzziness("AUTO")
                .fuzzyMaxExpansions(50)
                .autoGenerateSynonymsPhraseQuery(true)
                .fuzzyTranspositions(true)
                .build();

        List<FunctionScore> funcScores = new ArrayList<>();
        funcScores.add(new FunctionScore.Builder().filter(q -> q.matchAll(m -> m.boost(1f))).fieldValueFactor(fieldFunc).build());
        FunctionScoreQuery funcScoreQuery = new FunctionScoreQuery.Builder()
                .functions(funcScores).query(q -> q.queryString(testStrQuery)).build();

        return NativeQuery.builder()
                .withQuery(q -> q.functionScore(funcScoreQuery))
                .withMaxResults(searchConfig.getMaxRecords())
                .build();
    }

    public NativeQuery buildFuzzyQuery(String drugName){
        return NativeQuery.builder()
                .withQuery(q ->
                        q.match(m ->
                                m.field(searchConfig.getNGramFieldName())
                                        .query(drugName)
                                        .fuzziness("2")
                                        .operator(Operator.Or)
                                        .maxExpansions(50)
                                        .fuzzyTranspositions(true)
                                        .lenient(false)
                                        .zeroTermsQuery(ZeroTermsQuery.None)
                                        .prefixLength(0)
                                        .autoGenerateSynonymsPhraseQuery(true)
                                        .boost(1f)))
                .withMaxResults(searchConfig.getMaxRecords())
                .build();
    }

    public NativeQuery buildNGramTDrugQuery(String[] ndcIds){
        // 1
        //TermsQueryBuilder termsQueryBuilder = QueryBuilders.termsQuery("ndc_code.keyword", ndcIds);
        TermsQueryField ndcIdTerms = new TermsQueryField.Builder()
                .value(Arrays.stream(ndcIds).map(FieldValue::of).toList())
                .build();
        return NativeQuery.builder()
                .withQuery(q ->
                        q.terms(new TermsQuery.Builder()
                                .field("ndc_code.keyword")
                                .terms(ndcIdTerms).build())).build();
    }

    public NativeQuery buildGpiCodeQuery(String gpiCode){
        TermsQueryField gpiCodes = new TermsQueryField.Builder()
                .value(Arrays.stream(new String[]{gpiCode}).map(FieldValue::of).toList())
                .build();
        return NativeQuery.builder()
                .withQuery(q ->
                        q.terms(new TermsQuery.Builder()
                                .field("gpi_code.keyword")
                                .terms(gpiCodes).build()))
                .withMaxResults(20).build();
    }

    public NativeQuery buildGpiCodeBoolQuery(String gpiCode, String drugName){
        TermsQueryField gpiCodes = new TermsQueryField.Builder()
                .value(Arrays.stream(new String[]{gpiCode}).map(FieldValue::of).toList())
                .build();

        //build nativeQuery using BoolQuery
        BoolQuery boolQuery = new BoolQuery.Builder()
                .must(m -> m.terms(t -> t.field("gpi_code.keyword").terms(gpiCodes)))
                .filter(f -> f.term(t -> t.field("brand_name.keyword").value(FieldValue.of(drugName))))
                .build();

        return NativeQuery.builder()
                .withQuery(q ->
                        q.bool(boolQuery))
                .withMaxResults(searchConfig.getMaxNdcIds()).build();
    }
}
