package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.cvshealth.digital.framework.service.logging.service.LogServiceContext;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.exception.model.FaultTypes;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsV2Request;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FamilyInfoResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.MemberInfoResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.GetPlanDetailsListResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.GetPlanDetailsResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;

@Service
public class CrmService {

	@Value("${service.patientInfolEndPoint}")
	private String patientInfolEndPoint;

	@Value("${service.planDetailsEndPoint}")
	private String planDetailsEndPoint;

	@Value("${service.familyDetailsEndPoint}")
	private String familyDetailsEndPoint;

	@Autowired
	private RestService restService;

	public MemberInfoResponse getPatientInfo(DrugDetailsV2Request request, String trackingId) {
		HttpHeaders headers = getHeaders(trackingId);
		MemberInfoResponse response = null;
		try {
			long startTime = System.currentTimeMillis();
			LogServiceContext.addTags("crm-service-"+SearchConstants.CRM_SERVICE_GET_PATIENT_INFO, "calling getPatientInfo");
			response = restService.execute("crm-service", "getPatientInfo", request, MemberInfoResponse.class, headers, null);
			LogServiceContext.addRestApiMetrics("CRM_SERVICE_"+ SearchConstants.CRM_SERVICE_GET_PATIENT_INFO, "getPatientInfo", System.currentTimeMillis()-startTime);
		} catch (Exception e) {
			LogServiceContext.addTags("error:getPatientInfo ", e.getMessage());
			//throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
			/*throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE, new FaultSection.ErrorsDetails(
					ApiErrorStatus.MEMBER_NOT_FOUND.reason(), ApiErrorStatus.MEMBER_NOT_FOUND.reason(), ""));*/
			response = MemberInfoResponse.builder().statusCode(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusCode())
					.statusDescription(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusDescription()).build();
		}

		return response;
	}

	public GetPlanDetailsResponse getV2PlanDetails(DrugDetailsV2Request request, String trackingId) {
		HttpHeaders headers = getHeaders(trackingId);
		GetPlanDetailsListResponse getPlanDetailsListResponse = null;
		try {
			long startTime = System.currentTimeMillis();
			LogServiceContext.addTags("crm-service-"+SearchConstants.CRM_SERVICE_GET_PLAN_DETAILS_V2, "calling getPlanDetailsV2");
			getPlanDetailsListResponse = restService.execute("crm-service", "getPlanDetailsV2", request, GetPlanDetailsListResponse.class, headers, null);
			LogServiceContext.addRestApiMetrics("CRM_SERVICE_"+ SearchConstants.CRM_SERVICE_GET_PLAN_DETAILS_V2, "getPlanDetailsV2", System.currentTimeMillis()-startTime);
		} catch (Exception e) {
			LogServiceContext.addTags("error:getPlanDetailsV2", e.getMessage());
			getPlanDetailsListResponse = GetPlanDetailsListResponse.builder().statusCode(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusCode())
					.statusDescription(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusDescription()).build();
		}
		if (getPlanDetailsListResponse == null || getPlanDetailsListResponse.getPlanDetailsList() == null || getPlanDetailsListResponse.getPlanDetailsList().isEmpty()) {
			getPlanDetailsListResponse = GetPlanDetailsListResponse.builder().statusCode(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusCode())
					.statusDescription(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusDescription()).build();
			return null;
		}
		return getPlanDetailsListResponse.getPlanDetailsList().get(0);
	}

	public GetPlanDetailsResponse getV1PlanDetails(DrugDetailsV2Request request, String trackingId) {
		GetPlanDetailsResponse getPlanDetailsResponse = null;
		try {
			LogServiceContext.addTags("crm-service ", "calling getV1PlanDetails");
			getPlanDetailsResponse = restService.execute("crm-service", "getPlanDetails", request, GetPlanDetailsResponse.class);
		} catch (Exception e) {
			LogServiceContext.addTags("error:getPlanDetails", e.getMessage());
			//throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
			/*throw new ApiException(ApiStatusCodes.NO_DATA_AVAILABLE, FaultTypes.NO_DATA_AVAILABLE, new FaultSection.ErrorsDetails(
					ApiErrorStatus.PLAN_DETAILS_NOT_FOUND.reason(), ApiErrorStatus.PLAN_DETAILS_NOT_FOUND.reason(), ""));*/
			getPlanDetailsResponse = GetPlanDetailsResponse.builder().statusCode(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusCode())
					.statusDescription(ApiStatusCodes.NO_DATA_AVAILABLE.getStatusDescription()).build();
		}

		return getPlanDetailsResponse;
	}

	public FamilyInfoResponse getFamilyDetails(DrugDetailsV2Request request, String trackingId) throws ApiException {
		FamilyInfoResponse familyInfoResponse=null;
		try {
			familyInfoResponse = restService.execute("crm-service", "getFamilyDetails", request, FamilyInfoResponse.class);
		} catch (Exception e) {
			LogServiceContext.addTags("error:getFamilyDetails ", e.getMessage());
			throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
		}

		return familyInfoResponse;
	}


	public List<CompletableFuture<?>> makeParallelCalls(DrugDetailsV2Request request, String trackingId) {
		ExecutorService executor = Executors.newFixedThreadPool(3);
		CompletableFuture<MemberInfoResponse> patientInfoTask = CompletableFuture
				.supplyAsync(() -> getPatientInfo(request, trackingId), executor);

		CompletableFuture<GetPlanDetailsResponse> planDetailsTask =
				CompletableFuture.supplyAsync(() -> getV2PlanDetails(request, trackingId), executor);

		CompletableFuture<Void> allTasks = CompletableFuture.allOf(patientInfoTask, planDetailsTask);
		allTasks.exceptionally(ex -> {
			return null;
		}).whenComplete((result, ex) -> {
			executor.shutdown();
		});
		return Arrays.asList(patientInfoTask, planDetailsTask);
	}

	private HttpHeaders getHeaders(String trackingId) {
		HttpHeaders headers = new HttpHeaders();
        headers.add("x-grid", trackingId);
        return headers;
	}

}
