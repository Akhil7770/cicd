package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import com.cvshealth.digital.microservice.rxomnidrugsearch.config.ClientConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.ElasticIndexInfo;
import com.cvshealth.digital.framework.service.logging.service.CvsLogger;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.exception.model.FaultTypes;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.client.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class ElasticFallbackService {

    @Autowired
    private SearchConfig searchConfig;

    @Autowired
    private ClientConfig clientConfig;


    public ElasticIndexInfo getFallbackIndex() throws ApiException {
        try{
            InputStream inputStream = clientConfig.elasticsearchRestClient(clientConfig.clientConfiguration())
                    .performRequest(new Request("GET", "/_cat/indices/"
                            +searchConfig.getFallbackIndex()+"?h=i,creation.date.string&format=json&s=creation.date.string:desc"))
                    .getEntity().getContent();
            String result = new BufferedReader(new InputStreamReader(inputStream))
                    .lines().collect(Collectors.joining("\n"));

            ElasticIndexInfo[] indexInfo = new ObjectMapper().readValue(result, ElasticIndexInfo[].class);
            return indexInfo.length == 0 ? null : indexInfo[0];
        }catch (Exception e){
            CvsLogger.error("error:getFallbackIndex"+ e.getMessage());
            throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
        }
    }
}
