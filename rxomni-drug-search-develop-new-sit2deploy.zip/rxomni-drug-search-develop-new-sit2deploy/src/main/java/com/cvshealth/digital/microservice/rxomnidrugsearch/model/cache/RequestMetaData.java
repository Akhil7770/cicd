package com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode
@Data
public class RequestMetaData {
	
	private String appName;
	private String lineOfBusiness;
	private String conversationID;
}
