package com.cvshealth.digital.microservice.rxomnidrugsearch.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.http.HttpStatus;

@Data
@EqualsAndHashCode(callSuper = false)
public class ApiException extends Exception {
    private static final long serialVersionUID = 1L;
    private final HttpStatus httpStatus;
    private final String errorType;

    public ApiException(String message, HttpStatus httpStatus) {
        super(message);
        this.errorType=message;
        this.httpStatus = httpStatus;
    }
}
