package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;


import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FormularyCoverageDetails {
	
	 @JsonAlias(value = "formularyNumber")
	 private String formularyId;
	 
	@JsonProperty(value = "formularyName")
	private String formularyName;

	@JsonProperty(value = "formularyDrugs")
	public ArrayList<formularyDrugs> formularyDrugs;

	public static class formularyDrugs {
		
		@JsonProperty(value = "drug")
		private String drug;
		
		@JsonProperty(value = "drugName")
		private String drugName;
		
		@JsonProperty(value = "fromDate")
		private String fromDate;
		
		@JsonProperty(value = "thruDate")
		private String thruDate;
		
		@JsonProperty(value = "mony")
		private String mony;
		
		@JsonProperty(value = "medD")
		private String medD;
		
		@JsonProperty(value = "rxOtc")
		private String rxOtc;
        
		// @JsonInclude(JsonInclude.Include.NON_DEFAULT)
		// private PosMessaging posMessaging;
		
		@JsonProperty(value = "medispanDetail")
		private MedispanDetail medispanDetail;
		
		@JsonProperty(value = "drugDosages")
		public ArrayList<drugDosages> drugDosages;
		

		@JsonProperty(value = "coverageTier")
		private CoverageTier coverageTier;
		
		@JsonProperty(value = "onExclusionList")
		private boolean onExclusionList;
	
	}
	
	public static class drugDosages {

		@JsonProperty(value = "productName")
		private String productName;

		@JsonProperty(value = "dosageForm")
		private String dosageForm;

		@JsonInclude
		@JsonProperty(value = "strength")
		@Getter(AccessLevel.NONE)
		private String strength;

		@JsonInclude
		@Getter(AccessLevel.NONE)
		@JsonProperty(value = "strengthUOM")
		private String strengthUOM;

		@JsonProperty(value = "strengthAndUOM")
		private String strengthAndUOM;

		@JsonProperty(value = "applicableAttributes")
		public ArrayList<applicableAttributes> applicableAttributes;

		public String getStrength() {
			String str = ( this.strengthAndUOM!=null)?this.strengthAndUOM : "";
			String strength = "";
				for (int i = 0; i < str.length(); i++) {
					Boolean flag = Character.isDigit(str.charAt(i));
					if(i==0 & Character.isAlphabetic(str.charAt(i)))
						return strength;
					if (!flag)
						if (Character.isAlphabetic(str.charAt(i))) {
							strength = str.substring(0, i);
							break;
						}
				}
			return strength == "" ? str : strength;
		}



		public String getStrengthUOM() {
			String str = ( this.strengthAndUOM!=null)?this.strengthAndUOM : "";
			String strengthuom = "";
			if (str != null) {
				for (int i = 0; i < str.length(); i++) {
					Boolean flag = Character.isDigit(str.charAt(i));
					if (!flag)
						if (Character.isAlphabetic(str.charAt(i))) {
							this.setStrength(str.substring(0, i));
							strengthuom = str.substring(i);
							break;
						}

				}
			}
			return strengthuom.toLowerCase();
		}

		public void setStrength(String strength) {
			this.strength = strength;
		}

		public void setStrengthUOM(String strengthUOM) {
			this.strengthUOM = strengthUOM;
		}

		public static class applicableAttributes {

			@JsonProperty(value = "mony")
			private String mony;

			@JsonProperty(value = "medd")
			private String medd;

			@JsonProperty(value = "rxotc")
			private String rxotc;

		}
	}

}
