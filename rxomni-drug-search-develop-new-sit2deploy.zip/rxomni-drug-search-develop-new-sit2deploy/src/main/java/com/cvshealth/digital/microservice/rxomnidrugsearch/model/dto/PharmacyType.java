package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

public enum PharmacyType {
    RETAIL,
    MAIL
}

