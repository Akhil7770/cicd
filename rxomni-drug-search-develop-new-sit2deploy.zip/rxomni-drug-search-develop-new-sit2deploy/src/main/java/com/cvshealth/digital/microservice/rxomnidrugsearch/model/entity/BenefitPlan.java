package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BenefitPlan {
    private int deliverySystem;
    private String planBenefitId;
    private long formularyId;
//    private boolean active = false; // Phase 4 To set the active flag of benefit plan

    private boolean active;


    public static final int PAPER = 1;
    public static final int MAIL = 2;
    public static final int RETAIL = 3;
    private String effective;
    private String expiration;
    private String mailOrderPharmacy;
    private String planId;
    private boolean retail90DaySupplyProgram;
    private boolean maintenanceChoiceIndicator;
    private String maintenanceChoiceType;
    @JsonIgnore
    private String touchedIndicator;
}