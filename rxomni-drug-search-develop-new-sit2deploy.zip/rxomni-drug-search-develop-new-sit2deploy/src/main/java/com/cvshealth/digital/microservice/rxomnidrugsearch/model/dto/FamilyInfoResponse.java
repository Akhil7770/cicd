package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.FamilyMemberInfo;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.SecurityOption;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import java.util.List;

public class FamilyInfoResponse {
    private String id;
    private ArrayList<FamilyMemberInfo> familyMemberList;
    private String idType;
    private List<SecurityOption> securityOptions;

    @JsonIgnore
    private String source;

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setFamilyMemberList(ArrayList<FamilyMemberInfo> familyMemberList) {
        this.familyMemberList = familyMemberList;
    }

    public ArrayList<FamilyMemberInfo> getFamilyMemberList() {
        return familyMemberList;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdType() {
        return idType;
    }

    public void setSecurityOptions(List<SecurityOption> securityOptions) {
        this.securityOptions = securityOptions;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSource() {
        return source;
    }
    //    public List<SecurityOption> getSecurityOptions() {
//        return securityOptions;
//    }
}
