package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.cvshealth.digital.framework.service.logging.service.CvsLogger;
import com.cvshealth.digital.framework.service.logging.service.LogServiceContext;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugConditionFDBResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugConditionsRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsV2Request;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.Drug;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.DrugUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.DrugValidator;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.QueryHelper;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;
import static com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants.SUCCESS_MESSAGE;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchUtils;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DrugDetailsService {

    @Autowired
    private SearchConfig searchConfig;

    @Autowired
    private ElasticsearchOperations elasticsearchOperations;

    @Autowired
    private QueryHelper queryHelper;

    @Autowired
    private DrugUtils drugUtils;

    @Autowired
    private RestService restService;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private ServiceUtils serviceUtils;

    @Value("${drug-conditions.conditionslimit}")
    private Integer conditionslimit;

    public List<DrugDetailsResponse> getDrugFormAndDosageDetails(DrugDetailsRequest drugDetailsRequest) {
        LogServiceContext.addTags("getDrugFormAndDosageDetails:NdcIdList", drugDetailsRequest.getNdcIdList());
        List drugDetails = CollectionUtils.isEmpty(drugDetailsRequest.getNdcIdList())
                ? Collections.EMPTY_LIST
                : getV1DrugDetails(drugDetailsRequest.getNdcIdList().toArray(String[]::new));
        int actualSize = CollectionUtils.isEmpty(drugDetailsRequest.getNdcIdList()) ? 0 : drugDetailsRequest.getNdcIdList().size();
        LogServiceContext.addTags("Retrieved Drug dosage details of Actual NdcIdList size: ", actualSize
                + ", response size: " +drugDetails.size());
        return drugDetails;
    }

    public SearchResponseDto getV2DrugFormAndDosageDetails(DrugDetailsV2Request drugDetailsRequest) throws ApiException {
        LogServiceContext.addTags("getV2DrugFormAndDosageDetails:NdcId", drugDetailsRequest.getNdcId());
        // validate ndcId with empty/null and numeric.
        DrugValidator.validateNDCId(drugDetailsRequest.getNdcId());
        LogServiceContext.addTags("ndcIdValidated", true);
        return getV2DrugDetails(drugDetailsRequest);
    }

    private List getV1DrugDetails(String[] ndcIds){
        try {
            SearchHits<Drug> drugHits = elasticsearchOperations.search(queryHelper.buildNGramTDrugQuery(ndcIds),
                    Drug.class, IndexCoordinates.of(searchConfig.getMediSpanIndexName()));

            // 3. Map searchHits to drug list
            return drugHits.stream()
                    .filter(SearchUtils::filterExpiredDrugs)
                    .map(this::buildV1DrugDetailsResponse)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            CvsLogger.error("Get v1 Drug dosage details call failed with exception :"+ e.getMessage() );
        }

        return Collections.EMPTY_LIST;
    }

    private SearchResponseDto getV2DrugDetails(DrugDetailsV2Request drugDetailsV2Request){
        List<DrugResponse> drugNdcDetailsList = new ArrayList<>();
        try {
            SearchHits<Drug> drugHits = elasticsearchOperations.search(queryHelper.buildNGramTDrugQuery(new String[] {drugDetailsV2Request.getNdcId()}),
                    Drug.class, IndexCoordinates.of(searchConfig.getMediSpanIndexName()));

            // 3. Map searchHits to drug list
            drugNdcDetailsList = drugHits.stream()
                    .filter(SearchUtils::filterExpiredDrugs)
                    .map(this::buildV2DrugDetailsResponse)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            CvsLogger.error("Get v2 Drug dosage details call failed with exception :"+ e.getMessage() );
        }

        if(drugDetailsV2Request.isMoreNdcs()) {
            drugNdcDetailsList = drugNdcDetailsList.stream()
                    .map(this::lookupNdcsForGpiCode).collect(Collectors.toList());
        }

        return SearchResponseDto.builder().drugs(drugNdcDetailsList)
                .statusCode(String.valueOf(HttpStatus.SC_OK)).statusDescription(SUCCESS_MESSAGE).build();
    }

    private DrugResponse lookupNdcsForGpiCode(DrugResponse drug) {
        List<DrugResponse.Details> collectedNdcList = drug.getDetailsList().stream().map(item -> {
            NativeQuery boolQuery = queryHelper.buildGpiCodeBoolQuery(item.getGpiCode(), drug.getDrugName());
            SearchHits<Drug> drugHits = elasticsearchOperations.search(boolQuery, Drug.class,
                    IndexCoordinates.of(searchConfig.getMediSpanIndexName()));
            List<String> ndcIdList = drugHits.stream()
                    .filter(SearchUtils::filterExpiredDrugs)
                    .filter(x -> drug.getDrugName().equalsIgnoreCase(x.getContent().getBrand_name()))
                    .map(x -> x.getContent().getNdc_code())
                    .toList();

            ndcIdList = Stream.concat(Stream.of(item.getNdcId()), ndcIdList.stream()).distinct().collect(Collectors.toList());
            item.setNdcIds(ndcIdList);

            return item;
        }).collect(Collectors.toList());

        drug.setDetailsList(collectedNdcList);
        return drug;
    }

    private DrugDetailsResponse buildV1DrugDetailsResponse(SearchHit<Drug> x) {
        return DrugDetailsResponse.builder().brand_generic_status_id(Integer.parseInt(x.getContent().getGnrc_flag()))
                .ndc11_id(x.getContent().getNdc_code())
                .product_short_name(x.getContent().getLbl_name())
                .on_form_name(x.getContent().getDsg_form())
                .on_form_strength_name(x.getContent().getStrgh_desc())
                .brand_name(x.getContent().getBrand_name())
                .gnrc_name(x.getContent().getGnrc_name())
                .gpi_code(x.getContent().getGpi_code())
                .gcn_number(x.getContent().getGcn_nbr())
                .digital_dosage_form_desc(x.getContent().getDigital_dsg_form())
                .build();
    }

    private DrugResponse buildV2DrugDetailsResponse(SearchHit<Drug> x) {
        return DrugResponse.builder().drugName(x.getContent().getBrand_name()).genericName(x.getContent().getGnrc_name())
                .generic("1" .equals(x.getContent().getGnrc_flag()))
                .otc(SearchConstants.OTC_SINGLE_SOURCE.equalsIgnoreCase(x.getContent().getRx_otc_ind()))
                .repDrugClaimCount(x.getContent().getRxclm_retail_claim_count())
                .score(x.getScore())
                .detailsList(Lists.newArrayList(buildDrugDosageDetails(x)))
                .build();
    }

    private DrugResponse.Details buildDrugDosageDetails(SearchHit<Drug> x) {
        return DrugResponse.Details.builder()
                .drugName(x.getContent().getBrand_name())
                .genericName(x.getContent().getGnrc_name())
                .ndcId(x.getContent().getNdc_code())
                .formName(x.getContent().getDsg_form())
                .formStrengthName(x.getContent().getStrgh_desc())
                .retailMostCommonlyDispensedQty(x.getContent().getRxclm_rtl_rep_drug_mc_qty())
                .mailMostCommonlyDispensedQty(x.getContent().getRxclm_mail_rep_drug_mc_qty())
                .retailClaimCount(SearchUtils.formatValueToLong(x.getContent().getRxclm_retail_claim_count()))
                .generic("1".equals(x.getContent().getGnrc_flag()))
                .otc(SearchConstants.OTC_SINGLE_SOURCE.equalsIgnoreCase(x.getContent().getRx_otc_ind()))
                .gcn_number(x.getContent().getGcn_nbr())
                .controlledSubstance(StringUtils.isNotBlank(x.getContent().getDea_code()) &&
                        drugUtils.isControlledSubstance(Integer.parseInt(x.getContent().getDea_code())))
                .imzType(null == x.getContent().getImz_type_cd() ? "" : x.getContent().getImz_type_cd())
                .gpiCode(x.getContent().getGpi_code())
                .drugForm(null == x.getContent().getDrug_form() ? "" : x.getContent().getDrug_form())
                .mailMCPDays(x.getContent().getRxclm_ml_rep_drug_day_sply_qty())
                .retailMCPDays(x.getContent().getRxclm_rtl_rep_drug_dy_sply_qty())
                .gcn(SearchUtils.formatValueToLong(x.getContent().getGcn_nbr()))
                .mailMostCommonlyPrescribedDays(SearchUtils.formatValueToLong(x.getContent().getRxclm_ml_rep_drug_day_sply_qty()))
                .retailMostCommonlyPrescribedDays(SearchUtils.formatValueToLong(x.getContent().getRxclm_rtl_rep_drug_dy_sply_qty()))
                .strengthQuantity(x.getContent().getStrgh_nbr())
                .strengthDescription(x.getContent().getStrgh_desc())
                .dosageFormTypeCodeDescription(x.getContent().getDigital_dsg_form())
                .routeName(x.getContent().getRoute_name())
                .strengthCondition(x.getContent().getStrg_cond())
                .strengthUnit(x.getContent().getStrgh_unit())
                .strengthVolumeNumber(x.getContent().getStrgh_vol_nbr())
                .strengthVolumeUnit(x.getContent().getStrgh_vol_unit())
                .biosimilarGroup(x.getContent().getBiologic_name_grouper())
                .totalPackageQuantity(x.getContent().getTot_pkg_qty())
                .packageDescription(x.getContent().getPkg_desc())
                .packSize(SearchUtils.formatValueToFloat(x.getContent().getPackageSize()))
                .build();
    }

        public SearchResponseDto getDrugConditions(DrugConditionsRequest drugConditionsRequest, Map<String, String> headers) throws ApiException, Exception {
        String ndcId = drugConditionsRequest.getNdcId();
        String cacheKey = "ndcId_" + ndcId;
        LogServiceContext.addTags("getDrugConditions:NdcId", ndcId);
        LogServiceContext.addTags("x-grid", headers.get("x-grid"));

        String cacheValue = cacheService.checkCache(cacheKey, "", SearchConstants.DRUG_CONDITION_CONTEXT);
        boolean isValid = false;
        if (!StringUtils.isBlank(cacheValue)) {
            isValid = cacheService.checkForValidCacheForDrugConditions(cacheValue, ndcId);
        }

        DrugConditionFDBResponse response;
        SearchResponseDto searchResponseDto = new SearchResponseDto();
        List<String> drugConditionsList = new ArrayList<>();
        List<String> drugConditions = new ArrayList<>();

        if (!isValid) {
            try{
                response = getDrugConditionFDBResponse(ndcId);

                if (response != null && response.getItems() != null) {
                    drugConditionsList = response.getItems().stream().map(drugItem -> drugItem.getConditionDesc()).collect(Collectors.toList());
                }
                if (!CollectionUtils.isEmpty(drugConditionsList)) {
                    drugConditions = drugConditionsList.stream().limit(conditionslimit).collect(Collectors.toList());
                }
                searchResponseDto.setDrugConditions(drugConditions);
                searchResponseDto.setStatusCode(ApiStatusCodes.SUCCESS.getStatusCode());
                searchResponseDto.setStatusDescription(ApiStatusCodes.SUCCESS.getStatusDescription());

                cacheService.updateCache(cacheKey, serviceUtils.toJson(searchResponseDto), "", SearchConstants.DRUG_CONDITION_CONTEXT);
                LogServiceContext.addTags("DrugConditions_CacheUpdated", true);
            }catch(Exception e){
                LogServiceContext.addTags("error:getDrugConditions", "ERROR_WHILE_EXECUTING_QUERY " + e.getMessage());
                searchResponseDto.setDrugConditions(new ArrayList<>());
                searchResponseDto.setStatusCode(ApiStatusCodes.SUCCESS.getStatusCode());
                searchResponseDto.setStatusDescription(ApiStatusCodes.SUCCESS.getStatusDescription());
            }
        } else {
            LogServiceContext.addTags("DrugConditions_CacheRetrieved", true);
            return serviceUtils.fromJson(cacheValue, SearchResponseDto.class);
        }
        return searchResponseDto;
    }

    private DrugConditionFDBResponse getDrugConditionFDBResponse(String ndcId) {
        DrugConditionFDBResponse response;

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);

        Map<String, String> queryParam = new HashMap<>();
        queryParam.put("NDCID", ndcId);

        long startTime = System.currentTimeMillis();
        response = restService.execute(SearchConstants.FDB_SERVICE, SearchConstants.DRUG_CONDITIONS, null,
                DrugConditionFDBResponse.class, headers, queryParam);

        LogServiceContext.addRestApiMetrics("DRUG_CONDITIONS", "getDrugCondition", System.currentTimeMillis()-startTime);

        return response;
    }
  
}
