package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DrugResponse {

    @JsonProperty("drugName")
    private String drugName;
    @JsonIgnore
    private Long repDrugClaimCount;
    @JsonProperty("genericName")
    private String genericName;
    @JsonProperty("gpiName")
    private String gpiName;

    @JsonProperty("condition")
    private String condition;
    @JsonIgnore
    private float score;
    @JsonProperty("isGeneric")
    private boolean generic;
    @JsonProperty("isOtc")
    private boolean otc;

    @JsonProperty("uscDescription")
    private String uscDescription;
    @JsonProperty("isAIMLSuggested")
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private boolean aimlSuggested;
    @JsonIgnore
    private Details details;
    @JsonProperty("detailsList")
    private List<Details> detailsList;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Details{
        //Form Strength Dosage details.
        private String drugName;
        private String genericName;
        private String gpiName;
        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String ndcId;
        private String ndc11;
        private String formName;
        private String formStrengthName;
        private String retailMostCommonlyDispensedQty;
        private long retailMostCommonlyPrescribedDays;
        private String mailMostCommonlyDispensedQty;
        private long mailMostCommonlyPrescribedDays;
        @JsonIgnore
        private String retailMCPDays;
        @JsonIgnore
        private String mailMCPDays;

        private long retailClaimCount;
        private boolean generic;
        private boolean otc;
        @JsonIgnore
        private String gcn_number;
        @JsonInclude(JsonInclude.Include.NON_DEFAULT)
        private long gcn;
        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String gpiCode;
        private long mailClaimCount;
        //gcn
        @JsonInclude(JsonInclude.Include.NON_DEFAULT)
        private long genericCodeNumber;
        private boolean brand;
        @JsonInclude(JsonInclude.Include.NON_DEFAULT)
        private String nhu;
        // gpi code
        private String genericProductId;
        private boolean maintenance;

        private long drugEnforcementAdministrationClassCode;
        private long packageSize;
        private float packSize;

        private double drugPackageInSize;

        private double strengthQuantity;
        private String orangeCode;
        private String orangeDesc;
        private boolean speciality;
        private List<PharmacyType> pharmacyTypes;
        private String preferredStatus;

        private String imzType;

        private boolean controlledSubstance;

        @Builder.Default
        private boolean maxDaysEligible=false;
        private String maxDaysSupply;

        private String drugForm;

        private List<String> ndcIds;

        private String strengthDescription;

        private String dosageFormTypeCodeDescription;

        private String routeName;

        private String strengthCondition;

        private String strengthUnit;

        private double strengthVolumeNumber;

        private String strengthVolumeUnit;

        private String biosimilarGroup;

        private String totalPackageQuantity;

        private String packageDescription;

        private boolean repack;

    }
}
