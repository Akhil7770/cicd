package com.cvshealth.digital.microservice.rxomnidrugsearch.config;

import jakarta.annotation.PostConstruct;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.PathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.io.IOException;
import java.util.*;

@Configuration
@Data
public class DrugConditionConfig {
    private Map<String, List<String>> conditions = new HashMap<>();

    @Value("${service.drugs-conditions-map}")
    private String conditionsMap;

    @PostConstruct
    public void doInit() throws IOException {
        Properties properties = PropertiesLoaderUtils.loadProperties(new PathResource(conditionsMap));
        properties.forEach((key, value) ->
                conditions.put((String) key, Arrays.asList(StringUtils.splitPreserveAllTokens((String) value, ","))));
    }

}
