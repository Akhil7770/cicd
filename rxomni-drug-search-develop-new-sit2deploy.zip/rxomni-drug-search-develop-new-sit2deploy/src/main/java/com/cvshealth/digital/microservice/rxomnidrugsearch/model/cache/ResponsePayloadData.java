package com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode
@Data
public class ResponsePayloadData {
	
	private List<ResponseData> data;
}
