package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;


import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FormularyDrugNameSearch {

    @JsonProperty(value = "totalPages")
    private int totalPages;
    @JsonProperty(value = "totalElements")
    private int totalElements;
    @JsonProperty(value = "first")
    private boolean first;
    @JsonProperty(value = "last")
    private boolean last;
    @JsonProperty(value = "size")
    private int size;
    @JsonProperty(value = "sort")
    private Sort sort;
    @JsonProperty(value = "numberOfElements")
    private int numberOfElements;
    @JsonProperty(value = "empty")
    private boolean empty;
    @JsonProperty(value = "pageable")
    public Pageable pageable;
    @JsonProperty(value = "content")
    public ArrayList<Object> content;

}
