package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails;

import lombok.Builder;

import java.util.List;

@lombok.Data
@Builder
public class GetPlanDetailsListResponse  {
    private String statusCode;
    private String statusDescription;
    private List<GetPlanDetailsResponse> planDetailsList;
    // No-argument constructor
    public GetPlanDetailsListResponse() {
    }

    // Parameterized constructor
    public GetPlanDetailsListResponse(String statusCode, String statusDescription,List<GetPlanDetailsResponse> planDetailsList) {
        this.statusCode = statusCode;
        this.statusDescription = statusDescription;
        this.planDetailsList = planDetailsList;
    }
}