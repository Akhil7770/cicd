package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Describes a Client Plan Group
 */
@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientPlanGroup
{
    private long cpgID;
    private String cpgPlanCode;
    private String cpgPlanExtensionCode;
    private String cpgGroupCode;
    private String cpgGroupExtensionCode;
    private String billingReportingCode;
    private String accountId;

}