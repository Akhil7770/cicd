package com.cvshealth.digital.microservice.rxomnidrugsearch.controller;

import java.util.concurrent.ExecutionException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cvshealth.digital.framework.service.logging.service.LogServiceContext;
import com.cvshealth.digital.framework.starter.exception.api.ApiBadRequestException;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.HealthCheckException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.ApiErrorResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.HealthCheckResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchRequestDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.DrugDetailsV2Request;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.DrugSearchNdcidRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.CommonDrugSearchService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.ElasticSearchHealthCheckService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.SearchByNdcService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.SearchService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchUtils;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/microservices/rxomni-drug-search")
public class SearchController {

  @Autowired
  private SearchService searchService;

  @Autowired
  SearchByNdcService searchByNdcService;

  @Autowired
  private ElasticSearchHealthCheckService elasticSearchHealthCheckService;

  @Autowired
  private CommonDrugSearchService commonDrugSearchService;

  @GetMapping(value = "/drug/search/v1/drug-list", produces = MediaType.APPLICATION_JSON_VALUE)
  @Tag(name = "Search")
  @Operation(summary = "getSearch", description = "Get Search Information")
  @ApiResponses(value = {
          @ApiResponse(responseCode = "200", description = "Success Response",      content = {@Content(mediaType = "application/json", schema = @Schema(implementation = SearchResponseDto.class))}),
          @ApiResponse(responseCode = "400", description = "Bad Request",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "404", description = "No Drugs Found",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))})
  })
  @CrossOrigin(origins = {"cvshealth.com", "caremark.com", "cvs.com"})
  public ResponseEntity<SearchResponseDto> getSearch(@RequestHeader(value="x-custom-client", required = false) String customClient,
                                                     @RequestHeader(value="x-dosage-details", required = false) String dosageDetails,
                                                     @RequestHeader(value="x-search-filter", required = false) String searchFilter,
                                                     @RequestHeader(value="x-grid", required = false) String xGrid,
                                                     @RequestParam(value = "name", required = false) String name,
                                                     @RequestParam(value= "ndc11", required = false) String ndc11,
                                                     @RequestParam(value = "moreNdcs", required = false) boolean moreNdcs,
                                                     @RequestBody(required = false) DrugDetailsV2Request crmRequest
  ) throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
    //sanitize data before use.

    SearchRequestDto searchRequestDto = new SearchRequestDto();
    SearchResponseDto searchResponseDto = null;
    if( name != null ) {
      searchRequestDto.setName(SearchUtils.sanitizeData(name));
      searchRequestDto.setSearchType(SearchConstants.SEARCH_API);
      searchRequestDto.setClientName(SearchUtils.sanitizeData(customClient));
      searchRequestDto.setDrugDosageDetailsFlag(SearchUtils.sanitizeData(dosageDetails));
      searchRequestDto.setSearchFilter(SearchUtils.sanitizeData(searchFilter));
      searchRequestDto.setMoreNdcs(moreNdcs);
      LogServiceContext.addTags("SearchTerm", searchRequestDto.getName());
      LogServiceContext.addTags(SearchConstants.SEARCH_FOR_CLIENT, searchRequestDto.getClientName());
      searchResponseDto = searchService.getSearch(searchRequestDto);
    } else if (ndc11 != null ) {
      LogServiceContext.addTags("SearchNdcId", ndc11);
      LogServiceContext.addTags(SearchConstants.SEARCH_FOR_CLIENT, customClient);

      DrugSearchNdcidRequest drugSearchNdcidRequest = new DrugSearchNdcidRequest();
      if(crmRequest != null) {
        drugSearchNdcidRequest.setId(crmRequest.getId());
        drugSearchNdcidRequest.setIdType(crmRequest.getIdType());
      }

      drugSearchNdcidRequest.setNdcId(ndc11);
      searchResponseDto = searchByNdcService.searchNdcId(drugSearchNdcidRequest, xGrid);
    } else {
      throw new ApiBadRequestException();
    }

    return new ResponseEntity<>(searchResponseDto, HttpStatus.OK);
  }


  @PostMapping(value = "/drug/search/v2/drug-list", produces = MediaType.APPLICATION_JSON_VALUE)
  @Tag(name = "Search")
  @Operation(summary = "getSearch", description = "Get Search Information")
  @ApiResponses(value = {
          @ApiResponse(responseCode = "200", description = "Success Response",      content = {@Content(mediaType = "application/json", schema = @Schema(implementation = SearchResponseDto.class))}),
          @ApiResponse(responseCode = "400", description = "Bad Request",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "404", description = "No Drugs Found",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))})
  })
  @CrossOrigin("cvshealth.com")
  public ResponseEntity<SearchResponseDto> getSearchV2(@RequestHeader(value="x-custom-client", required = false) String customClient,
                                                       @RequestHeader(value="x-grid", required = false) String xGrid,
                                                       @RequestBody(required = false) DrugDetailsV2Request crmRequest
  ) throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
    //sanitize data before use.
    SearchResponseDto searchResponseDto = null;

    if(crmRequest.getDrugName()!=null && crmRequest.getNdcId() != null ) {
      throw new ApiBadRequestException();
    }

    if (crmRequest.getNdcId() != null ) {
      LogServiceContext.addTags("SearchNdcIdV2", crmRequest.getNdcId());
      LogServiceContext.addTags(SearchConstants.SEARCH_FOR_CLIENT, customClient);
      DrugSearchNdcidRequest drugSearchNdcidRequest = new DrugSearchNdcidRequest();
      if(crmRequest != null) {
        drugSearchNdcidRequest.setId(crmRequest.getId());
        drugSearchNdcidRequest.setIdType(crmRequest.getIdType());
        drugSearchNdcidRequest.setIsOEMember(crmRequest.getIsOEMember());
        if(!StringUtils.isEmpty(crmRequest.getCag())) {
          drugSearchNdcidRequest.setCag(crmRequest.getCag());
        }
      }
      drugSearchNdcidRequest.setNdcId(crmRequest.getNdcId());
      searchResponseDto = searchByNdcService.searchNdcId(drugSearchNdcidRequest, xGrid);
    }
    else if( crmRequest.getDrugName() != null) {
      LogServiceContext.addTags("SearchDrugNameV2", crmRequest.getDrugName());
      LogServiceContext.addTags(SearchConstants.SEARCH_FOR_CLIENT, customClient);

      DrugSearchNdcidRequest drugSearchNdcidRequest = new DrugSearchNdcidRequest();
      if(crmRequest != null) {
        drugSearchNdcidRequest.setId(crmRequest.getId());
        drugSearchNdcidRequest.setIdType(crmRequest.getIdType());
        drugSearchNdcidRequest.setIsOEMember(crmRequest.getIsOEMember());
        if(!StringUtils.isEmpty(crmRequest.getCag())) {
          drugSearchNdcidRequest.setCag(crmRequest.getCag());
        }
      }
      drugSearchNdcidRequest.setDrugName(crmRequest.getDrugName());
      searchResponseDto = searchByNdcService.searchByName(drugSearchNdcidRequest, xGrid);
    } else {
      throw new ApiBadRequestException();
    }

    return new ResponseEntity<>(searchResponseDto, HttpStatus.OK);
  }
  @GetMapping(value = "/drug/healthcheck/1.0", produces = MediaType.APPLICATION_JSON_VALUE)
  @Tag(name = "ElasticSearchHealthCheck")
  @Operation(summary = "getElasticSearchHealth", description = "Get Elasticsearch Health Information")
  @ApiResponses(value = {
          @ApiResponse(responseCode = "200", description = "Success Response",      content = {@Content(mediaType = "application/json", schema = @Schema(implementation = HealthCheckResponseDto.class))}),
          @ApiResponse(responseCode = "503", description = "Internal Server Error", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = HealthCheckResponseDto.class))})
  })
  @CrossOrigin("cvshealth.com")
  public HealthCheckResponseDto getElasticSearchHealth() throws HealthCheckException {
    return elasticSearchHealthCheckService.getESHealthCheck();
  }

  @GetMapping(value = "/drug/search/v1/common-drugs", produces = MediaType.APPLICATION_JSON_VALUE)
  @Tag(name = "CommonDrugs")
  @Operation(summary = "getCommonDrugs", description = "Get Common drugs from Adobe data")
  @ApiResponses(value = {
          @ApiResponse(responseCode = "200", description = "Success Response",      content = {@Content(mediaType = "application/json", schema = @Schema(implementation = SearchResponseDto.class))}),
          @ApiResponse(responseCode = "400", description = "Bad Request",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "404", description = "No Drugs Found",           content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))}),
          @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class))})
  })
  @CrossOrigin(origins = {"cvshealth.com", "caremark.com", "cvs.com"})
  public ResponseEntity<SearchResponseDto> getCommonDrugs(@RequestHeader(value="x-custom-client", required = false) String customClient,
  @RequestHeader(value="x-grid", required = false) String xGrid) throws ApiException, Exception {
    SearchRequestDto searchRequestDto = new SearchRequestDto();
    searchRequestDto.setSearchType(SearchConstants.SEARCH_API);
    searchRequestDto.setClientName(SearchUtils.sanitizeData(customClient));
    SearchResponseDto searchResponseDto = commonDrugSearchService.retrieveCommonDrugs(searchRequestDto);
    return new ResponseEntity<>(searchResponseDto, HttpStatus.OK);
  }

}
