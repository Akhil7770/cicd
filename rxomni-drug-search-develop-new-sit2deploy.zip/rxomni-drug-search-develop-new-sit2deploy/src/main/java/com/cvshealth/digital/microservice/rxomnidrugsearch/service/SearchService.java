package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.cvshealth.digital.framework.service.logging.service.CvsLogger;
import com.cvshealth.digital.framework.service.logging.service.LogServiceContext;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.api.ApiNoDataAvailableException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.exception.model.FaultTypes;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.DrugConditionConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiErrorStatus;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchRequestDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.Drug;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.ElasticIndexInfo;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.ConditionValidator;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.DrugUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.DrugValidator;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.QueryHelper;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;
import static com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants.SUCCESS_MESSAGE;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchHelper;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchUtils;
import com.google.common.collect.Lists;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class SearchService {

    @Autowired
    private SearchConfig searchConfig;

    @Autowired
    private ElasticsearchOperations elasticsearchOperations;

    @Autowired
    private FuzzySearchService fuzzySearchService;

    @Autowired
    private ElasticFallbackService elasticFallbackService;

    @Autowired
    private ConditionSearchService conditionSearchService;

    @Autowired
    private DrugConditionConfig drugConditionConfig;

    @Autowired
    private AIMLSuggestionService aimlSuggestionService;

    @Autowired
    private QueryHelper queryHelper;

    @Autowired
    private DrugUtils drugUtils;

    public SearchResponseDto getSearch(SearchRequestDto searchRequestDto) throws ApiException {

        //Handle special characters in the drugname, replace with space.
        String drugName = SearchUtils.stripDrugName(searchRequestDto.getName());
        String searchType = searchRequestDto.getSearchType();
        String clientName = searchRequestDto.getClientName();
        boolean isClientApiCall= SearchUtils.isCashDiscountToolClientCall(clientName, searchConfig.getDosageEligibleClients());

        //validate drug name with empty/null and numeric.
        DrugValidator.validateDrugName(drugName);

        if(searchConfig.isConditionSearchEnabled() && !isClientApiCall){
            drugName = ConditionValidator.lookUpCondition(drugName, drugConditionConfig.getConditions());

            if(drugName.startsWith("drug-context") ){
                List<DrugResponse> drugList = conditionSearchService.retrieveConditionDrugs(drugName).stream().limit(searchConfig.getTotalRecords()).collect(Collectors.toList());
                return buildSearchResponse(drugList);
            }
        }

        //boolean flag values: null/false/true
        String isCDTDosageDetailsCall = searchRequestDto.getDrugDosageDetailsFlag();

        //AIML search integration to fetch top 2 suggested drugs.
        boolean enableAIMLSearch = searchConfig.isAimlSuggestionEnabled() && SearchUtils.isAIMLSearchEnabled(clientName, searchConfig.getAimlSuggestionClients());

        //Apply nGram Analyzer for brand_name and fetch all matching records from ES.
        List<DrugResponse> nGramPartialMatchDrugList = constructNGramPartialMatchQuery(drugName,
                searchType.startsWith("fallback") ? StringUtils.substringAfterLast(searchType, ":") : searchConfig.getIndexName());

        if(searchType.equalsIgnoreCase(SearchConstants.HEALTH_API)){
            return buildSearchResponse(nGramPartialMatchDrugList);
        }

        long totalRecords = enableAIMLSearch ? 100 : getTotalSearchRecords(searchConfig, searchRequestDto, isCDTDosageDetailsCall);

        nGramPartialMatchDrugList = filterWithDrugNames(drugName, searchRequestDto.getSearchFilter(), nGramPartialMatchDrugList);

        List<DrugResponse> phoneticFuzzyDrugList = null;

        if (null != nGramPartialMatchDrugList && nGramPartialMatchDrugList.size() < totalRecords) {
            //Apply fuzziness to search.
            List<DrugResponse> fuzzyList = fuzzySearchService.getFuzziSearch(drugName, isClientApiCall);
            phoneticFuzzyDrugList = processFuzziResponse(drugName, isClientApiCall, nGramPartialMatchDrugList, phoneticFuzzyDrugList, totalRecords, fuzzyList);
        }

        List<DrugResponse> nGramPartialFuzzyMatchDrugList = Stream.of(nGramPartialMatchDrugList, phoneticFuzzyDrugList).filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .filter(isClientApiCall ? x -> true : SearchUtils.distinctByKey(DrugResponse::getDrugName))
                .collect(Collectors.toList());

        if(enableAIMLSearch){
            List<DrugResponse> combinedSuggestions = aimlSuggestionService.getAIMLSuggestions(nGramPartialFuzzyMatchDrugList ,drugName);
            nGramPartialFuzzyMatchDrugList = combinedSuggestions.stream().limit(searchConfig.getTotalRecords()).collect(Collectors.toList());
        }

        if (CollectionUtils.isEmpty(nGramPartialFuzzyMatchDrugList)) {
            if(!searchType.startsWith("fallback") && searchConfig.isFallbackEnabled()){
                return applyFallbackProcess(drugName);
            }
            throw new ApiNoDataAvailableException(ApiErrorStatus.DRUG_NOT_FOUND);
        }

        if(isClientApiCall) {
            if(SearchConstants.GPI_NAME_SEARCH_FILTER.equalsIgnoreCase(searchRequestDto.getSearchFilter())){
                nGramPartialFuzzyMatchDrugList = SearchHelper.mergeDosageDetailsByGpiNames(nGramPartialFuzzyMatchDrugList, drugName, totalRecords);
            }else {
                //CDT sildenafil issue fix
                nGramPartialFuzzyMatchDrugList = isCDTDosageDetailsCall == null ? SearchHelper.mergeDosageDetailsByDrugName(nGramPartialFuzzyMatchDrugList, drugName, totalRecords)
                        : SearchHelper.mergeDosageDetailsByGenericName(nGramPartialFuzzyMatchDrugList, totalRecords, isCDTDosageDetailsCall);
                try{
                    if(searchRequestDto.isMoreNdcs()){
                        nGramPartialFuzzyMatchDrugList = nGramPartialFuzzyMatchDrugList.stream()
                                .map(this::lookupNdcsForGpiCode).collect(Collectors.toList());
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }

            }
        }else{
            nGramPartialFuzzyMatchDrugList = nGramPartialFuzzyMatchDrugList.stream().limit(totalRecords).collect(Collectors.toList());
        }

        return buildSearchResponse(nGramPartialFuzzyMatchDrugList);
    }

    private DrugResponse lookupNdcsForGpiCode(DrugResponse drug) {
        List<DrugResponse.Details> collectedNdcList = drug.getDetailsList().stream().map(item -> {
            String gpiCode = item.getGpiCode();
            NativeQuery boolQuery = queryHelper.buildGpiCodeBoolQuery(gpiCode, drug.getDrugName());
            SearchHits<Drug> drugHits = elasticsearchOperations.search(boolQuery, Drug.class,
                    IndexCoordinates.of(searchConfig.getMediSpanIndexName()));
            List<String> ndcIdList = drugHits.stream()
                    .filter(SearchUtils::filterExpiredDrugs)
                    .filter(x -> drug.getDrugName().equalsIgnoreCase(x.getContent().getBrand_name()))
                    .map(x -> x.getContent().getNdc_code())
                    .toList();
            item.setNdcIds(ndcIdList);

            return item;
        }).collect(Collectors.toList());

        drug.setDetailsList(collectedNdcList);
        return drug;
    }

    private List<DrugResponse> processFuzziResponse(String drugName, boolean isCDTApiCall, List<DrugResponse> nGramPartialMatchDrugList, List<DrugResponse> phoneticFuzzyDrugList, long totalRecords, List<DrugResponse> fuzzyList) throws ApiException {
        try {
            phoneticFuzzyDrugList = Stream.of(fuzzyList).flatMap(Collection::stream)
                    .filter(isCDTApiCall ? x -> true : SearchUtils.distinctByKey(DrugResponse::getDrugName))
                    //.map(val -> prepareFuzzyDosageDetails(dosageDetailsRequired, val))
                    .collect(Collectors.toList());

            phoneticFuzzyDrugList = sortFuzzyPhoneticDrugList(phoneticFuzzyDrugList, drugName).stream()
                    //.limit(totalRecords-nGramPartialMatchDrugList.size())
                    .collect(Collectors.toList());
        } catch (Exception e) {
            CvsLogger.error("Fuzzy search failed with error :  "+e.getMessage());
            if(CollectionUtils.isEmpty(nGramPartialMatchDrugList)){
                throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
            }
        }
        return phoneticFuzzyDrugList;
    }

    private SearchResponseDto buildSearchResponse(List<DrugResponse> drugList) {
        return SearchResponseDto.builder().drugs(drugList)
                .statusCode(String.valueOf(HttpStatus.SC_OK)).statusDescription(SUCCESS_MESSAGE).build();
    }

    private long getTotalSearchRecords(SearchConfig searchConfig, SearchRequestDto searchRequestDto, String isCDTDosageDetailsCall) {
        if(SearchConstants.GPI_NAME_SEARCH_FILTER.equalsIgnoreCase(searchRequestDto.getSearchFilter())){
            return searchConfig.getTotalGPINameRecords();
        }
        return SearchUtils.isCashDiscountToolClientCall(searchRequestDto.getClientName(), searchConfig.getDosageEligibleClients())
                && Boolean.valueOf(isCDTDosageDetailsCall) ? searchConfig.getMaxRecords() : searchConfig.getTotalRecords();
    }

    private SearchResponseDto applyFallbackProcess(String drugName) throws ApiException {
        ElasticIndexInfo previousIndex = elasticFallbackService.getFallbackIndex();
        LogServiceContext.addTags("applyFallbackProcessForIndex", previousIndex.getName());
        return getSearch(SearchRequestDto.builder().name(drugName).searchType("fallback:"+previousIndex.getName()).clientName("").build());
    }

    private List<DrugResponse> constructNGramPartialMatchQuery(String drugName, String indexName) {
        LogServiceContext.addTags("constructNGramPartialMatchQueryFor", drugName + " " + indexName);
        String[] indexNames = indexName.split(",");

        // Get all item with given name
        try {
            NativeQuery nGramQuery = queryHelper.buildNgramQuery(drugName);
            SearchHits<Drug> drugHits = elasticsearchOperations.search(nGramQuery, Drug.class, IndexCoordinates.of(indexNames));
            List<DrugResponse> drugRepList = drugHits.stream()
                    .filter(SearchUtils::filterObsoleteDrugs)
                    .map(x -> DrugResponse.builder().drugName(x.getContent().getBrand_name()).genericName(x.getContent().getGnrc_name())
                            .generic("1" .equals(x.getContent().getGnrc_flag()))
                            .otc(SearchConstants.OTC_SINGLE_SOURCE.equalsIgnoreCase(x.getContent().getRx_otc_ind()))
                            .repDrugClaimCount(x.getContent().getRxclm_retail_claim_count())
                            .gpiName(x.getContent().getGpi_name())
                            .score(x.getScore())
                            .details(buildDrugDosageDetails(x))
                            .detailsList(Lists.newArrayList(buildDrugDosageDetails(x)))
                            .build())
                    .collect(Collectors.toList());

            return drugRepList;
        } catch (Exception e) {
            CvsLogger.error(" nGram search failed with exception :"+ e.getMessage());
        }

        return new ArrayList<>();
    }

    private DrugResponse.Details buildDrugDosageDetails(SearchHit<Drug> x) {
        return DrugResponse.Details.builder()
                .drugName(x.getContent().getBrand_name())
                .genericName(x.getContent().getGnrc_name())
                .gpiName(x.getContent().getGpi_name())
                .ndcId(x.getContent().getNdc_code())
                .formName(x.getContent().getDsg_form())
                .formStrengthName(x.getContent().getStrgh_desc())
                .retailMostCommonlyDispensedQty(x.getContent().getRxclm_rtl_rep_drug_mc_qty())
                .mailMostCommonlyDispensedQty(x.getContent().getRxclm_mail_rep_drug_mc_qty())
                .retailClaimCount(x.getContent().getRxclm_retail_claim_count())
                .generic("1".equals(x.getContent().getGnrc_flag()))
                .otc(SearchConstants.OTC_SINGLE_SOURCE.equalsIgnoreCase(x.getContent().getRx_otc_ind()))
                .controlledSubstance(StringUtils.isNotBlank(x.getContent().getDea_code()) &&
                        drugUtils.isControlledSubstance(Integer.parseInt(x.getContent().getDea_code())))
                .gcn_number(x.getContent().getGcn_nbr())
                .drugForm(x.getContent().getDrug_form())
                .gpiCode(x.getContent().getGpi_code())
                .mailMCPDays(x.getContent().getRxclm_ml_rep_drug_day_sply_qty())
                .retailMCPDays(x.getContent().getRxclm_rtl_rep_drug_dy_sply_qty())
                .gcn(SearchUtils.formatValueToLong(x.getContent().getGcn_nbr()))
                .mailMostCommonlyPrescribedDays(SearchUtils.formatValueToLong(x.getContent().getRxclm_ml_rep_drug_day_sply_qty()))
                .retailMostCommonlyPrescribedDays(SearchUtils.formatValueToLong(x.getContent().getRxclm_rtl_rep_drug_dy_sply_qty()))
                .nhu(x.getContent().getQl_nhu_type_cd())
                .strengthQuantity(x.getContent().getStrgh_nbr())
                .strengthDescription(x.getContent().getStrgh_desc())
                .dosageFormTypeCodeDescription(x.getContent().getDigital_dsg_form())
                .routeName(x.getContent().getRoute_name())
                .strengthCondition(x.getContent().getStrg_cond())
                .strengthUnit(x.getContent().getStrgh_unit())
                .strengthVolumeNumber(x.getContent().getStrgh_vol_nbr())
                .strengthVolumeUnit(x.getContent().getStrgh_vol_unit())
                .biosimilarGroup(x.getContent().getBiologic_name_grouper())
                .totalPackageQuantity(x.getContent().getTot_pkg_qty())
                .packageDescription(x.getContent().getPkg_desc())
                .build();
    }

    private List<DrugResponse> filterWithDrugNames(String drugName, String searchFilter, List<DrugResponse> drugRepList) {
        if(SearchConstants.GPI_NAME_SEARCH_FILTER.equalsIgnoreCase(searchFilter)){
            return filterDrugsWithStartEnd(drugName, drugRepList).stream()
                    //.limit(searchConfig.getTotalRecords())
                    .collect(Collectors.toList());
        }
        List<DrugResponse> newDrugList = drugRepList.stream().filter(item -> StringUtils.containsIgnoreCase(item.getDrugName(), drugName))
                .filter(SearchUtils.distinctByKey(DrugResponse::getDrugName))
                .collect(Collectors.toList());

        return filterDrugsWithStartEnd(drugName, newDrugList).stream()
                .limit(searchConfig.getTotalRecords()).collect(Collectors.toList());
    }

    private List<DrugResponse> filterDrugsWithStartEnd(String drugName, List<DrugResponse> newDrugList) {
        List<DrugResponse> startsWith3Letters = newDrugList.stream()
                .filter(item -> StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName.substring(0, 3)))
                .collect(Collectors.toList());

        List<DrugResponse> startsWithMoreThan3Letters = newDrugList.stream()
                .filter(item -> !StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName.substring(0, 3)))
                .collect(Collectors.toList());

        return Stream.of(startsWith3Letters, startsWithMoreThan3Letters).flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    private List<DrugResponse> sortFuzzyPhoneticDrugList(List<DrugResponse> drugList, String drugName) {
        List<DrugResponse> startsWith2or3Letters = drugList.stream()
                .filter(item -> (StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName.substring(0, 3))
                        || StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName
                        .substring(0, 2))))
                .sorted( (x1,x2) -> Math.round(x2.getRepDrugClaimCount() - x1.getRepDrugClaimCount()))
                .collect(Collectors.toList());

        List<DrugResponse> startsWithOtherLetters = drugList.stream()
                .filter(item -> !(StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName.substring(0, 3)) &&
                        StringUtils.startsWithIgnoreCase(item.getDrugName(), drugName.substring(0, 2))))
                .sorted( (x1,x2) -> Math.round(x2.getRepDrugClaimCount() - x1.getRepDrugClaimCount()))
                .collect(Collectors.toList());

        return Stream.of(startsWith2or3Letters, startsWithOtherLetters).flatMap(Collection::stream).collect(Collectors.toList());
    }

}
