package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import lombok.Data;

@Data
public class Beneficiary {

	private String userId;
	private String externalID;
	private long beneficiaryId;
	private String ID;
	private String IDType;
	private String lastName;
	private String firstName;
	private String clientCode;
	private String gender;
	private String dateOfBirth;
	private String effectiveDate;
	private String terminationDate;
	private String carrierID;
	private String accountID;
	private String groupID;
	private String userTier;
	private String memberStatus;
	private String phoneAreaCode;
	private String phoneNo;
	private String personCode;
	private String stateCode;
	private String payorID;
	private int sortByCode;
	private String zipCode;
	private String searchType;
	private String addressType;
	private String clientFilterList;
	private String findSingleMember;
	private String as400Route;
	private String requesterID;
	private String application;
	private String clientAppName;
	private String authType;
	private long internalID;
	private boolean underAgeMinor;
	private InternalParams internalParams;
	private String groupPlanCd;
	private String billingRptCd;
	private String planExtn;
	private String groupExtn;
	private String eisName;
	private boolean registered;
	BeneficiaryKey beneficiaryKey;
	private String lastLoggedInTs;
	private boolean lockoutInd;

	public String getID() {
		return ID;
	}

	public void setID(String ID) {
		this.ID = ID;
	}

	public BeneficiaryKey getBeneficiaryKey() {
		return beneficiaryKey;
	}
	public void setBeneficiaryKey(BeneficiaryKey beneficiaryKey) {
		this.beneficiaryKey = beneficiaryKey;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getExternalID() {
		return externalID;
	}
	public void setExternalID(String externalID) {
		this.externalID = externalID;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getClientCode() {
		return clientCode;
	}
	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPersonCode() {
		return personCode;
	}
	public void setPersonCode(String personCode) {
		this.personCode = personCode;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getCarrierID() {
		return carrierID;
	}
	public void setCarrierID(String carrierID) {
		this.carrierID = carrierID;
	}
	public String getAccountID() {
		return accountID;
	}
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}
	public String getGroupID() {
		return groupID;
	}
	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}
	public String getPayorID() {
		return payorID;
	}
	public void setPayorID(String payorID) {
		this.payorID = payorID;
	}
	public int getSortByCode() {
		return sortByCode;
	}
	public void setSortByCode(int sortByCode) {
		this.sortByCode = sortByCode;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getPhoneAreaCode() {
		return phoneAreaCode;
	}
	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	public String getClientFilterList() {
		return clientFilterList;
	}
	public void setClientFilterList(String clientFilterList) {
		this.clientFilterList = clientFilterList;
	}
	public String getFindSingleMember() {
		return findSingleMember;
	}
	public void setFindSingleMember(String findSingleMember) {
		this.findSingleMember = findSingleMember;
	}
	public String getAs400Route() {
		return as400Route;
	}
	public void setAs400Route(String as400Route) {
		this.as400Route = as400Route;
	}
	public String getRequesterID() {
		return requesterID;
	}
	public void setRequesterID(String requesterID) {
		this.requesterID = requesterID;
	}
	public String getApplication() {
		return application;
	}
	public void setApplication(String application) {
		this.application = application;
	}
	public String getClientAppName() {
		return clientAppName;
	}
	public void setClientAppName(String clientAppName) {
		this.clientAppName = clientAppName;
	}
	public long getBeneficiaryId() {
		return beneficiaryId;
	}
	public void setBeneficiaryId(long beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}
	public String getUserTier() {
		return userTier;
	}
	public void setUserTier(String userTier) {
		this.userTier = userTier;
	}
	public String getMemberStatus() {
		return memberStatus;
	}
	public void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getTerminationDate() {
		return terminationDate;
	}
	public void setTerminationDate(String terminationDate) {
		this.terminationDate = terminationDate;
	}
	/**
	 * @return the authType
	 */
	public String getAuthType() {
		return authType;
	}
	/**
	 * @param authType the authType to set
	 */
	public void setAuthType(String authType) {
		this.authType = authType;
	}
	/**
	 * @return the internalID
	 */
	public long getInternalID() {
		return internalID;
	}
	/**
	 * @param internalID the internalID to set
	 */
	public void setInternalID(long internalID) {
		this.internalID = internalID;
	}
	/**
	 * @return the internalParams
	 */
	public InternalParams getInternalParams() {
		return internalParams;
	}
	/**
	 * @param internalParams the internalParams to set
	 */
	public void setInternalParams(InternalParams internalParams) {
		this.internalParams = internalParams;
	}
	/**
	 * @return the groupPlanCd
	 */
	public String getGroupPlanCd() {
		return groupPlanCd;
	}
	/**
	 * @param groupPlanCd the groupPlanCd to set
	 */
	public void setGroupPlanCd(String groupPlanCd) {
		this.groupPlanCd = groupPlanCd;
	}
	/**
	 * @return the billingRptCd
	 */
	public String getBillingRptCd() {
		return billingRptCd;
	}
	/**
	 * @param billingRptCd the billingRptCd to set
	 */
	public void setBillingRptCd(String billingRptCd) {
		this.billingRptCd = billingRptCd;
	}
	/**
	 * @return the planExtn
	 */
	public String getPlanExtn() {
		return planExtn;
	}
	/**
	 * @param planExtn the planExtn to set
	 */
	public void setPlanExtn(String planExtn) {
		this.planExtn = planExtn;
	}
	/**
	 * @return the groupExtn
	 */
	public String getGroupExtn() {
		return groupExtn;
	}
	/**
	 * @param groupExtn the groupExtn to set
	 */
	public void setGroupExtn(String groupExtn) {
		this.groupExtn = groupExtn;
	}
	/**
	 * @return the eisName
	 */
	public String getEisName() {
		return eisName;
	}
	/**
	 * @param eisName the eisName to set
	 */
	public void setEisName(String eisName) {
		this.eisName = eisName;
	}
	/**
	 * @return the registeredMember
	 */
	public boolean isRegistered() {
		return registered;
	}
	/**
	 * @param registeredMember the registeredMember to set
	 */
	public void setRegistered(boolean registered) {
		this.registered = registered;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}
