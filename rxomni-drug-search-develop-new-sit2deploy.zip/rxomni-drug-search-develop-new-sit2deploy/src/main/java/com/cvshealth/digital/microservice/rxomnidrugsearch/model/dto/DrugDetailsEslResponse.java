package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class DrugDetailsEslResponse {

    private String statusCode;
    private String statusDescription;
    private List<DrugV2Response> drugs;

}
