package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FormularyMapping {

	@JsonAlias(value = "formularyNumber")
	private String formularyId;

	@JsonAlias(value = "name")
	private String formularyName;

	@JsonProperty(value = "year")
	private int year;

	@JsonProperty(value = "clientFormularyName")
	private String clientFormularyName;

	@JsonProperty(value = "linesOfBusiness")
	public ArrayList<LinesOfBusiness> linesOfBusiness;

	public static class LinesOfBusiness {
		@JsonAlias(value = "code")
		public String lobCode;
		@JsonAlias(value = "description")
		public String lobDescription;
	}

}
