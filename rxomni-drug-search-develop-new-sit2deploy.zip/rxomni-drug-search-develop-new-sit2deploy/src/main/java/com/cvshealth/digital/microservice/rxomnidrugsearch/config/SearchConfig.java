package com.cvshealth.digital.microservice.rxomnidrugsearch.config;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.File;
import java.util.Set;

@Configuration
@ComponentScan(basePackages = { "com.cvshealth.digital.drugsearch.service" })
@Data
@Slf4j
public class SearchConfig {

    @Value("${elasticsearch.hostAndPort}")
    private String elasticSearchHost;

    @Value("${elasticsearch.maxRecords}")
    private int maxRecords;

    @Value("${elasticsearch.fuzziness}")
    private String fuzziness;

    @Value("${elasticsearch.indexName}")
    private String indexName;

    @Value("${search.totalRecords}")
    private long totalRecords;

    @Value("${search.totalGPINameRecords}")
    private int totalGPINameRecords;

    @Value("${elasticsearch.nGram.analyzer}")
    private String nGramAnalyzer;

    @Value("${elasticsearch.nGram.fieldName}")
    private String nGramFieldName;

    @Value("${elasticsearch.claimCount.fieldName}")
    private String rxRetailClaimCount;

    @Value("${elasticsearch.userName}")
    private String elasticSearchUserId;

    @Value("${elasticsearch.authCode}")
    private String elasticSearchAuth;

    @Value("${elasticsearch.healthCheck.drugNames}")
    private String drugNames;

    @Value("${search.fallbackEnabled}")
    private boolean fallbackEnabled;

    @Value("${search.fallbackIndex}")
    private String fallbackIndex;

    @Value("${elasticsearch.medi-span.indexName}")
    private String mediSpanIndexName;

    @Value("${aiml.service.url}")
    private String aimlServiceUrl;

    @Value("${search.aimlSuggestionEnabled}")
    private boolean aimlSuggestionEnabled;

    @Value("${search.aimlSuggestionClients}")
    private String[] aimlSuggestionClients;

    @Value("${search.enableDosageDetails.clientNames}")
    private String[] dosageEligibleClients;

    @Value("${search.dea-class-codes.controlled-substance}")
    private Set<String> deaClassCodes;

    @Autowired
    private Environment environment;

    @Value("${search.conditionSearchEnabled}")
    private boolean conditionSearchEnabled;

    @Value("${search.maxNdcIds}")
    private int maxNdcIds;
    public SSLContext getSSLContext() throws Exception {
        SSLContextBuilder builder = SSLContexts.custom();
        builder.loadTrustMaterial(new File(environment.getProperty("javax.net.ssl.trustStore")),
                environment.getProperty("javax.net.ssl.trustStorePassword").toCharArray(),
                new TrustSelfSignedStrategy());
        return builder.build();
    }

    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }

}
