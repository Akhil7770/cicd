package com.cvshealth.digital.microservice.rxomnidrugsearch.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cvshealth.digital.framework.service.rest.RestRequestInfo;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.exception.model.ApiStatusCodes;
import com.cvshealth.digital.framework.starter.exception.model.FaultTypes;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyMapping;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyTherapeuticClasses;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.TokenModel;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.OAuthTokenService;

@Service
public class FetchFormularyTherapeuticClassesService {

	private static final String SERVICE_NAME = "myPBMservices";

	private static final String OPERATION_NAME_GET_FORMULARY_DRUGCLASS = "fetchFormularyTherapeuticClassesEndPoint";

	/** The rest service. */
	@Autowired
	private RestService restService;

	/** The oauth token service. */
	@Autowired
	private OAuthTokenService oAuthTokenService;

	public FormularyTherapeuticClasses fetchFormularyTherapeuticClasses(String page, String pageSize,
			String sortDirection) throws ApiException {
		ResponseEntity<FormularyTherapeuticClasses> responseEntity = null;

		try {
			TokenModel token = oAuthTokenService.getAuthToken();
			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Bearer " + token.getAccess_token());
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
			HttpEntity request = new HttpEntity<>(headers);
			Map<String, String> requestMap = new HashMap<String, String>();
			requestMap.put("page", page);
			requestMap.put("pageSize", pageSize);
			requestMap.put("sortDirection", sortDirection);
			RestRequestInfo requestInfo = restService.buildRestRequestInfo(SERVICE_NAME,
					OPERATION_NAME_GET_FORMULARY_DRUGCLASS, HttpMethod.GET, null, headers, requestMap);
			responseEntity = restService.httpRequest(requestInfo, null, FormularyTherapeuticClasses.class);
		} catch (Exception e) {
			throw new ApiException(ApiStatusCodes.INTERNAL_SERVER_ERROR, FaultTypes.ERROR);
		}

		return responseEntity.getBody();
	}

}
