package com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@lombok.Data
public class BeneficiaryKey {
	private Integer benefactorClientInternalID;
	private Integer cardholderInternalID;
	private String carrierID;
	private String clientCode;
	private Long clientId;
	private String clientName;
	private String externalID;
	private String groupID;
	private String accountID;
	private String eisName;


	private Integer linkedBeneficiaryInternalID;
	private String linkedEffectiveDate;
	private String linkedTerminationDate;
	private Integer provideClientIdentifier;
	private String rxBin;
	private String rxPcn;
	private String rxGroup;
	private String issuer;
	private String planCardId;
}