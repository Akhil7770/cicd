package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails;


import lombok.Data;

@Data
public class DrugDetailsV2Request {
    private String id;
    private String idType;

    private String ndcId;
    private String drugName;
    private Boolean isOEMember;
    private String cag;
}