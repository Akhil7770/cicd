package com.cvshealth.digital.microservice.rxomnidrugsearch.util;

import com.cvshealth.digital.framework.starter.exception.api.ApiBadRequestException;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiErrorStatus;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class DrugValidator {
    private DrugValidator() {
    }

    public static void validateDrugName(String name) throws ApiException {

        //Search term length must be > 3 to query ES.
        if (StringUtils.isBlank(name) || name.length() < 3) {
            throw new ApiBadRequestException(ApiErrorStatus.REQUIRED_FIELD_MISSING_ERROR);
        }

        if (name.matches("[0-9 ]+")) {
            //Checks drug with numeric values and with any spaces.
            throw new ApiBadRequestException(ApiErrorStatus.MUST_MATCH_PATTERN_ERROR);
        }
    }

    public static void validateNDCId(String name) throws ApiException {

        //Search term length must be > 3 to query ES.
        if (StringUtils.isBlank(name) || name.length() != 11) {
            throw new ApiBadRequestException(ApiErrorStatus.REQUIRED_FIELD_MISSING_ERROR);
        }

        if (!StringUtils.isNumeric(name)) {
            //Checks drug with numeric values and with any spaces.
            throw new ApiBadRequestException(ApiErrorStatus.MUST_MATCH_PATTERN_ERROR);
        }
    }

}
