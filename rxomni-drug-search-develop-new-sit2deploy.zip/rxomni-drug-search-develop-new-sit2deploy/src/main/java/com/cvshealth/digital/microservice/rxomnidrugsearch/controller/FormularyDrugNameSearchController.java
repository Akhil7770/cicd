package com.cvshealth.digital.microservice.rxomnidrugsearch.controller;

import java.util.concurrent.ExecutionException;

import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.ApiErrorResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyDrugNameSearch;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.FormularyDrugNameSearchResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.FormularyDrugNameSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping("/microservices/rxomni-drug-search")

public class FormularyDrugNameSearchController {

    @Autowired
    private FormularyDrugNameSearchService formularyDrugNameSearchService;

    @GetMapping(value = "/drug/search/v1/getFormularyDrugNameSearch", produces = MediaType.APPLICATION_JSON_VALUE)
    @Tag(name = "Search")
    @Operation(summary = "fetchFormularyDrugMapping", description = "Get Formulary Drug Information based on drug name and alphabet")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Success Response", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = FormularyDrugNameSearchResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }),
            @ApiResponse(responseCode = "404", description = "No Drugs Found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ApiErrorResponseDto.class)) }) })
    @CrossOrigin("cvshealth.com")
    public ResponseEntity<FormularyDrugNameSearch> fetchFormularyDrugNameSearchMapping(
            @RequestParam(value = "drugName", required = true) String drugName,
            @RequestParam(value = "searchType", required = true) String searchType,
            @RequestParam(value = "page", required = true) String page,
            @RequestParam(value = "pageSize", required = true) String pageSize)  throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        FormularyDrugNameSearch res = formularyDrugNameSearchService.fetchFormularyDrugNameSearch(drugName,
                searchType, page, pageSize);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

}

