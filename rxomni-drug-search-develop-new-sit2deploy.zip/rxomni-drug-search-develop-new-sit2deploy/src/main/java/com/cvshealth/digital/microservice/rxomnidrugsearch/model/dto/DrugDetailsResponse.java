package com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DrugDetailsResponse {
    //Form Strength Dosage details.
    private String ndc11_id;
    private int brand_generic_status_id;
    private String product_short_name;
    private String on_form_name;
    private String on_form_strength_name;
    private String brand_name;
    private String gpi_code;
    private String gnrc_name;
    private String gcn_number;
    private String digital_dosage_form_desc;
}
