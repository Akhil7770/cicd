package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.ClientConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.ElasticIndexInfo;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.ElasticFallbackService;
import org.apache.http.HttpEntity;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;

public class ElasticFallbackServiceTest extends BaseIntegrationTest{

    @Mock
    private SearchConfig searchConfig;

    @Mock
    private ClientConfig clientConfig;

    @InjectMocks
    private ElasticFallbackService elasticFallbackService;

    @Test
    public void testFallbackIndexReturnLatestIndex() throws Exception {
        when(searchConfig.getFallbackIndex()).thenReturn("t_rep_drug-*");
        RestClient restClientMock = mock(RestClient.class);
        when(clientConfig.elasticsearchRestClient(any())).thenReturn(restClientMock);
        Response respMock = mock(Response.class);
        when(restClientMock.performRequest(any())).thenReturn(respMock);
        HttpEntity entity = mock(HttpEntity.class);
        when(respMock.getEntity()).thenReturn(entity);
        String val = "[{\"i\": \"t_drug\"}]";
        InputStream inputStream = new ByteArrayInputStream(val.getBytes(StandardCharsets.UTF_8));
        when(entity.getContent()).thenReturn(inputStream);
        ElasticIndexInfo fallbackIndexes = elasticFallbackService.getFallbackIndex();
        Assertions.assertNotNull(fallbackIndexes);
    }

    @Test
    public void testFallbackIndexRThrowException() {
        lenient().when(searchConfig.getFallbackIndex()).thenReturn("t_rep_drug-*");
        when(clientConfig.elasticsearchRestClient(any())).thenThrow(new RuntimeException());
        ApiException e = assertThrows(ApiException.class, () -> elasticFallbackService.getFallbackIndex());
        Assertions.assertTrue(e.getApiError().getHttpStatus().is5xxServerError());
    }

}
