package com.cvshealth.digital.microservice.rxomnidrugsearch.test.controller;

import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.controller.DrugDetailsController;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.*;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.DrugDetailsService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.test.service.BaseIntegrationTest;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DrugDetailsControllerTest extends BaseIntegrationTest {

    @Mock
    private DrugDetailsService drugDetailsService;
    @InjectMocks
    private DrugDetailsController drugDetailsController;

    public static final String ndcId = "00071015523";

    @Test
    public void testDrugInfoReturnSuccess() throws ApiException {
        DrugDetailsRequest drugDetailsRequest = new DrugDetailsRequest();
        drugDetailsRequest.setNdcIdList(Lists.newArrayList(ndcId));
        List<DrugDetailsResponse> drugFormAndDosageDetails = new ArrayList<>();
        DrugDetailsResponse response = DrugDetailsResponse.builder().ndc11_id(ndcId).build();
        drugFormAndDosageDetails.add(response);
        when(drugDetailsService.getDrugFormAndDosageDetails(eq(drugDetailsRequest))).thenReturn(drugFormAndDosageDetails);
        ResponseEntity<List<DrugDetailsResponse>> drugFormAndStrengthDetails = drugDetailsController.getDrugFormAndStrengthDetails(new HashMap<>(), drugDetailsRequest);

        assertNotNull(drugFormAndStrengthDetails);
        assertNotNull(drugFormAndStrengthDetails.getBody());
        assertTrue(drugFormAndStrengthDetails.getBody().stream().anyMatch(a -> ndcId.equalsIgnoreCase(a.getNdc11_id())));
    }

    @Test
    public void testV2DrugInfoReturnSuccess() throws ApiException {
        DrugDetailsV2Request drugDetailsRequest = new DrugDetailsV2Request();
        drugDetailsRequest.setNdcId(ndcId);
        DrugResponse response = DrugResponse.builder().drugName("lipitor").build();
        SearchResponseDto searchResponseDto = SearchResponseDto.builder().drugs(Lists.newArrayList(response)).build();
        when(drugDetailsService.getV2DrugFormAndDosageDetails(eq(drugDetailsRequest))).thenReturn(searchResponseDto);
        ResponseEntity<SearchResponseDto> drugFormAndStrengthDetails = drugDetailsController.getV2DrugFormAndStrengthDetailsByNdcId(new HashMap<>(), drugDetailsRequest);

        assertNotNull(drugFormAndStrengthDetails);
        assertNotNull(drugFormAndStrengthDetails.getBody());
        assertTrue(drugFormAndStrengthDetails.getBody().getDrugs().stream().anyMatch(a -> "lipitor".equalsIgnoreCase(a.getDrugName())));
    }

    @Test
    public void testGetV1DrugConditionReturnSuccess() throws Exception {

        DrugConditionsRequest drugConditionsRequest = new DrugConditionsRequest();
        drugConditionsRequest.setNdcId("51167012101");
        Map<String, String> headers = new HashMap<>();
        headers.put("x-grid", "test-grid");

        SearchResponseDto responseDto = new SearchResponseDto();
        responseDto.setDrugConditions(List.of("cystic fibrosis with homozygous F508del mutation in CFTR gene", "cystic fibrosis with heterozygous F508del mutation in CFTR gene", "cystic fibrosis with responsive CFTR mutation"));
        responseDto.setStatusCode("0000");
        responseDto.setStatusDescription("Success");

        when(drugDetailsService.getDrugConditions(eq(drugConditionsRequest), eq(headers))).thenReturn(responseDto);

        ResponseEntity<SearchResponseDto> response = drugDetailsController.getV1DrugCondition(headers, drugConditionsRequest);

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertEquals(3, response.getBody().getDrugConditions().size());
        assertEquals("cystic fibrosis with homozygous F508del mutation in CFTR gene", response.getBody().getDrugConditions().get(0));
        assertEquals("cystic fibrosis with heterozygous F508del mutation in CFTR gene", response.getBody().getDrugConditions().get(1));
        assertEquals("cystic fibrosis with responsive CFTR mutation", response.getBody().getDrugConditions().get(2));
        assertEquals("0000", response.getBody().getStatusCode());
        assertEquals("Success", response.getBody().getStatusDescription());

        verify(drugDetailsService, times(1)).getDrugConditions(eq(drugConditionsRequest), eq(headers));
    }
}
