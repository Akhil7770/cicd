package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import com.cvshealth.digital.framework.service.rest.RestHttpServiceException;
import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.ApiErrorStatus;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.cache.CacheResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.*;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.DrugSearchNdcidRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.GetPlanDetailsResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.Drug;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.CacheService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.CrmService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.DrugDetailsService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.SearchByNdcService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.elasticsearch.core.*;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.data.elasticsearch.core.query.Query;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.cvshealth.digital.microservice.rxomnidrugsearch.test.data.TestHelper.*;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SearchByNdcServiceTest extends BaseIntegrationTest {

    @InjectMocks
    private SearchByNdcService searchByNdcService;

    public static final String ndcId = "00071015523";

    @Mock
    private SearchConfig searchConfig;

    @Mock
    private ElasticsearchOperations elasticsearchOperations;

    @Mock
    private DrugDetailsService drugDetailsService;

    @Mock
    private CrmService crmService;

    private String drugDetailEndPoint="test.com";

    private String setCache="test.com";

    private String getCache="test.com";

    @Spy
    private ServiceUtils serviceUtils = new ServiceUtils(getObjectMapper());

    private ServiceUtils serviceUtility = new ServiceUtils(getObjectMapper());

    @Mock
    private CacheService cacheService;
    @Mock
    private RestService restService;

    @BeforeEach
    void setup(TestInfo info) throws IOException, ApiException {
        String jsonResp = "{\"statusCode\":\"0000\",\"statusDescription\":\"Success\",\"beneficiary\":{\"userId\":\"57226202\",\"externalID\":\"05004206100\",\"beneficiaryId\":57226202,\"lastName\":\"EDUARDO\",\"firstName\":\"WARREN\",\"gender\":\"1\",\"dateOfBirth\":\"01/02/1954\",\"phoneNumbers\":[],\"personCode\":\"00\",\"sortByCode\":0,\"internalID\":57226202,\"underAgeMinor\":false,\"eisName\":\"rxclaim\",\"registered\":true,\"lockoutInd\":false,\"id\":\"57226202\",\"idtype\":\"PBM_QL_PARTICIPANT_ID_TYPE\"}}";
        MemberInfoResponse patientInfoResponse = serviceUtils.fromJson(jsonResp, MemberInfoResponse.class);

        ExecutorService executor = Executors.newFixedThreadPool(3);

        String jsonPlanDtlsResp = "{\"statusCode\":\"0000\",\"statusDescription\":\"Success\",\"beneficiaryKey\":{\"benefactorClientInternalID\":29047,\"cardholderInternalID\":57226202,\"carrierID\":\"22MV\",\"clientCode\":\"X22MV\",\"clientId\":29047,\"clientName\":\"IX DIRECT PAY MEDEX\",\"externalID\":\"05004206100\",\"groupID\":\"997445010\",\"accountID\":\"4015051\",\"eisName\":\"rxclaim\",\"provideClientIdentifier\":13627},\"primary\":false,\"personalizationId\":2043730,\"registrationOptedOut\":true,\"isEligible\":true,\"planStartDate\":\"2023-01-01\",\"earlyRegistrationAllowed\":true,\"medicare\":false,\"medBEligible\":false,\"aetnaClient\":false,\"nonPbmLobCode\":\"01\",\"personCode\":\"00\",\"coverageEffectiveDate\":\"2023-01-01\",\"coverageTerminationDate\":\"2039-12-31\",\"isFuturePlan\":false,\"stCob\":false,\"relationShipCode\":\"1\",\"qlMail\":true,\"planBenefitList\":[{\"active\":true,\"deliverySystem\":1,\"effective\":\"2023-01-01\",\"expiration\":\"2039-12-31\",\"planBenefitId\":\"-666\",\"planId\":\"TDMSHLPLNI\",\"retail90DaySupplyProgram\":false,\"maintenanceChoiceIndicator\":false},{\"active\":true,\"deliverySystem\":2,\"effective\":\"2023-01-01\",\"expiration\":\"2039-12-31\",\"mailOrderPharmacy\":\"SAT\",\"planBenefitId\":\"233559\",\"planId\":\"TDMSHLPLNM\",\"retail90DaySupplyProgram\":false,\"maintenanceChoiceIndicator\":false},{\"active\":true,\"deliverySystem\":3,\"effective\":\"2023-01-01\",\"expiration\":\"2039-12-31\",\"planBenefitId\":\"-666\",\"planId\":\"TDMSHLPLN\",\"retail90DaySupplyProgram\":false,\"maintenanceChoiceIndicator\":false}],\"prefPharmInd\":\"N\"}";
        GetPlanDetailsResponse planDtlsResponse = serviceUtils.fromJson(jsonPlanDtlsResp, GetPlanDetailsResponse.class);

        CompletableFuture<MemberInfoResponse> patientInfoTask = CompletableFuture
                .supplyAsync(() -> patientInfoResponse, executor);

        CompletableFuture<GetPlanDetailsResponse> planDetailsTask = CompletableFuture
                .supplyAsync(() -> planDtlsResponse, executor);
        lenient().when(crmService.makeParallelCalls(any(), any())).thenReturn(Arrays.asList(patientInfoTask,  planDetailsTask));
        if (info.getDisplayName().equalsIgnoreCase("testSearchByNdcIdAuthFlowReturnErrorWhenNoDrugDetails()")) {
            lenient().when(restService.execute(eq("drug-details-service"), eq("getV2DrugDetails"), any(),
                    eq(DrugDetailsEslResponse.class), any(),any())).thenThrow(new RestHttpServiceException("UNPROCESSABLE_ENTITY"));
        }else{
            lenient().when(restService.execute(eq("drug-details-service"), eq("getV2DrugDetails"), any(),
                    eq(DrugDetailsEslResponse.class), any(),any())).thenReturn(getDrugResponseV2());
        }

        lenient().when(drugDetailsService.getV2DrugFormAndDosageDetails(Mockito.any())).thenReturn(SearchResponseDto.builder().drugs(new ArrayList<>()).build());

        if(info.getDisplayName().equalsIgnoreCase("testSearchByNdcIdByElasticUsingGenericCodesReturnSuccess()")) {
            Drug sildenafilRecordData = serviceUtility.fromJson(SILDENAFIL_CDT_RECORD, Drug.class);
            Drug lipitorRecordData = serviceUtility.fromJson(LIPITOR_RECORD, Drug.class);

            List<SearchHit<Drug>> generic_hits = Lists.newArrayList(new SearchHit<>("index_drug", "631191", null, 1f, null,
                    new HashMap<>(), null, null, null, new ArrayList<>(), sildenafilRecordData));
            List<SearchHit<Drug>> brand_hits = Lists.newArrayList(new SearchHit<>("index_drug", "123456", null, 1f, null,
                    new HashMap<>(), null, null, null, new ArrayList<>(), lipitorRecordData));

            SearchHits<Drug> genericDrugHits = new SearchHitsImpl<Drug>(1L, TotalHitsRelation.EQUAL_TO,
                    1.0F, null, null, null, generic_hits,
                    null, null, null);
            SearchHits<Drug> brandDrugHits = new SearchHitsImpl<Drug>(1L, TotalHitsRelation.EQUAL_TO,
                    1.0F, null, null, null, brand_hits,
                    null, null, null);
            lenient().when(elasticsearchOperations.search((Query) any(),eq(Drug.class), any())).thenReturn(brandDrugHits).thenReturn(brandDrugHits)
                    .thenReturn(genericDrugHits);
        }else{
            Drug lipitorRecordData = serviceUtility.fromJson(LIPITOR_RECORD, Drug.class);

            List<SearchHit<Drug>> hits = Lists.newArrayList(new SearchHit<>("index_drug", "631190", null, 1f, null,
                    new HashMap<>(), null, null, null, new ArrayList<>(), lipitorRecordData));

            SearchHits<Drug> drugHits = new SearchHitsImpl<Drug>(1L, TotalHitsRelation.EQUAL_TO,
                    1.0F, null, null, null, hits,
                    null, null, null);

            lenient().when(elasticsearchOperations.search((Query) any(),eq(Drug.class),eq(IndexCoordinates.of("index_drug")))).thenReturn(drugHits);

        }

        lenient().when(restService.execute(eq("cache-service"), eq("set-data"), any(),
                eq(CacheResponse.class))).thenReturn(getCacheResponse());
    }

    @Test
    public void testSearchByNdcIdReturnSuccess() throws ApiException {
        when(searchConfig.getMediSpanIndexName()).thenReturn("index_drug");
        SearchResponseDto responseDto = searchByNdcService.searchByNdcId(ndcId);
        Assertions.assertEquals("00071015523", responseDto.getDrugInfo().getNdcId());
        assertEquals("LIPITOR", responseDto.getDrugInfo().getDrugName());
    }

    @Test
    public void testSearchByNdcIdReturnFailure() {
        when(searchConfig.getMediSpanIndexName()).thenReturn("index_drug");
        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),eq(IndexCoordinates.of("index_drug"))))
                .thenThrow(new RuntimeException());
        Assert.assertThrows(Exception.class, () -> searchByNdcService.searchByNdcId(ndcId));
    }

    @Test
    public void testSearchByNdcIdReturnPlanDetailsFailure1() {
//        when(restService.execute(eq("cache-service"), eq("set-data"), any(),
//                eq(CacheResponse.class))).thenReturn(null);
        String jsonResp = "{\"statusCode\":\"0000\",\"statusDescription\":\"Success\",\"beneficiary\":{\"userId\":\"57226202\",\"externalID\":\"05004206100\",\"beneficiaryId\":57226202,\"lastName\":\"EDUARDO\",\"firstName\":\"WARREN\",\"gender\":\"1\",\"dateOfBirth\":\"01/02/1954\",\"phoneNumbers\":[],\"personCode\":\"00\",\"sortByCode\":0,\"internalID\":57226202,\"underAgeMinor\":false,\"eisName\":\"rxclaim\",\"registered\":true,\"lockoutInd\":false,\"id\":\"57226202\",\"idtype\":\"PBM_QL_PARTICIPANT_ID_TYPE\"}}";
        MemberInfoResponse patientInfoResponse = serviceUtils.fromJson(jsonResp, MemberInfoResponse.class);

        ExecutorService executor = Executors.newFixedThreadPool(3);

        String jsonPlanDtlsResp = "{\"statusCode\":\"5013\",\"statusDescription\":\"Failed\"}";
        GetPlanDetailsResponse planDtlsResponse = serviceUtils.fromJson(jsonPlanDtlsResp, GetPlanDetailsResponse.class);

        CompletableFuture<MemberInfoResponse> patientInfoTask = CompletableFuture
                .supplyAsync(() -> patientInfoResponse, executor);

        CompletableFuture<GetPlanDetailsResponse> planDetailsTask = CompletableFuture
                .supplyAsync(() -> planDtlsResponse, executor);
        lenient().when(crmService.makeParallelCalls(any(), any())).thenReturn(Arrays.asList(patientInfoTask,  planDetailsTask));

        Assert.assertThrows(ApiException.class, () -> searchByNdcService.searchNdcId(getDrugSearchNdcidRequest(), ""));
    }

    @Test
    public void testSearchByNdcIdReturnPlanDetailsFailure2() {
//        when(restService.execute(eq("cache-service"), eq("set-data"), any(),
//                eq(CacheResponse.class))).thenReturn(null);
        String jsonResp = "{\"statusCode\":\"0000\",\"statusDescription\":\"Success\",\"beneficiary\":{\"userId\":\"57226202\",\"externalID\":\"05004206100\",\"beneficiaryId\":57226202,\"lastName\":\"EDUARDO\",\"firstName\":\"WARREN\",\"gender\":\"1\",\"dateOfBirth\":\"01/02/1954\",\"phoneNumbers\":[],\"personCode\":\"00\",\"sortByCode\":0,\"internalID\":57226202,\"underAgeMinor\":false,\"eisName\":\"rxclaim\",\"registered\":true,\"lockoutInd\":false,\"id\":\"57226202\",\"idtype\":\"PBM_QL_PARTICIPANT_ID_TYPE\"}}";
        MemberInfoResponse patientInfoResponse = serviceUtils.fromJson(jsonResp, MemberInfoResponse.class);

        ExecutorService executor = Executors.newFixedThreadPool(3);

        String jsonPlanDtlsResp = "{\"statusCode\":\"5011\",\"statusDescription\":\"Failed\"}";
        GetPlanDetailsResponse planDtlsResponse = serviceUtils.fromJson(jsonPlanDtlsResp, GetPlanDetailsResponse.class);

        CompletableFuture<MemberInfoResponse> patientInfoTask = CompletableFuture
                .supplyAsync(() -> patientInfoResponse, executor);

        CompletableFuture<GetPlanDetailsResponse> planDetailsTask = CompletableFuture
                .supplyAsync(() -> planDtlsResponse, executor);
        lenient().when(crmService.makeParallelCalls(any(), any())).thenReturn(Arrays.asList(patientInfoTask,  planDetailsTask));

        Assert.assertThrows(ApiException.class, () -> searchByNdcService.searchNdcId(getDrugSearchNdcidRequest(), ""));
    }

    @Test
    public void testSearchByNdcIdReturnPatientDetailsFailure1() {
//        when(restService.execute(eq("cache-service"), eq("set-data"), any(),
//                eq(CacheResponse.class))).thenReturn(null);
        String jsonResp = "{\"statusCode\":\"5013\",\"statusDescription\":\"Failed\"}";
        MemberInfoResponse patientInfoResponse = serviceUtils.fromJson(jsonResp, MemberInfoResponse.class);

        ExecutorService executor = Executors.newFixedThreadPool(3);

        String jsonPlanDtlsResp = "{\"statusCode\":\"0000\",\"statusDescription\":\"Success\"}";
        GetPlanDetailsResponse planDtlsResponse = serviceUtils.fromJson(jsonPlanDtlsResp, GetPlanDetailsResponse.class);

        CompletableFuture<MemberInfoResponse> patientInfoTask = CompletableFuture
                .supplyAsync(() -> patientInfoResponse, executor);

        CompletableFuture<GetPlanDetailsResponse> planDetailsTask = CompletableFuture
                .supplyAsync(() -> planDtlsResponse, executor);
        lenient().when(crmService.makeParallelCalls(any(), any())).thenReturn(Arrays.asList(patientInfoTask,  planDetailsTask));

        Assert.assertThrows(ApiException.class, () -> searchByNdcService.searchNdcId(getDrugSearchNdcidRequest(), ""));
    }

    @Test
    public void testSearchByNdcIdReturnPatientDetailsFailure2() {
//        when(restService.execute(eq("cache-service"), eq("set-data"), any(),
//                eq(CacheResponse.class))).thenReturn(null);
        String jsonResp = "{\"statusCode\":\"5011\",\"statusDescription\":\"Failed\"}";
        MemberInfoResponse patientInfoResponse = serviceUtils.fromJson(jsonResp, MemberInfoResponse.class);

        ExecutorService executor = Executors.newFixedThreadPool(3);

        String jsonPlanDtlsResp = "{\"statusCode\":\"0000\",\"statusDescription\":\"Success\"}";
        GetPlanDetailsResponse planDtlsResponse = serviceUtils.fromJson(jsonPlanDtlsResp, GetPlanDetailsResponse.class);

        CompletableFuture<MemberInfoResponse> patientInfoTask = CompletableFuture
                .supplyAsync(() -> patientInfoResponse, executor);

        CompletableFuture<GetPlanDetailsResponse> planDetailsTask = CompletableFuture
                .supplyAsync(() -> planDtlsResponse, executor);
        lenient().when(crmService.makeParallelCalls(any(), any())).thenReturn(Arrays.asList(patientInfoTask,  planDetailsTask));

        Assert.assertThrows(ApiException.class, () -> searchByNdcService.searchNdcId(getDrugSearchNdcidRequest(), ""));
    }

    @Test
    public void testSearchByNdcIdAuthFlowReturnSuccess() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        SearchResponseDto responseDto = searchByNdcService.searchNdcId(getDrugSearchNdcidRequest(), "");
        assertTrue(ndcId, responseDto.getDrugs().stream().anyMatch(a -> a.getDrugName().equalsIgnoreCase("Lipitor")));
    }

    @Test
    public void testSearchByNdcIdAuthFlowReturnFromNoCache1() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
//        when(restService.execute(eq("cache-service"), eq("set-data"), any(),
//                eq(CacheResponse.class))).thenReturn(null);
        SearchResponseDto responseDto = searchByNdcService.searchNdcId(getDrugSearchNdcidRequest(), "");
        assertTrue(ndcId, responseDto.getDrugs().stream().anyMatch(a -> a.getDrugName().equalsIgnoreCase("Lipitor")));
    }

    @Test
    public void testSearchByNdcIdAuthFlowReturnFromNoCache2() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        CacheResponse cacheResponse = getCacheResponse();
        cacheResponse.getResponseMetaData().setStatusCode("1111");
//        when(restService.execute(eq("cache-service"), eq("set-data"), any(),
//                eq(CacheResponse.class))).thenReturn(cacheResponse);
        SearchResponseDto responseDto = searchByNdcService.searchNdcId(getDrugSearchNdcidRequest(), "");
        assertTrue(ndcId, responseDto.getDrugs().stream().anyMatch(a -> a.getDrugName().equalsIgnoreCase("Lipitor")));
    }

    @Test
    public void testSearchByNdcIdAuthFlowReturnFromNoCache3() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        CacheResponse cacheResponse = getCacheResponse();
        cacheResponse.getResponsePayloadData().getData().get(0).setKey(null);
        cacheResponse.getResponsePayloadData().getData().get(0).setValue(null);
//        when(restService.execute(eq("cache-service"), eq("set-data"), any(),
//                eq(CacheResponse.class))).thenReturn(cacheResponse);
        SearchResponseDto responseDto = searchByNdcService.searchNdcId(getDrugSearchNdcidRequest(), "");
        assertTrue(ndcId, responseDto.getDrugs().stream().anyMatch(a -> a.getDrugName().equalsIgnoreCase("Lipitor")));
    }

    @Test
    public void testSearchByNdcIdAuthFlowReturnErrorWhenNoDrugDetails() {
        CacheResponse cacheResponse = getCacheResponse();
        cacheResponse.getResponsePayloadData().getData().get(0).setValue("{\"statusCode\":\"200\",\"statusDescription\":\" Search is success! \",\"drugs\":[{\"drugName\":\"Lipitor\"}]}");
//        when(restService.execute(eq("cache-service"), eq("set-data"), any(),
//                eq(CacheResponse.class))).thenReturn(cacheResponse);
        ApiException e = assertThrows(ApiException.class, () -> searchByNdcService.searchNdcId(getDrugSearchNdcidRequest(), ""));
        Assertions.assertTrue(e.getApiError().getHttpStatus().is4xxClientError());
    }

    @Test
    public void testSearchByNdcIdByElasticReturnSuccess() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        when(searchConfig.getIndexName()).thenReturn("index_drug");
        DrugSearchNdcidRequest drugSearchNdcidRequest = new DrugSearchNdcidRequest();
        drugSearchNdcidRequest.setNdcId("00071015523");
        SearchResponseDto responseDto = searchByNdcService.searchNdcId(drugSearchNdcidRequest, "");
        assertTrue(responseDto.getDrugs().stream().anyMatch(a -> a.getDrugName().equalsIgnoreCase("Lipitor")));
    }

    @Test
    public void testSearchByNdcIdByElasticUsingGenericCodesReturnSuccess() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        when(searchConfig.getIndexName()).thenReturn("index_drug");
        DrugSearchNdcidRequest drugSearchNdcidRequest = new DrugSearchNdcidRequest();
        drugSearchNdcidRequest.setNdcId("76282064501");
        SearchResponseDto responseDto = searchByNdcService.searchNdcId(drugSearchNdcidRequest, "");
        assertTrue(responseDto.getDrugs().stream().anyMatch(a -> a.getDrugName().equalsIgnoreCase("SILDENAFIL")));
    }

    @Test
    public void testSearchByNameFromCacheReturnSuccess() throws ApiException, ExecutionException, InterruptedException, IOException {
        SearchResponseDto responseDto = searchByNdcService.searchByName(getDrugSearchNdcidRequest(), "");
        assertTrue(responseDto.getDrugs().stream().anyMatch(a -> a.getDrugName().equalsIgnoreCase("Lipitor")));
    }


    @Test
    public void testSearchByNameReturnSuccess() throws ApiException, ExecutionException, InterruptedException, IOException {
//        when(restService.execute(eq("cache-service"), eq("set-data"), any(),
//                eq(CacheResponse.class))).thenReturn(null);

        SearchResponseDto responseDto = searchByNdcService.searchByName(getDrugSearchNdcidRequest(), "");
        assertTrue(responseDto.getDrugs().stream().anyMatch(a -> a.getDrugName().equalsIgnoreCase("Lipitor")));
    }

    @Test
    public void testSearchByInvalidNdcIdReturnSuccess() {
        ApiException e = assertThrows(ApiException.class, () -> searchByNdcService.searchByNdcId("7070001188"));
        assertEquals(ApiErrorStatus.MUST_MATCH_PATTERN.httpStatus().getReasonPhrase(), e.getApiError().getHttpStatus().getReasonPhrase());
    }
}