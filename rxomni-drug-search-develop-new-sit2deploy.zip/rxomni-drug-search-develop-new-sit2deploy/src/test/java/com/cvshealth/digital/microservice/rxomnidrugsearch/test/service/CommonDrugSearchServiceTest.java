package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.when;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.framework.starter.utils.ThreadPoolUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchRequestDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.CacheService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.CommonDrugSearchService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.SearchService;

@RunWith(MockitoJUnitRunner.class)
public class CommonDrugSearchServiceTest extends BaseIntegrationTest{

    @Mock
    private CacheService cacheService;

    @Mock
    private RestService restService;

    @Mock
    private ServiceUtils serviceUtils;

    @Mock
    private SearchService searchService;

    @Mock
    private ThreadPoolUtils threadPoolUtils;

    @InjectMocks
    private CommonDrugSearchService commonDrugSearchService;

    @Test
    public void testFetchCommonDrugsReturnLipitor() throws Exception {
        SearchResponseDto searchResponseDto = new SearchResponseDto();
        searchResponseDto.setStatusCode("200");
        searchResponseDto.setStatusDescription("Search is success!");
        List<DrugResponse> drugs = new ArrayList<>();
        DrugResponse drugResponse = new DrugResponse();
        drugResponse.setDrugName("Lipitor");
        drugs.add(drugResponse);
        searchResponseDto.setDrugs(drugs);
        when(cacheService.checkCache(any(), any(), any())).thenReturn("");
        when(restService.execute(any(), any(), any(), any())).thenReturn(searchResponseDto);

        List<DrugResponse> lipitorRec = Collections.singletonList(DrugResponse.builder().drugName("Lipitor").build());
        when(threadPoolUtils.waitToCompleteAndReturn(any())).thenReturn(Collections.singletonList(SearchResponseDto.builder().drugs(lipitorRec).build()));

        when(searchService.getSearch(any())).thenReturn(SearchResponseDto.builder().drugs(lipitorRec).build());

        SearchRequestDto searchRequestDto = new SearchRequestDto();
        searchRequestDto.setName("Lipitor");
        searchRequestDto.setSearchType("SEARCH_API");
        searchRequestDto.setClientName("TestClient");

        SearchResponseDto response = commonDrugSearchService.retrieveCommonDrugs(searchRequestDto);
        Assert.assertNotNull(response);
        Assert.assertFalse(CollectionUtils.isEmpty(response.getDrugs()));
        Assert.assertEquals("200", response.getStatusCode());
        Assert.assertEquals("Search is success!", response.getStatusDescription());
        Assert.assertEquals("Lipitor", response.getDrugs().get(0).getDrugName());
    }

    @Test
    public void testFetchCommonDrugsFromCache() throws Exception {
        String cacheValue = "{\"statusCode\":\"200\",\"statusDescription\":\"Search is success!\",\"drugs\":[{\"drugName\":\"Lipitor\"}]}";
        SearchResponseDto searchResponseDto = new SearchResponseDto();
        searchResponseDto.setStatusCode("200");
        searchResponseDto.setStatusDescription("Search is success!");
        List<DrugResponse> drugs = new ArrayList<>();
        DrugResponse drugResponse = new DrugResponse();
        drugResponse.setDrugName("Lipitor");
        drugs.add(drugResponse);
        searchResponseDto.setDrugs(drugs);

        when(cacheService.checkCache(anyString(), anyString(), anyString())).thenReturn(cacheValue);
        when(cacheService.checkForValidCacheForCommonDrugs(anyString(), anyString())).thenReturn(true);
        when(serviceUtils.fromJson(cacheValue, SearchResponseDto.class)).thenReturn(searchResponseDto);

        SearchRequestDto searchRequestDto = new SearchRequestDto();
        searchRequestDto.setName("Lipitor");
        searchRequestDto.setSearchType("SEARCH_API");
        searchRequestDto.setClientName("TestClient");

        SearchResponseDto response = commonDrugSearchService.retrieveCommonDrugs(searchRequestDto);
        Assert.assertNotNull(response);
        Assert.assertEquals("200", response.getStatusCode());
        Assert.assertEquals("Search is success!", response.getStatusDescription());
        Assert.assertEquals("Lipitor", response.getDrugs().get(0).getDrugName());
    }

    @Test
    public void testFetchCommonDrugs_Exception() throws Exception {
        SearchResponseDto searchResponseDto = new SearchResponseDto();
        searchResponseDto.setStatusCode("200");
        searchResponseDto.setStatusDescription("Search is success!");
        List<DrugResponse> drugs = new ArrayList<>();
        DrugResponse drugResponse = new DrugResponse();
        drugResponse.setDrugName("Lipitor");
        drugs.add(drugResponse);
        searchResponseDto.setDrugs(drugs);
        when(cacheService.checkCache(any(), any(), any())).thenReturn("");

        Mockito.doThrow(new RuntimeException()).when(restService).execute(any(), any(), any(), any());

        SearchRequestDto searchRequestDto = new SearchRequestDto();
        searchRequestDto.setName("Lipitor");
        searchRequestDto.setSearchType("SEARCH_API");
        searchRequestDto.setClientName("TestClient");

        assertThrows(Exception.class, () -> commonDrugSearchService.retrieveCommonDrugs(searchRequestDto));
    }

}