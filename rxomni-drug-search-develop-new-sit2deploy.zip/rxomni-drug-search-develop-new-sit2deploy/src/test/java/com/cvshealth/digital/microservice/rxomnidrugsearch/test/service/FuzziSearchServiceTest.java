package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.Drug;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.FuzzySearchService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.test.data.TestHelper;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.QueryHelper;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.data.elasticsearch.core.*;
import org.springframework.data.elasticsearch.core.query.Query;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.cvshealth.digital.microservice.rxomnidrugsearch.test.data.TestHelper.LIPITOR_RECORD;
import static com.cvshealth.digital.microservice.rxomnidrugsearch.test.data.TestHelper.getObjectMapper;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

public class FuzziSearchServiceTest extends BaseIntegrationTest{

    @Mock
    private SearchConfig searchConfig;

    @Mock
    private ElasticsearchOperations elasticsearchOperations;

    @Mock
    private QueryHelper queryHelper;

    @InjectMocks
    private FuzzySearchService fuzzySearchService;

    ServiceUtils serviceUtils = new ServiceUtils(getObjectMapper());

    @Test
    public void testLippiFuzzySearchReturnRecords() {
        when(searchConfig.getTotalRecords()).thenReturn(2L);
        Drug lipitorRecordData = serviceUtils.fromJson(LIPITOR_RECORD, Drug.class);

        List<SearchHit<Drug>> hits = Lists.newArrayList(new SearchHit<>("t_rep_drug", "12978", null, 1f, null,
                new HashMap<>(), null, null, null, new ArrayList<>(), lipitorRecordData),
                new SearchHit<>("t_rep_drug", "12979", null, 1f, null,
                        new HashMap<>(), null, null, null, new ArrayList<>(), serviceUtils.fromJson(TestHelper.LIP2_RECORD, Drug.class)));

        when(searchConfig.getIndexName()).thenReturn("test-index");

        SearchHits<Drug> drugHits = new SearchHitsImpl<>(2L, TotalHitsRelation.EQUAL_TO, 1.0F, null, null, null, hits, null, null, null);

        when(elasticsearchOperations.search((Query) any(), eq(Drug.class), any())).thenReturn(drugHits);

        List<DrugResponse> response = fuzzySearchService.getFuzziSearch("LIP", false);

        Assertions.assertTrue(!response.isEmpty());
        Assertions.assertTrue(response.stream().anyMatch(a -> a.getDrugName().equalsIgnoreCase(TestHelper.LIPITOR)));
    }

    @Test
    public void testLippiFuzzySearchReturnEmptyRecords() {
        when(searchConfig.getTotalRecords()).thenReturn(1L);

        List<SearchHit<Drug>> hits = Lists.newArrayList(new SearchHit<>("t_rep_drug", "12978", null, 1f, null,
                new HashMap<>(), null, null, null, new ArrayList<>(), null));

        SearchHits<Drug> drugHits = new SearchHitsImpl<>(1L, TotalHitsRelation.EQUAL_TO,
                        1.0F, null, null, null, hits, null, null, null);

        // when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        List<DrugResponse> response = fuzzySearchService.getFuzziSearch(TestHelper.LIPITOR,false);
        Assertions.assertTrue(CollectionUtils.isEmpty(response));
    }
}
