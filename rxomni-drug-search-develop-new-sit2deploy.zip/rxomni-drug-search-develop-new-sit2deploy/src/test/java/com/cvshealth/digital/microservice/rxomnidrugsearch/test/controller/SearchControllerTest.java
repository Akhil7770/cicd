package com.cvshealth.digital.microservice.rxomnidrugsearch.test.controller;

import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.assertj.core.util.Lists;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;

import com.cvshealth.digital.framework.starter.exception.api.ApiBadRequestException;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.controller.SearchController;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.HealthCheckException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.HealthCheckResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchRequestDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.planDetails.DrugDetailsV2Request;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.CommonDrugSearchService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.ElasticSearchHealthCheckService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.SearchByNdcService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.SearchService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.test.service.BaseIntegrationTest;
import static com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants.SUCCESS_MESSAGE;
import com.fasterxml.jackson.core.JsonProcessingException;

@RunWith(MockitoJUnitRunner.class)
public class SearchControllerTest extends BaseIntegrationTest{

    @InjectMocks
    private SearchController searchController;

    @Mock
    private SearchService searchService;

    @Mock
    private SearchByNdcService searchByNdcService;

    @Mock
    private ElasticSearchHealthCheckService elasticSearchHealthCheckService;

    @Mock
    private CommonDrugSearchService commonDrugSearchService;

    @Test
    public void searchV1LippiReturnLipitor() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        when(searchService.getSearch(any())).thenReturn(
                SearchResponseDto.builder()
                        .drugs(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()))
                        .statusCode(String.valueOf(HttpStatus.SC_OK)).statusDescription(SUCCESS_MESSAGE).build());
        ResponseEntity<SearchResponseDto> response = searchController.getSearch("", "", "", "", "Lippi","",false, null);
        assertTrue(Objects.requireNonNull(response.getBody()).getDrugs().stream()
                .anyMatch(drug -> drug.getDrugName().equalsIgnoreCase("LIPITOR")));
    }

    @Test
    public void searchByV1NdcIdReturnSuccess() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        DrugDetailsV2Request drugDetailsV2Request = new DrugDetailsV2Request();

        when(searchByNdcService.searchNdcId(any(), any())).thenReturn(
                SearchResponseDto.builder()
                        .drugs(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()))
                        .statusCode(String.valueOf(HttpStatus.SC_OK)).statusDescription(SUCCESS_MESSAGE).build());
        ResponseEntity<SearchResponseDto> response = searchController.getSearch("", "", "","", null,"00071015523", false, drugDetailsV2Request);
        assertTrue(Objects.requireNonNull(response.getBody()).getDrugs().stream()
                .anyMatch(drug -> drug.getDrugName().equalsIgnoreCase("LIPITOR")));
    }

    @Test
    public void searchByV1WithNoDrugOrNdcIdReturnException() {
        assertThrows(ApiBadRequestException.class, () -> searchController.getSearch("", "", "","", null,null, false, null));
    }


    @Test
    public void searchV2LipitorReturnLipitor() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        request.setDrugName("Lipitor");
        when(searchByNdcService.searchByName(any(), any())).thenReturn(
                SearchResponseDto.builder()
                        .drugs(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()))
                        .statusCode(String.valueOf(HttpStatus.SC_OK)).statusDescription(SUCCESS_MESSAGE).build());

        ResponseEntity<SearchResponseDto> response = searchController.getSearchV2("", "", request);
        assertTrue(Objects.requireNonNull(response.getBody()).getDrugs().stream()
                .anyMatch(drug -> drug.getDrugName().equalsIgnoreCase("LIPITOR")));
    }

    @Test
    public void searchByV2NdcIdNoDrugNameOrNdcIdReturnException() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        assertThrows(ApiBadRequestException.class, () -> searchController.getSearchV2("", "", request));
    }

    @Test
    public void searchByV2NdcIdAndDrugNameReturnException() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        request.setDrugName("Lipitor");
        request.setNdcId("00071015523");
        assertThrows(ApiBadRequestException.class, () -> searchController.getSearchV2("", "", request));
    }

    @Test
    public void searchByV2NdcIdReturnSuccess() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        DrugDetailsV2Request request = new DrugDetailsV2Request();
        request.setId("57226202");
        request.setIdType("PBM_QL_PARTICIPANT_ID_TYPE");
        request.setNdcId("00071015523");
        when(searchByNdcService.searchNdcId(any(), any())).thenReturn(
                SearchResponseDto.builder()
                        .drugs(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()))
                        .statusCode(String.valueOf(HttpStatus.SC_OK)).statusDescription(SUCCESS_MESSAGE).build());
        ResponseEntity<SearchResponseDto> response = searchController.getSearchV2("", "", request);
        assertTrue(Objects.requireNonNull(response.getBody()).getDrugs().stream()
                .anyMatch(drug -> drug.getDrugName().equalsIgnoreCase("LIPITOR")));
    }

    @Test
    public void searchForCaremarkReturnNoDosage() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        when(searchService.getSearch(any())).thenReturn(
                SearchResponseDto.builder()
                        .drugs(new ArrayList<>())
                        .statusCode(String.valueOf(HttpStatus.SC_OK)).statusDescription(SUCCESS_MESSAGE).build());
        ResponseEntity<SearchResponseDto> response = searchController.getSearch("", "", "","", "Lippi","", false, null);
        assertTrue(CollectionUtils.isEmpty(response.getBody().getDrugs()));
    }

    @Test
    public void searchStatinReturnAtorvastatin() throws ApiException, ExecutionException, InterruptedException, JsonProcessingException {
        when(searchService.getSearch(any())).thenReturn(
                SearchResponseDto.builder()
                        .drugs(Lists.newArrayList(DrugResponse.builder().drugName("Atorvastatin Statin").build()))
                        .statusCode(String.valueOf(HttpStatus.SC_OK)).statusDescription(SUCCESS_MESSAGE).build());
        ResponseEntity<SearchResponseDto> response = searchController.getSearch("", "","", "", "Statin","", false, null);
        assertTrue(Objects.requireNonNull(response.getBody()).getDrugs().stream()
                .anyMatch(drug -> StringUtils.containsIgnoreCase(drug.getDrugName(),"Atorvastatin")));
    }

    @Test
    public void testElasticSearchHealth() throws HealthCheckException {
        when(elasticSearchHealthCheckService.getESHealthCheck()).thenReturn(HealthCheckResponseDto.builder().status("success").build());
        HealthCheckResponseDto elasticSearchHealth = searchController.getElasticSearchHealth();
        assertTrue("success".equalsIgnoreCase(elasticSearchHealth.getStatus()));
    }

    @Test
    public void testCommonDrugSearch() throws Exception {
        when(commonDrugSearchService.retrieveCommonDrugs(any(SearchRequestDto.class))).thenReturn(
                SearchResponseDto.builder()
                        .drugs(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build()))
                        .statusCode(String.valueOf(HttpStatus.SC_OK)).statusDescription(SUCCESS_MESSAGE).build());
        ResponseEntity<SearchResponseDto> response = searchController.getCommonDrugs("CustomClient", "test");
        assertTrue(Objects.requireNonNull(response.getBody()).getDrugs().stream()
                .anyMatch(drug -> drug.getDrugName().equalsIgnoreCase("LIPITOR")));
    }

}