package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
public abstract class BaseIntegrationTest{
    public static final String ndcId = "70700011885";
}
