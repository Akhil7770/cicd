package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.exception.HealthCheckException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.ElasticSearchHealthCheckService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.SearchService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class HealthCheckServiceTest extends BaseIntegrationTest{

    @Mock
    private SearchConfig searchConfig;

    @InjectMocks
    private ElasticSearchHealthCheckService elasticSearchHealthCheckService;

    @Test
    public void testDrugSearchReturnUpHealthCheck() throws HealthCheckException, ApiException {
        SearchService searchService = mock(SearchService.class);
        SearchResponseDto response = SearchResponseDto.builder().drugs(Lists.newArrayList(DrugResponse.builder().drugName("Lipitor").build())).build();
        when(searchService.getSearch(any())).thenReturn(response);
        when(searchConfig.getDrugNames()).thenReturn("Lipitor");
        elasticSearchHealthCheckService = new ElasticSearchHealthCheckService(searchConfig, searchService);
        Assertions.assertEquals(SearchConstants.UP, elasticSearchHealthCheckService.getESHealthCheck().getStatus());
    }

    @Test
    public void testSearchFailed() throws ApiException {
        SearchService searchService = mock(SearchService.class);
        SearchResponseDto response = SearchResponseDto.builder().drugs(new ArrayList<>()).build();
        when(searchService.getSearch(any())).thenReturn(response);
        when(searchConfig.getDrugNames()).thenReturn("Lipitor");
        elasticSearchHealthCheckService = new ElasticSearchHealthCheckService(searchConfig, searchService);
        Assert.assertThrows(HealthCheckException.class, () -> elasticSearchHealthCheckService.getESHealthCheck());
    }

    @Test
    public void testDrugSearchReturnDownHealthCheck() throws ApiException {
        SearchService searchService = mock(SearchService.class);
        lenient().when(searchService.getSearch(any())).thenThrow(IllegalArgumentException.class);
        elasticSearchHealthCheckService = new ElasticSearchHealthCheckService(searchConfig, searchService);
        HealthCheckException e = assertThrows(HealthCheckException.class, () -> elasticSearchHealthCheckService.getESHealthCheck());
        Assertions.assertEquals(SearchConstants.DOWN, e.getMessage());
        Assertions.assertTrue(e.getHttpStatus().is5xxServerError());
    }
}
