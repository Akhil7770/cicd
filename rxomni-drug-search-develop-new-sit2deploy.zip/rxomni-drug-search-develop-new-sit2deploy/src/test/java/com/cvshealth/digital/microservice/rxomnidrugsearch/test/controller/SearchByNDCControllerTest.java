package com.cvshealth.digital.microservice.rxomnidrugsearch.test.controller;

import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.microservice.rxomnidrugsearch.controller.SearchByNdcController;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchByNdcDrugResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.SearchByNdcService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.test.service.BaseIntegrationTest;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertNotNull;

public class SearchByNDCControllerTest extends BaseIntegrationTest {

    @Mock
    private SearchByNdcService searchByNdcService;

    @InjectMocks
    private SearchByNdcController searchByNdcController;

    public static final String ndcId = "00071015523";

    @Test
    public void searchValidNDCIdReturnSuccessResponse() throws ApiException {
        SearchByNdcDrugResponse searchByNdcDrugResponse = SearchByNdcDrugResponse.builder().drugName("Lipitor").build();
        SearchResponseDto mockResp = SearchResponseDto.builder().drugInfo(searchByNdcDrugResponse).build();
        Mockito.when(searchByNdcService.searchByNdcId(Mockito.eq(ndcId))).thenReturn(mockResp);
        ResponseEntity<SearchResponseDto> searchResponseDtoResponseEntity = searchByNdcController.searchByNdcId(ndcId);
        assertNotNull(searchResponseDtoResponseEntity);
        assertNotNull(searchResponseDtoResponseEntity.getBody());
        assertNotNull(searchResponseDtoResponseEntity.getBody().getDrugInfo());
    }

}
