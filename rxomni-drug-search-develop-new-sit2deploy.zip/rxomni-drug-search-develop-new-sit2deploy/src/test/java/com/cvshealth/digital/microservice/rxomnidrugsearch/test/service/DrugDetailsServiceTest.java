package com.cvshealth.digital.microservice.rxomnidrugsearch.test.service;

import com.cvshealth.digital.framework.service.rest.RestService;
import com.cvshealth.digital.framework.starter.exception.api.ApiException;
import com.cvshealth.digital.framework.starter.utils.ServiceUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.config.SearchConfig;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugDetailsV2Request;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.SearchResponseDto;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.entity.Drug;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.CacheService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.service.DrugDetailsService;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugConditionFDBResponse;
import com.cvshealth.digital.microservice.rxomnidrugsearch.model.dto.DrugConditionsRequest;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.DrugUtils;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.QueryHelper;
import com.cvshealth.digital.microservice.rxomnidrugsearch.util.SearchConstants;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.data.elasticsearch.core.*;
import org.springframework.data.elasticsearch.core.query.Query;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.cvshealth.digital.microservice.rxomnidrugsearch.test.data.TestHelper.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class DrugDetailsServiceTest extends BaseIntegrationTest {

    @Mock
    private SearchConfig searchConfig;

    @Mock
    private ElasticsearchOperations elasticsearchOperations;

    @Mock
    private QueryHelper queryHelper;

    @Mock
    private RestService restService;

    @Mock
    private CacheService cacheService;

    @Mock
    private ServiceUtils serviceUtils;

    @Mock
    private DrugUtils drugUtils;

    @InjectMocks
    private DrugDetailsService drugDetailsService;

    @Test
    public void testDosageDetailsReturnRecords(){
        DrugDetailsRequest drugDetailsRequest = new DrugDetailsRequest();
        drugDetailsRequest.setNdcIdList(Arrays.asList("65757030001", "00054028259"));

        ServiceUtils serviceUtils = new ServiceUtils(getObjectMapper());
        Drug drug1 = serviceUtils.fromJson(ndc1Data, Drug.class);
        Drug drug2 = serviceUtils.fromJson(ndc2Data, Drug.class);

        List<SearchHit<Drug>> hits = new ArrayList<>();
        hits.add(new SearchHit<>("t_drug", "84705", null, 1f, null,
                new HashMap<>(), null, null, null, new ArrayList<>(), drug1));
        hits.add(new SearchHit<>("t_drug", "39842617", null, 1f, null,
                new HashMap<>(), null, null, null, new ArrayList<>(), drug2));
        SearchHits<Drug> drugHits = new SearchHitsImpl<>( 1L, TotalHitsRelation.EQUAL_TO, 1.0F, null,
                                null, null, hits, null, null, null
                        );  
        when(queryHelper.buildNGramTDrugQuery(any())).thenReturn(NativeQuery.builder().build());
        when(searchConfig.getMediSpanIndexName()).thenReturn("t_drug-omni");

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);

        List<DrugDetailsResponse> drugFormAndDosageDetails = drugDetailsService.getDrugFormAndDosageDetails(drugDetailsRequest);
        Assert.assertTrue(drugFormAndDosageDetails.size() > 1);
    }

    @Test
    public void testDosageDetailsReturnEmptyList(){
        DrugDetailsRequest drugDetailsRequest = new DrugDetailsRequest();
        drugDetailsRequest.setNdcIdList(null);
        List<DrugDetailsResponse> drugFormAndDosageDetails = drugDetailsService.getDrugFormAndDosageDetails(drugDetailsRequest);
        Assert.assertEquals(drugFormAndDosageDetails.size(), 0);
    }

    @Test
    public void testDrugDetailsReturnEmptyList(){
        DrugDetailsRequest drugDetailsRequest = new DrugDetailsRequest();
        drugDetailsRequest.setNdcIdList(Arrays.asList("65757030001", "00054028259"));
       // when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenThrow(new RuntimeException());
        List<DrugDetailsResponse> drugFormAndDosageDetails = drugDetailsService.getDrugFormAndDosageDetails(drugDetailsRequest);
        Assert.assertEquals(drugFormAndDosageDetails.size(), 0);
    }

    @Test
    public void testV2DrugDetailsReturnEmptyList() throws ApiException {
        DrugDetailsV2Request drugDetailsV2Request = new DrugDetailsV2Request();
        drugDetailsV2Request.setNdcId("65757030001");
        // when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenThrow(new RuntimeException());
        SearchResponseDto response  = drugDetailsService.getV2DrugFormAndDosageDetails(drugDetailsV2Request);
        Assert.assertEquals(response.getDrugs().size(), 0);
    }

    @Test
    public void testV2DosageDetailsReturnRecords() throws ApiException {
        DrugDetailsV2Request drugDetailsRequest = new DrugDetailsV2Request();
        drugDetailsRequest.setNdcId("65757030001");

        ServiceUtils serviceUtils = new ServiceUtils(getObjectMapper());
        Drug drug1 = serviceUtils.fromJson(ndc1Data, Drug.class);

        List<SearchHit<Drug>> hits = new ArrayList<>();
        hits.add(new SearchHit<>("t_drug", "84705", null, 1f, null,
                new HashMap<>(), null, null, null, new ArrayList<>(), drug1));
        SearchHits<Drug> drugHits = new SearchHitsImpl<>( 1L,
                        TotalHitsRelation.EQUAL_TO, 1.0F, null, null, 
                        null, hits, null, null, null
                );
        when(queryHelper.buildNGramTDrugQuery(any())).thenReturn(NativeQuery.builder().build());
        when(searchConfig.getMediSpanIndexName()).thenReturn("t_drug-omni");

        when(drugUtils.isControlledSubstance(anyInt())).thenReturn(false);

        when(elasticsearchOperations.search((Query) any(),eq(Drug.class),any())).thenReturn(drugHits);
        SearchResponseDto response = drugDetailsService.getV2DrugFormAndDosageDetails(drugDetailsRequest);
        Assert.assertEquals(1, response.getDrugs().size());
    }

    @Test
    public void testGetDrugConditionFDBResponse() throws Exception {
        DrugConditionsRequest drugConditionsRequest = new DrugConditionsRequest();
        drugConditionsRequest.setNdcId("51167012101");
    
        when(cacheService.checkCache(any(), any(), any())).thenReturn("");
        DrugConditionFDBResponse fdbResponse = getDrugConditionFDBResponse();
    
        when(restService.execute(
                eq(SearchConstants.FDB_SERVICE),
                eq(SearchConstants.DRUG_CONDITIONS),
                isNull(),
                eq(DrugConditionFDBResponse.class),
                any(),
                any()
        )).thenReturn(fdbResponse);
    
        java.lang.reflect.Field field = drugDetailsService.getClass().getDeclaredField("conditionslimit");
        field.setAccessible(true);
        field.set(drugDetailsService, 3);
    
        Mockito.doNothing().when(cacheService).updateCache(
            any(),
            any(),
            any(),
            eq(SearchConstants.DRUG_CONDITION_CONTEXT)
        );

        when(serviceUtils.toJson(any())).thenReturn("{\"drugConditions\":[\"cystic fibrosis with homozygous F508del mutation in CFTR gene\",\"cystic fibrosis with heterozygous F508del mutation in CFTR gene\",\"cystic fibrosis with responsive CFTR mutation\"],\"statusCode\":\"0000\",\"statusDescription\":\"Success\"}");
    
        SearchResponseDto response = drugDetailsService.getDrugConditions(drugConditionsRequest, new HashMap<>());
    
        Assert.assertNotNull(response);
        Assert.assertEquals(3, response.getDrugConditions().size());
        Assert.assertEquals("cystic fibrosis with homozygous F508del mutation in CFTR gene", response.getDrugConditions().get(0));
        Assert.assertEquals("cystic fibrosis with heterozygous F508del mutation in CFTR gene", response.getDrugConditions().get(1));
        Assert.assertEquals("cystic fibrosis with responsive CFTR mutation", response.getDrugConditions().get(2));
    }

    @Test
    public void testGetDrugConditionFDBResponse_CacheHit() throws Exception {
        DrugConditionsRequest drugConditionsRequest = new DrugConditionsRequest();
        drugConditionsRequest.setNdcId("51167012101");

        String cacheValue = "{\"drugConditions\":[\"cystic fibrosis with homozygous F508del mutation in CFTR gene\",\"cystic fibrosis with heterozygous F508del mutation in CFTR gene\",\"cystic fibrosis with responsive CFTR mutation\"],\"statusCode\":\"0000\",\"statusDescription\":\"Success\"}";
        when(cacheService.checkCache(any(), any(), any())).thenReturn(cacheValue);
        when(cacheService.checkForValidCacheForDrugConditions(eq(cacheValue), eq("51167012101"))).thenReturn(true);

        SearchResponseDto cachedResponse = new SearchResponseDto();
        cachedResponse.setDrugConditions(Arrays.asList("cystic fibrosis with homozygous F508del mutation in CFTR gene", "cystic fibrosis with heterozygous F508del mutation in CFTR gene", "cystic fibrosis with responsive CFTR mutation"));
        cachedResponse.setStatusCode("0000");
        cachedResponse.setStatusDescription("Success");
        when(serviceUtils.fromJson(eq(cacheValue), eq(SearchResponseDto.class))).thenReturn(cachedResponse);

        SearchResponseDto response = drugDetailsService.getDrugConditions(drugConditionsRequest, new HashMap<>());

        Assert.assertNotNull(response);
        Assert.assertEquals(3, response.getDrugConditions().size());
        Assert.assertEquals("cystic fibrosis with homozygous F508del mutation in CFTR gene", response.getDrugConditions().get(0));
        Assert.assertEquals("cystic fibrosis with heterozygous F508del mutation in CFTR gene", response.getDrugConditions().get(1));
        Assert.assertEquals("cystic fibrosis with responsive CFTR mutation", response.getDrugConditions().get(2));

        verify(restService, never()).execute(any(), any(), any(), any(), any(), any());
        verify(cacheService, never()).updateCache(any(), any(), any(), any());
    }

    @Test
    public void testGetDrugConditionFDBResponse_RuntimeException() throws Exception {
        DrugConditionsRequest drugConditionsRequest = new DrugConditionsRequest();
        drugConditionsRequest.setNdcId("51167012101");
    
        when(cacheService.checkCache(any(), any(), any())).thenReturn("");
        when(restService.execute(
                eq(SearchConstants.FDB_SERVICE),
                eq(SearchConstants.DRUG_CONDITIONS),
                isNull(),
                eq(DrugConditionFDBResponse.class),
                any(),
                any()
        )).thenThrow(new RuntimeException());
    
        java.lang.reflect.Field field = drugDetailsService.getClass().getDeclaredField("conditionslimit");
        field.setAccessible(true);
        field.set(drugDetailsService, 3);
    
        SearchResponseDto response = drugDetailsService.getDrugConditions(drugConditionsRequest, new HashMap<>());
    
        Assert.assertNotNull(response);
        Assert.assertNotNull(response.getDrugConditions());
        Assert.assertTrue(response.getDrugConditions().isEmpty());
        Assert.assertEquals("0000", response.getStatusCode());
        Assert.assertEquals("Success", response.getStatusDescription());
    }
}